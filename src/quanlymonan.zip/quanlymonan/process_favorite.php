<?php
session_start();
require_once 'connect.php';

header('Content-Type: application/json');

error_log("process_favorite.php: Request received"); // Debug

if (!isset($_SESSION['user_id'])) {
    error_log("process_favorite.php: User not logged in"); // Debug
    echo json_encode(['success' => false, 'message' => 'Vui lòng đăng nhập để thực hiện thao tác này.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['dish_id']) || !isset($_POST['action'])) {
    error_log("process_favorite.php: Invalid request - dish_id or action missing"); // Debug
    echo json_encode(['success' => false, 'message' => 'Yêu cầu không hợp lệ.']);
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$dish_id = (int)$_POST['dish_id'];
$action = $_POST['action'];

error_log("process_favorite.php: user_id=$user_id, dish_id=$dish_id, action=$action"); // Debug

// Kiểm tra món ăn có tồn tại không
$sql = "SELECT ma_monan FROM monan WHERE ma_monan = :dish_id";
$stmt = $conn->prepare($sql);
$stmt->execute(['dish_id' => $dish_id]);
if (!$stmt->fetch()) {
    error_log("process_favorite.php: Dish not found, dish_id=$dish_id"); // Debug
    echo json_encode(['success' => false, 'message' => 'Món ăn không tồn tại.']);
    exit();
}

try {
    if ($action === 'add') {
        // Kiểm tra xem món đã có trong danh sách yêu thích chưa
        $sql = "SELECT COUNT(*) FROM favorites WHERE ma_nguoidung = :user_id AND ma_monan = :dish_id";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['user_id' => $user_id, 'dish_id' => $dish_id]);
        if ($stmt->fetchColumn() > 0) {
            error_log("process_favorite.php: Dish already in favorites, dish_id=$dish_id"); // Debug
            echo json_encode(['success' => false, 'message' => 'Món ăn đã có trong danh sách yêu thích.']);
            exit();
        }
        
        // Thêm vào danh sách yêu thích
        $sql = "INSERT INTO favorites (ma_nguoidung, ma_monan, created_at) 
                VALUES (:user_id, :dish_id, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['user_id' => $user_id, 'dish_id' => $dish_id]);
        error_log("process_favorite.php: Added to favorites, dish_id=$dish_id"); // Debug
        echo json_encode(['success' => true, 'message' => 'Đã thêm vào danh sách yêu thích.']);
    } elseif ($action === 'remove') {
        // Xóa khỏi danh sách yêu thích
        $sql = "DELETE FROM favorites WHERE ma_nguoidung = :user_id AND ma_monan = :dish_id";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['user_id' => $user_id, 'dish_id' => $dish_id]);
        if ($stmt->rowCount() > 0) {
            error_log("process_favorite.php: Removed from favorites, dish_id=$dish_id"); // Debug
            echo json_encode(['success' => true, 'message' => 'Đã xóa khỏi danh sách yêu thích.']);
        } else {
            error_log("process_favorite.php: Dish not in favorites, dish_id=$dish_id"); // Debug
            echo json_encode(['success' => false, 'message' => 'Món ăn không có trong danh sách yêu thích.']);
        }
    } else {
        error_log("process_favorite.php: Invalid action, action=$action"); // Debug
        echo json_encode(['success' => false, 'message' => 'Hành động không hợp lệ.']);
    }
} catch (PDOException $e) {
    error_log("process_favorite.php: Database error: " . $e->getMessage()); // Debug
    echo json_encode(['success' => false, 'message' => 'Lỗi cơ sở dữ liệu: ' . $e->getMessage()]);
}
exit();
?>