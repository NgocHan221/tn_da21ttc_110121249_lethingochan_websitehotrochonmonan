<?php
session_start();
require_once 'connect.php';

// Kiểm tra và xác thực dish_id
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php?error=ID không hợp lệ");
    exit();
}
$dish_id = (int)$_GET['id'];

try {
    // Truy vấn lấy thông tin món ăn và bài viết bảo quản
    $sql = "SELECT m.ten_monan, p.id AS preservation_id, p.content, p.ghi_chu 
            FROM monan m 
            LEFT JOIN preservation p ON m.ma_monan = p.dish_id 
            WHERE m.ma_monan = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $dish_id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$data) {
        header("Location: index.php?error=Món ăn không tồn tại");
        exit();
    }

    $preservation_id = $data['preservation_id'];
    $menu_suggestions = [];
    if ($preservation_id) {
        // Lấy thực đơn gợi ý nếu có preservation_id
        $sql = "SELECT meal, calories, dishes 
                FROM menu_suggestions 
                WHERE preservation_id = :preservation_id";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['preservation_id' => $preservation_id]);
        $menu_suggestions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    error_log("Lỗi truy vấn: " . $e->getMessage());
    header("Location: index.php?error=Lỗi truy vấn dữ liệu");
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cách bảo quản thực phẩm - <?php echo htmlspecialchars($data['ten_monan']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        html, body {
            margin: 0;
            padding: 0;
            height: 100%;
            width: 100%;
            overflow-x: hidden;
        }
        .larger-text {
            font-size: 1.25rem;
        }
        .content-container {
            width: 100vw;
            height: 100vh;
            padding: 1rem;
            box-sizing: border-box;
            overflow-y: auto;
        }
        .table-container {
            margin-top: 2rem;
        }
        .preservation-content img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="content-container">
        <h2 class="text-3xl font-bold mb-4 text-center larger-text">Dinh dưỡng trong thực phẩm - <?php echo htmlspecialchars($data['ten_monan']); ?></h2>
        <div class="bg-white p-6 rounded-lg shadow-lg mt-4">
            <h3 class="text-xl font-semibold larger-text"></h3>
            <div class="larger-text mt-2 preservation-content">
                <?php echo $data['content'] ? htmlspecialchars_decode($data['content']) : 'Chưa có hướng dẫn bảo quản.'; ?>
            </div>
            <?php if (!empty($data['ghi_chu'])): ?>
                <div class="larger-text mt-4">
                    <h4 class="text-lg font-semibold"><b>Ghi chú</b></h4>
                    <p><?php echo nl2br(htmlspecialchars($data['ghi_chu'])); ?></p>
                </div>
            <?php endif; ?>
            <?php if (!empty($menu_suggestions)): ?>
                <h3 class="mt-6 text-xl font-semibold larger-text"><b>Thực đơn gợi ý cho món ăn trên</b></h3>
                <div class="table-container">
                    <table class="w-full border-collapse mt-2">
                        <thead>
                            <tr class="bg-gray-200">
                                <th class="border p-2 larger-text">Bữa ăn</th>
                                <th class="border p-2 larger-text">Năng lượng (kcal)</th>
                                <th class="border p-2 larger-text">Món ăn</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $meals = ['Bữa sáng', 'Bữa trưa', 'Bữa tối'];
                            foreach ($meals as $meal): ?>
                                <tr>
                                    <td class="border p-2 larger-text"><?php echo $meal; ?></td>
                                    <td class="border p-2 larger-text">
                                        <?php
                                        $calories = '';
                                        $dishes = [];
                                        foreach ($menu_suggestions as $suggestion) {
                                            if ($suggestion['meal'] === $meal) {
                                                $calories = htmlspecialchars($suggestion['calories']);
                                                $dishes = json_decode($suggestion['dishes'], true) ?? [];
                                                if (json_last_error() !== JSON_ERROR_NONE) {
                                                    error_log("Lỗi giải mã JSON: " . json_last_error_msg());
                                                    $dishes = [];
                                                }
                                                break;
                                            }
                                        }
                                        echo $calories ?: '0';
                                        ?>
                                    </td>
                                    <td class="border p-2 larger-text">
                                        <?php
                                        if (!empty($dishes)) {
                                            echo '<ul class="list-disc pl-5">';
                                            foreach ($dishes as $dish) {
                                                echo '<li>' . htmlspecialchars($dish) . '</li>';
                                            }
                                            echo '</ul>';
                                        } else {
                                            echo 'Chưa có món ăn gợi ý.';
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
            <p class="mt-6 text-center"><a href="detail.php?id=<?php echo $dish_id; ?>" class="text-blue-500 larger-text hover:underline">Quay lại chi tiết món ăn</a></p>
        </div>
    </div>
</body>
</html>