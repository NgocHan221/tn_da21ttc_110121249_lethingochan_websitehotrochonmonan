<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

try {
    $sql = "SELECT * FROM nguoidung WHERE ma_nguoidung = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        session_destroy();
        header("Location: login.php?error=Phiên đăng nhập không hợp lệ");
        exit();
    }

    $message = '';
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
        // Tạo CSRF token nếu chưa có
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            $message = "CSRF token không hợp lệ!";
        } else {
            $ten_dangnhap = trim(filter_var($_POST['ten_dangnhap'], FILTER_SANITIZE_STRING));
            $ho_ten = trim(filter_var($_POST['ho_ten'], FILTER_SANITIZE_STRING));
            $email = trim(filter_var($_POST['email'], FILTER_SANITIZE_EMAIL));
            $sdt = trim(filter_var($_POST['sdt'], FILTER_SANITIZE_STRING));
            $tuoi = (int)$_POST['tuoi'];
            $chieu_cao = (float)$_POST['chieu_cao'];
            $can_nang = (float)$_POST['can_nang'];
            $gioi_tinh = $_POST['gioi_tinh'];
            $tinh_trang = trim(filter_var($_POST['tinh_trang'], FILTER_SANITIZE_STRING));
            $mat_khau = $_POST['mat_khau'];
            $confirm_password = $_POST['confirm_password'];

            if (!empty($mat_khau) && $mat_khau !== $confirm_password) {
                $message = "Mật khẩu xác nhận không khớp!";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $message = "Email không hợp lệ!";
            } elseif (!empty($sdt) && !preg_match('/^0[0-9]{9}$/', $sdt)) {
                $message = "Số điện thoại không hợp lệ!";
            } elseif (!empty($mat_khau) && strlen($mat_khau) < 6) {
                $message = "Mật khẩu mới phải dài ít nhất 6 ký tự!";
            } elseif ($tuoi < 1 || $tuoi > 150) {
                $message = "Tuổi phải từ 1 đến 150!";
            } elseif ($chieu_cao < 50 || $chieu_cao > 300) {
                $message = "Chiều cao phải từ 50 đến 300 cm!";
            } elseif ($can_nang < 20 || $can_nang > 300) {
                $message = "Cân nặng phải từ 20 đến 300 kg!";
            } elseif (!in_array($gioi_tinh, ['Nam', 'Nữ', 'Khác'])) {
                $message = "Giới tính không hợp lệ!";
            } elseif (strlen($tinh_trang) > 50) {
                $message = "Tình trạng không được vượt quá 50 ký tự!";
            } else {
                $sql_check = "SELECT ma_nguoidung FROM nguoidung WHERE (email = :email OR ten_dangnhap = :ten_dangnhap) AND ma_nguoidung != :id";
                $stmt_check = $conn->prepare($sql_check);
                $stmt_check->execute(['email' => $email, 'ten_dangnhap' => $ten_dangnhap, 'id' => $_SESSION['user_id']]);
                $existing_user = $stmt_check->fetch(PDO::FETCH_ASSOC);

                if ($existing_user) {
                    $message = "Email hoặc tên đăng nhập đã tồn tại!";
                } else {
                    $update_data = [
                        'ten_dangnhap' => $ten_dangnhap,
                        'ho_ten' => $ho_ten,
                        'email' => $email,
                        'sdt' => empty($sdt) ? null : $sdt,
                        'tuoi' => $tuoi,
                        'chieu_cao' => $chieu_cao,
                        'can_nang' => $can_nang,
                        'gioi_tinh' => $gioi_tinh,
                        'tinh_trang' => $tinh_trang,
                        'id' => $_SESSION['user_id']
                    ];

                    $sql_update = "UPDATE nguoidung SET ten_dangnhap = :ten_dangnhap, ho_ten = :ho_ten, email = :email, sdt = :sdt, tuoi = :tuoi, chieu_cao = :chieu_cao, can_nang = :can_nang, gioi_tinh = :gioi_tinh, tinh_trang = :tinh_trang";

                    if (!empty($mat_khau)) {
                        $sql_update .= ", mat_khau = :mat_khau";
                        $update_data['mat_khau'] = $mat_khau; // Lưu mật khẩu dạng plain-text
                    }

                    $sql_update .= " WHERE ma_nguoidung = :id";
                    $stmt_update = $conn->prepare($sql_update);
                    $stmt_update->execute($update_data);

                    $_SESSION['ten_dangnhap'] = $ten_dangnhap;
                    $message = "Cập nhật thông tin thành công!";

                    $stmt = $conn->prepare($sql);
                    $stmt->execute(['id' => $_SESSION['user_id']]);
                    $user = $stmt->fetch(PDO::FETCH_ASSOC);
                }
            }
        }
    }

    // Tạo CSRF token mới cho form
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
} catch (PDOException $e) {
    error_log("Database error at " . date('Y-m-d H:i:s') . ": " . $e->getMessage());
    $message = "Đã xảy ra lỗi, vui lòng thử lại sau!";
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hồ sơ người dùng</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gradient-to-br from-blue-100 to-purple-100 min-h-screen flex items-center justify-center py-10">
    <div class="bg-white shadow-xl rounded-xl max-w-4xl w-full p-8 space-y-8">
        <h2 class="text-3xl font-bold text-center text-blue-700">Hồ sơ của <?php echo htmlspecialchars($user['ten_dangnhap']); ?></h2>

        <?php if (!empty($message)): ?>
            <div class="p-4 rounded text-center font-medium <?php echo strpos($message, 'thành công') !== false ? 'bg-green-100 text-green-700 border border-green-400' : 'bg-red-100 text-red-700 border border-red-400'; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <div class="space-y-2 text-gray-700">
            <h3 class="text-xl font-semibold text-gray-800 border-b pb-2">Thông tin cá nhân</h3>
            <p><strong>Tên đăng nhập:</strong> <?php echo htmlspecialchars($user['ten_dangnhap']); ?></p>
            <p><strong>Họ tên:</strong> <?php echo htmlspecialchars($user['ho_ten']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
            <p><strong>Số điện thoại:</strong> <?php echo htmlspecialchars($user['sdt'] ?? ''); ?></p>
            <p><strong>Tuổi:</strong> <?php echo htmlspecialchars($user['tuoi'] ?? ''); ?></p>
            <p><strong>Chiều cao:</strong> <?php echo htmlspecialchars($user['chieu_cao'] ?? ''); ?> cm</p>
            <p><strong>Cân nặng:</strong> <?php echo htmlspecialchars($user['can_nang'] ?? ''); ?> kg</p>
            <p><strong>Giới tính:</strong> <?php echo htmlspecialchars($user['gioi_tinh'] ?? ''); ?></p>
            <p><strong>Tình trạng:</strong> <?php echo htmlspecialchars($user['tinh_trang'] ?? 'Bình thường'); ?></p>
            <div class="mt-6 text-center">
                <button id="toggleFormButton" class="bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700 transition">Cập nhật thông tin</button>
                <a href="index.php" class="ml-4 text-blue-600 hover:underline">Quay lại</a>
            </div>
        </div>

        <div id="updateForm" class="hidden border-t pt-6">
            <h3 class="text-xl font-semibold text-gray-800 mb-4">Cập nhật thông tin</h3>
            <form action="profile.php" method="POST" class="space-y-4">
                <input type="hidden" name="update_profile" value="1">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div><label class="block font-medium">Tên đăng nhập</label><input type="text" name="ten_dangnhap" value="<?php echo htmlspecialchars($user['ten_dangnhap']); ?>" class="w-full mt-1 p-2 border border-gray-300 rounded-lg" required></div>
                    <div><label class="block font-medium">Họ tên</label><input type="text" name="ho_ten" value="<?php echo htmlspecialchars($user['ho_ten']); ?>" class="w-full mt-1 p-2 border border-gray-300 rounded-lg" required></div>
                    <div><label class="block font-medium">Email</label><input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" class="w-full mt-1 p-2 border border-gray-300 rounded-lg" required></div>
                    <div><label class="block font-medium">Số điện thoại</label><input type="text" name="sdt" value="<?php echo htmlspecialchars($user['sdt'] ?? ''); ?>" class="w-full mt-1 p-2 border border-gray-300 rounded-lg"></div>
                    <div><label class="block font-medium">Tuổi</label><input type="number" name="tuoi" value="<?php echo htmlspecialchars($user['tuoi'] ?? ''); ?>" class="w-full mt-1 p-2 border border-gray-300 rounded-lg" min="1" max="150" required></div>
                    <div><label class="block font-medium">Chiều cao (cm)</label><input type="number" name="chieu_cao" value="<?php echo htmlspecialchars($user['chieu_cao'] ?? ''); ?>" step="0.1" min="50" max="300" class="w-full mt-1 p-2 border border-gray-300 rounded-lg" required></div>
                    <div><label class="block font-medium">Cân nặng (kg)</label><input type="number" name="can_nang" value="<?php echo htmlspecialchars($user['can_nang'] ?? ''); ?>" step="0.1" min="20" max="300" class="w-full mt-1 p-2 border border-gray-300 rounded-lg" required></div>
                    <div><label class="block font-medium">Tình trạng</label><input type="text" name="tinh_trang" value="<?php echo htmlspecialchars($user['tinh_trang'] ?? 'Bình thường'); ?>" class="w-full mt-1 p-2 border border-gray-300 rounded-lg" maxlength="50" required></div>
                    <div>
                        <label class="block font-medium">Giới tính</label>
                        <select name="gioi_tinh" class="w-full mt-1 p-2 border border-gray-300 rounded-lg">
                            <option value="Nam" <?php echo ($user['gioi_tinh'] == 'Nam') ? 'selected' : ''; ?>>Nam</option>
                            <option value="Nữ" <?php echo ($user['gioi_tinh'] == 'Nữ') ? 'selected' : ''; ?>>Nữ</option>
                            <option value="Khác" <?php echo ($user['gioi_tinh'] == 'Khác') ? 'selected' : ''; ?>>Khác</option>
                        </select>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="relative">
                        <label class="block font-medium">Mật khẩu mới</label>
                        <input type="password" name="mat_khau" id="mat_khau" class="w-full mt-1 p-2 border border-gray-300 rounded-lg">
                        <span class="absolute right-3 top-9 cursor-pointer" onclick="togglePassword('mat_khau', 'eyeIcon')"><i id="eyeIcon" class="fas fa-eye text-gray-600"></i></span>
                    </div>
                    <div class="relative">
                        <label class="block font-medium">Xác nhận mật khẩu</label>
                        <input type="password" name="confirm_password" id="confirm_password" class="w-full mt-1 p-2 border border-gray-300 rounded-lg">
                        <span class="absolute right-3 top-9 cursor-pointer" onclick="togglePassword('confirm_password', 'eyeIconConfirm')"><i id="eyeIconConfirm" class="fas fa-eye text-gray-600"></i></span>
                    </div>
                </div>

                <div class="pt-4">
                    <button type="submit" class="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition">Lưu thay đổi</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function togglePassword(inputId, iconId) {
            const passwordInput = document.getElementById(inputId);
            const eyeIcon = document.getElementById(iconId);
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                eyeIcon.classList.remove('fa-eye');
                eyeIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                eyeIcon.classList.remove('fa-eye-slash');
                eyeIcon.classList.add('fa-eye');
            }
        }

        document.getElementById('toggleFormButton').addEventListener('click', function () {
            const form = document.getElementById('updateForm');
            form.classList.toggle('hidden');
            form.scrollIntoView({ behavior: 'smooth' });
        });
    </script>
</body>
</html>