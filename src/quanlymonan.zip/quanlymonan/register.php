<?php
session_start();
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['vai_tro'] == 'admin') {
        header("Location: admin_dashboard.php");
    } else {
        header("Location: user_dashboard.php");
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gradient-to-br from-indigo-100 via-blue-50 to-white min-h-screen flex items-center justify-center px-4">
    <div class="bg-white p-8 md:p-10 rounded-2xl shadow-2xl w-full max-w-lg">
        <h2 class="text-3xl font-bold text-center text-indigo-700 mb-4">Tạo tài khoản mới</h2>
        <p class="text-center text-gray-500 mb-6 text-sm">Vui lòng điền đầy đủ thông tin bên dưới</p>

        <?php if (isset($_GET['error'])): ?>
            <div class="bg-red-50 text-red-600 border border-red-200 rounded-md p-3 mb-4 text-sm">
                <i class="fas fa-exclamation-circle mr-2"></i><?php echo htmlspecialchars($_GET['error']); ?>
            </div>
        <?php endif; ?>

        <form action="process_register.php" method="POST" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Tên đăng nhập</label>
                <input type="text" name="ten_dangnhap" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Họ tên</label>
                <input type="text" name="ho_ten" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" name="email" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Số điện thoại</label>
                <input type="text" name="sdt" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none">
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tuổi</label>
                    <input type="number" name="tuoi" min="1" max="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Chiều cao (cm)</label>
                    <input type="number" name="chieu_cao" step="0.1" min="50" max="300" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Cân nặng (kg)</label>
                    <input type="number" name="can_nang" step="0.1" min="20" max="300" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" required>
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Giới tính</label>
                <select name="gioi_tinh" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" required>
                    <option value="Nam">Nam</option>
                    <option value="Nữ">Nữ</option>
                    <option value="Khác">Khác</option>
                </select>
            </div>
            <div class="relative">
                <label class="block text-sm font-medium text-gray-700 mb-1">Mật khẩu</label>
                <input type="password" name="password" id="password" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" required>
                <span class="absolute right-4 top-11 text-gray-500 cursor-pointer hover:text-indigo-700" onclick="togglePassword('password', 'eyeIcon')">
                    <i id="eyeIcon" class="fas fa-eye"></i>
                </span>
            </div>
            <div class="relative">
                <label class="block text-sm font-medium text-gray-700 mb-1">Xác nhận mật khẩu</label>
                <input type="password" name="confirm_password" id="confirm_password" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" required>
                <span class="absolute right-4 top-11 text-gray-500 cursor-pointer hover:text-indigo-700" onclick="togglePassword('confirm_password', 'eyeIconConfirm')">
                    <i id="eyeIconConfirm" class="fas fa-eye"></i>
                </span>
            </div>
            <button type="submit" class="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition duration-200 focus:ring-2 focus:ring-indigo-400 focus:outline-none">Đăng ký</button>
        </form>
        <p class="mt-6 text-center text-gray-600 text-sm">
            Đã có tài khoản?
            <a href="login.php" class="text-indigo-600 font-medium hover:underline">Đăng nhập</a>
        </p>
    </div>

    <script>
        function togglePassword(inputId, iconId) {
            const input = document.getElementById(inputId);
            const icon = document.getElementById(iconId);
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }
    </script>
</body>
</html>
