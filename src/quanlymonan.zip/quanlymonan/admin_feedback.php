<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Handle rating filter
$rating_filter = isset($_GET['rating_filter']) && is_numeric($_GET['rating_filter']) ? (int)$_GET['rating_filter'] : '';
$rating_filter_null = ($rating_filter === 0); // Handle "Chưa đánh giá"

// Lấy danh sách bình luận
$sql = "SELECT f.id, f.content, f.rating, f.created_at, f.is_admin, f.parent_id, 
        u.ten_dangnhap, u.ho_ten, m.ten_monan, m.ma_monan 
        FROM feedback f 
        JOIN nguoidung u ON f.ma_nguoidung = u.ma_nguoidung 
        JOIN monan m ON f.ma_monan = m.ma_monan 
        WHERE f.is_deleted = 0";
if ($rating_filter !== '') {
    if ($rating_filter_null) {
        $sql .= " AND f.rating IS NULL";
    } else {
        $sql .= " AND f.rating = :rating_filter";
    }
}
$sql .= " ORDER BY f.created_at DESC";
$stmt = $conn->prepare($sql);
if ($rating_filter !== '' && !$rating_filter_null) {
    $stmt->bindValue(':rating_filter', $rating_filter, PDO::PARAM_INT);
}
$stmt->execute();
$feedbacks = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Xử lý trả lời bình luận
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['content']) && isset($_POST['feedback_id'])) {
    $content = $_POST['content'];
    $feedback_id = $_POST['feedback_id'];
    
    // Lấy thông tin món ăn để gửi thông báo
    $sql = "SELECT ma_monan, ma_nguoidung FROM feedback WHERE id = :feedback_id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['feedback_id' => $feedback_id]);
    $feedback = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $sql = "INSERT INTO feedback (ma_nguoidung, ma_monan, parent_id, content, created_at, is_admin) 
            VALUES (:ma_nguoidung, :ma_monan, :parent_id, :content, NOW(), 1)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        'ma_nguoidung' => $_SESSION['user_id'],
        'ma_monan' => $feedback['ma_monan'],
        'parent_id' => $feedback_id,
        'content' => $content
    ]);
    
    // Thêm thông báo cho người dùng
    $sql = "INSERT INTO notifications (ma_nguoidung, message, created_at, is_read) 
            VALUES (:ma_nguoidung, :message, NOW(), 0)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        'ma_nguoidung' => $feedback['ma_nguoidung'],
        'message' => "Admin đã trả lời bình luận của bạn về món ăn."
    ]);
    
    header("Location: admin_feedback.php" . ($rating_filter !== '' ? "?rating_filter=$rating_filter" : ""));
    exit();
}

// Xử lý xóa bình luận
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "UPDATE feedback SET is_deleted = 1 WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $delete_id]);
    header("Location: admin_feedback.php" . ($rating_filter !== '' ? "?rating_filter=$rating_filter" : ""));
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý phản hồi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .feedback-card {
            background: #f9fafb;
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            border: 1px solid #e5e7eb;
        }
        .feedback-card.reply {
            margin-left: 2rem;
            background: #f3f4f6;
        }
        .feedback-card .feedback-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        .feedback-card .feedback-header .user-info {
            font-weight: 600;
            color: #1f2937;
        }
        .feedback-card .feedback-header .admin-badge {
            background: #3b82f6;
            color: white;
            padding: 0.2rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.75rem;
        }
        .feedback-card .feedback-content {
            color: #4b5563;
        }
        .feedback-card .feedback-actions {
            margin-top: 0.5rem;
            display: flex;
            gap: 0.5rem;
        }
        .feedback-form {
            margin-top: 1rem;
            background: #ffffff;
            padding: 1rem;
            border-radius: 0.5rem;
            border: 1px solid #e5e7eb;
        }
        .feedback-form textarea {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #e5e7eb;
            border-radius: 0.375rem;
            resize: vertical;
        }
        .filter-container {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            align-items: center;
        }
        .filter-select {
            flex: 0 0 auto;
            min-width: 150px;
        }
        @media (max-width: 640px) {
            .filter-container {
                flex-direction: column;
            }
            .filter-select {
                width: 100%;
            }
        }
    </style>
</head>
<body class="bg-gray-100 flex">
    <!-- Menu dọc bên trái -->
    <div class="w-96 bg-gray-800 text-white h-screen fixed top-0 left-0 p-4 text-xl">
        <h2 class="text-3xl font-bold mb-6">Quản trị viên</h2>
        <ul>
            <li class="mb-4">
                <a href="admin_dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-users mr-2"></i> Quản lý người dùng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-list mr-2"></i> Quản lý danh mục
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_diets.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-utensils mr-2"></i> Quản lý chế độ
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_ingredients.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-seedling mr-2"></i> Quản lý nguyên liệu
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_nutrients.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-heartbeat mr-2"></i> Quản lý dinh dưỡng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_components.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-vial mr-2"></i> Quản lý thành phần dinh dưỡng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_dishes.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-utensil-spoon mr-2"></i> Quản lý món ăn
                </a>
            </li>
            <li class="mb-4">
                <a href="admin_feedback.php" class="flex items-center p-2 bg-gray-700 rounded">
                    <i class="fas fa-comments mr-2"></i> Quản lý phản hồi
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_preservation.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-leaf mr-2"></i> Quản lý chi tiết dinh dưỡng
                </a>
            </li>
            <li>
                <a href="logout.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-sign-out-alt mr-2"></i> Đăng xuất
                </a>
            </li>
        </ul>
    </div>
    <!-- Nội dung chính -->
    <div class="ml-64 p-6 w-full">
        <div class="max-w-6xl mx-auto bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl font-bold mb-6 text-center">Quản lý phản hồi</h2>
            <div class="mb-4 filter-container">
                <form method="GET" class="flex items-center gap-2 filter-select">
                    <select name="rating_filter" onchange="this.form.submit()" class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="" <?php echo $rating_filter === '' ? 'selected' : ''; ?>>Tất cả</option>
                        <option value="0" <?php echo $rating_filter === 0 ? 'selected' : ''; ?>>Chưa đánh giá</option>
                        <option value="1" <?php echo $rating_filter === 1 ? 'selected' : ''; ?>>1 sao</option>
                        <option value="2" <?php echo $rating_filter === 2 ? 'selected' : ''; ?>>2 sao</option>
                        <option value="3" <?php echo $rating_filter === 3 ? 'selected' : ''; ?>>3 sao</option>
                        <option value="4" <?php echo $rating_filter === 4 ? 'selected' : ''; ?>>4 sao</option>
                        <option value="5" <?php echo $rating_filter === 5 ? 'selected' : ''; ?>>5 sao</option>
                    </select>
                </form>
            </div>
            <div class="mt-4">
                <?php
                // Tạo mảng để lưu bình luận theo parent_id
                $feedback_tree = [];
                foreach ($feedbacks as $feedback) {
                    $feedback_tree[$feedback['parent_id'] ?? 0][] = $feedback;
                }

                function display_feedbacks($feedbacks, $feedback_tree, $parent_id = 0, $level = 0) {
                    if (!isset($feedback_tree[$parent_id])) return;
                    foreach ($feedback_tree[$parent_id] as $feedback) {
                        ?>
                        <div class="feedback-card <?php echo $feedback['parent_id'] ? 'reply' : ''; ?>">
                            <div class="feedback-header">
                                <div class="user-info">
                                    <?php echo htmlspecialchars($feedback['ho_ten'] ?: $feedback['ten_dangnhap']); ?>
                                    <?php if ($feedback['is_admin']): ?>
                                        <span class="admin-badge">Admin</span>
                                    <?php endif; ?>
                                    <div class="text-base font-medium text-gray-700 mt-1">
                                        Món ăn: <a href="detail.php?id=<?php echo $feedback['ma_monan']; ?>" class="text-blue-500 hover:underline"><?php echo htmlspecialchars($feedback['ten_monan']); ?></a>
                                    </div>
                                </div>
                                <div class="text-sm text-gray-500">
                                    <?php echo date('d/m/Y H:i', strtotime($feedback['created_at'])); ?>
                                </div>
                            </div>
                            <div class="feedback-content">
                                <?php echo nl2br(htmlspecialchars($feedback['content'])); ?>
                                <div class="mt-2 text-yellow-500">
                                    <?php
                                    if ($feedback['rating']) {
                                        echo str_repeat('★', $feedback['rating']) . str_repeat('☆', 5 - $feedback['rating']);
                                    } else {
                                        echo '<span class="text-gray-500">Chưa đánh giá</span>';
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="feedback-actions">
                                <button onclick="showReplyForm(<?php echo $feedback['id']; ?>)" class="text-blue-500 hover:underline">Trả lời</button>
                                <a href="admin_feedback.php?delete_id=<?php echo $feedback['id']; ?><?php echo $rating_filter !== '' ? '&rating_filter=' . $rating_filter : ''; ?>" class="text-red-500 hover:underline" onclick="return confirm('Bạn có chắc muốn xóa bình luận này?')">Xóa</a>
                            </div>
                            <div id="reply-form-<?php echo $feedback['id']; ?>" class="feedback-form hidden mt-2">
                                <form method="POST">
                                    <input type="hidden" name="feedback_id" value="<?php echo $feedback['id']; ?>">
                                    <textarea name="content" rows="3" placeholder="Viết câu trả lời..." required></textarea>
                                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 mt-2">Gửi trả lời</button>
                                </form>
                            </div>
                        </div>
                        <?php
                        display_feedbacks($feedbacks, $feedback_tree, $feedback['id'], $level + 1);
                    }
                }
                ?>
                <?php if (empty($feedbacks)): ?>
                    <div class="text-center text-gray-500 mt-4">Không có bình luận nào để hiển thị.</div>
                <?php else: ?>
                    <?php display_feedbacks($feedbacks, $feedback_tree); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script>
        function showReplyForm(feedbackId) {
            document.getElementById(`reply-form-${feedbackId}`).classList.toggle('hidden');
        }
    </script>
</body>
</html>