<?php
require_once 'connect.php';

header('Content-Type: application/json');

if (isset($_GET['ma_monan']) && is_numeric($_GET['ma_monan'])) {
    $ma_monan = (int)$_GET['ma_monan'];
    $sql = "SELECT n.ma_nguyenlieu, n.ten_nguyenlieu 
            FROM monan_nguyenlieu mn 
            JOIN nguyenlieu n ON mn.ma_nguyenlieu = n.ma_nguyenlieu 
            WHERE mn.ma_monan = :ma_monan 
            ORDER BY n.ten_nguyenlieu";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_monan' => $ma_monan]);
    $ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['ingredients' => $ingredients]);
} else {
    echo json_encode(['ingredients' => []]);
}
?>