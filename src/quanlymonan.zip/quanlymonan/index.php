<?php
session_start();
require_once 'connect.php';

// Debug: Log session data for troubleshooting
if (isset($_SESSION['user_id'])) {
    error_log("Session data on index.php at " . date('Y-m-d H:i:s') . ": " . print_r($_SESSION, true));
}

// Lấy danh sách chế độ và danh mục để làm bộ lọc
$sql = "SELECT * FROM chedo ORDER BY ten_chedo";
$stmt = $conn->prepare($sql);
$stmt->execute();
$diets = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sql = "SELECT * FROM danhmuc ORDER BY ten_danhmuc";
$stmt = $conn->prepare($sql);
$stmt->execute();
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Xử lý tìm kiếm và bộ lọc
$search_query = $_POST['search_query'] ?? '';
$calo_filter = $_POST['calo_filter'] ?? '';
$chedo_filter = $_POST['chedo_filter'] ?? '';
$danhmuc_filter = $_POST['danhmuc_filter'] ?? '';

$where = [];
$params = [];
$filter_status = [];

if ($calo_filter) {
    switch ($calo_filter) {
        case 'under_250':
            $where[] = "m.calo < 250";
            $filter_status[] = "Calo: Dưới 250 kcal";
            break;
        case '250_350':
            $where[] = "m.calo BETWEEN 250 AND 350";
            $filter_status[] = "Calo: 250 - 350 kcal";
            break;
        case '350_500':
            $where[] = "m.calo BETWEEN 350 AND 500";
            $filter_status[] = "Calo: 350 - 500 kcal";
            break;
        case 'above_500':
            $where[] = "m.calo > 500";
            $filter_status[] = "Calo: Trên 500 kcal";
            break;
    }
}

if ($chedo_filter) {
    $where[] = "m.ma_chedo = :ma_chedo";
    $params['ma_chedo'] = $chedo_filter;
    foreach ($diets as $diet) {
        if ($diet['ma_chedo'] == $chedo_filter) {
            $filter_status[] = "Chế độ: " . htmlspecialchars($diet['ten_chedo']);
            break;
        }
    }
}

if ($danhmuc_filter) {
    $where[] = "EXISTS (
        SELECT 1 
        FROM monan_danhmuc md 
        WHERE md.ma_monan = m.ma_monan 
        AND md.ma_danhmuc = :ma_danhmuc
    )";
    $params['ma_danhmuc'] = $danhmuc_filter;
    foreach ($categories as $category) {
        if ($category['ma_danhmuc'] == $danhmuc_filter) {
            $filter_status[] = "Danh mục: " . htmlspecialchars($category['ten_danhmuc']);
            break;
        }
    }
}

if ($search_query) {
    $where[] = "(m.ten_monan LIKE :search_query 
                OR EXISTS (
                    SELECT 1 
                    FROM monan_danhmuc md 
                    JOIN danhmuc d ON md.ma_danhmuc = d.ma_danhmuc 
                    WHERE md.ma_monan = m.ma_monan 
                    AND d.ten_danhmuc LIKE :search_query
                ) 
                OR EXISTS (
                    SELECT 1 
                    FROM monan_nguyenlieu mn 
                    JOIN nguyenlieu nl ON mn.ma_nguyenlieu = nl.ma_nguyenlieu 
                    WHERE mn.ma_monan = m.ma_monan 
                    AND nl.ten_nguyenlieu LIKE :search_query
                ))";
    $params['search_query'] = '%' . $search_query . '%';
    $filter_status[] = "Tìm kiếm: " . htmlspecialchars($search_query);
}

// Phân trang
$items_per_page = 8;
$current_page = isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] > 0 ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $items_per_page;

// Đếm tổng số món ăn
$count_sql = "SELECT COUNT(*) as total 
              FROM monan m";
if (!empty($where)) {
    $count_sql .= " WHERE " . implode(" AND ", $where);
}
$count_stmt = $conn->prepare($count_sql);
foreach ($params as $key => $value) {
    $count_stmt->bindValue($key, $value);
}
$count_stmt->execute();
$total_items = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = max(1, ceil($total_items / $items_per_page));

// Điều chỉnh current_page nếu vượt quá tổng số trang
if ($current_page > $total_pages) {
    $current_page = $total_pages;
    $offset = ($current_page - 1) * $items_per_page;
}

// Truy vấn danh sách món ăn với đánh giá trung bình và phân trang
$sql = "SELECT m.*, c.ten_chedo, 
               COALESCE(AVG(f.rating), 0) as avg_rating
        FROM monan m 
        LEFT JOIN chedo c ON m.ma_chedo = c.ma_chedo
        LEFT JOIN feedback f ON m.ma_monan = f.ma_monan AND f.rating IS NOT NULL AND f.is_deleted = 0";
if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " GROUP BY m.ma_monan ORDER BY avg_rating DESC, m.ten_monan 
         LIMIT :items_per_page OFFSET :offset";

$stmt = $conn->prepare($sql);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->bindValue(':items_per_page', $items_per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$dishes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Danh sách 3 hình ảnh cho banner
$upload_dir = 'Uploads/images/';
$selected_images = [
    'banner1.jpg',
    'banner2.jpg',
    'banner3.jpg'
];
$banner_images = [];
$valid_extensions = ['jpg', 'jpeg', 'png', 'gif'];

foreach ($selected_images as $image) {
    $file_path = $upload_dir . $image;
    if (file_exists($file_path) && is_file($file_path)) {
        $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        if (in_array($ext, $valid_extensions)) {
            $banner_images[] = $file_path;
        } else {
            error_log("Invalid image extension for: $file_path at " . date('Y-m-d H:i:s'));
        }
    } else {
        error_log("Image not found: $file_path at " . date('Y-m-d H:i:s'));
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang chủ - Danh sách món ăn</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <style>
        .dish-card {
            background: linear-gradient(145deg, #ffffff, #f9fafb);
            border: 1px solid #e5e7eb;
            border-radius: 0.75rem;
            padding: 0.75rem;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            overflow: hidden;
            position: relative;
        }
        .dish-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
        }
        .dish-card-link {
            display: block;
            text-decoration: none;
            color: inherit;
        }
        .dish-card-content {
            position: relative;
        }
        .dish-card-content img {
            width: 100%;
            height: 192px;
            object-fit: cover;
            border-radius: 0.5rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .dish-card:hover .dish-card-content img {
            transform: scale(1.05);
        }
        .dish-card-content h3 {
            font-size: 1.125rem;
            font-weight: 700;
            color: #1f2937;
            margin: 0.5rem 0;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .dish-card-content p {
            font-size: 0.875rem;
            color: #4b5563;
            margin: 0.25rem 0;
            text-align: center;
        }
        .dish-card-content .calo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.25rem;
            font-weight: 600;
            color: #3b82f6;
            font-size: 0.875rem;
        }
        .dish-card-content .rating {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.25rem;
            color: #f59e0b;
            font-size: 0.875rem;
        }
        .detail-btn {
            display: block;
            text-align: center;
            font-size: 0.875rem;
            font-weight: 500;
            color: white;
            background: linear-gradient(to right, #3b82f6, #2563eb);
            padding: 0.5rem 0;
            border-radius: 0.375rem;
            margin: 0.5rem 0 0;
            transition: background 0.3s ease, transform 0.2s ease;
            text-decoration: none;
            z-index: 10;
        }
        .detail-btn:hover {
            background: linear-gradient(to right, #2563eb, #1d4ed8);
            transform: scale(1.02);
        }
        .swiper-slide img {
            width: 100%;
            height: 400px;
            object-fit: cover;
        }
        .filter-card {
            border-radius: 0.75rem;
            padding: 1.5rem;
            transition: all 0.3s ease;
        }
        .filter-card:hover {
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        .filter-card select {
            padding: 0.75rem;
            border-radius: 0.375rem;
            border: 1px solid #e5e7eb;
            width: 100%;
            font-size: 0.875rem;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .filter-card select:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
            outline: none;
        }
        .filter-card .filter-group {
            margin-bottom: 1rem;
        }
        .filter-card .filter-label {
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 0.5rem;
            display: block;
        }
        .filter-card .reset-filter-btn {
            display: block;
            width: 100%;
            text-align: center;
            font-size: 0.875rem;
            font-weight: 500;
            color: white;
            background: linear-gradient(to right, #ef4444, #dc2626);
            padding: 0.5rem 0;
            border-radius: 0.375rem;
            margin-top: 1rem;
            transition: background 0.3s ease, transform 0.2s ease;
        }
        .filter-card .reset-filter-btn:hover {
            background: linear-gradient(to right, #dc2626, #b91c1c);
            transform: scale(1.02);
        }
        .filter-status {
            background-color: #f3f4f6;
            border-radius: 0.5rem;
            padding: 1rem;
            margin-bottom: 1rem;
            font-size: 0.875rem;
            color: #1f2937;
        }
        .filter-status ul {
            list-style-type: disc;
            padding-left: 1.5rem;
        }
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.5rem;
            margin-top: 2rem;
            padding: 1rem;
        }
        .pagination a, .pagination span {
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            font-size: 0.875rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        .pagination a {
            background: linear-gradient(to right, #3b82f6, #2563eb);
            color: white;
        }
        .pagination a:hover {
            background: linear-gradient(to right, #2563eb, #1d4ed8);
            transform: scale(1.05);
        }
        .pagination .active {
            background: #1f2937;
            color: white;
            cursor: default;
        }
        .pagination .disabled {
            background: #e5e7eb;
            color: #9ca3af;
            cursor: not-allowed;
        }
        footer {
            background: linear-gradient(145deg, #1f2937, #111827);
            color: #f3f4f6;
            padding: 2rem 0;
            margin-top: 2rem;
            border-top: 1px solid #374151;
        }
        footer .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1.5rem;
        }
        footer .footer-links {
            display: flex;
            gap: 1.5rem;
        }
        footer .footer-links a {
            color: #d1d5db;
            font-size: 1.25rem;
            transition: color 0.3s ease;
        }
        footer .footer-links a:hover {
            color: #3b82f6;
        }
        footer .footer-info {
            font-size: 1.25rem;
            color: #9ca3af;
            text-align: center;
        }
        footer .footer-social {
            display: flex;
            gap: 1rem;
        }
        footer .footer-social a {
            color: #d1d5db;
            font-size: 1.25rem;
            transition: color 0.3s ease;
        }
        footer .footer-social a:hover {
            color: #3b82f6;
        }
        .search-bar {
            padding: 1.5rem;
            transition: all 0.3s ease;
        }
        .search-bar form {
            position: relative;
            width: 100%;
        }
        .search-bar .input-wrapper {
            position: relative;
            width: 100%;
        }
        .search-bar input {
            padding: 0.75rem 2.5rem 0.75rem 2.5rem;
            border-radius: 9999px;
            border: 2px solid #e5e7eb;
            width: 100%;
            font-size: 0.875rem;
            background-color: #f9fafb;
            transition: border-color 0.3s ease, box-shadow 0.3s ease, background-color 0.3s ease;
        }
        .search-bar input:focus {
            border-color: #3b82f6;
            background-color: #ffffff;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
            outline: none;
        }
        .search-bar .search-icon {
            position: absolute;
            left: 0.75rem;
            top: 50%;
            transform: translateY(-50%);
            color: #6b7280;
            font-size: 1rem;
            pointer-events: none;
            transition: color 0.3s ease;
        }
        .search-bar input:focus + .search-icon {
            color: #3b82f6;
        }
        .search-bar .clear-btn {
            position: absolute;
            right: 0.75rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #6b7280;
            font-size: 1rem;
            cursor: pointer;
            display: none;
            transition: color 0.3s ease;
        }
        .search-bar .clear-btn:hover {
            color: #3b82f6;
        }
        .search-bar .clear-btn.show {
            display: block;
        }
        .navbar {
            background: linear-gradient(145deg, #4f46e5, #10b981);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 50;
        }
        .navbar-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        .nav-menu {
            display: flex;
            gap: 0.75rem;
            align-items: center;
        }
        .nav-menu a {
            color: #e5e7eb;
            font-size: 1rem;
            font-weight: 500;
            text-decoration: none;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            transition: background-color 0.3s ease, color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }
        .nav-menu a:hover {
            background-color: #6b7280;
            color: #ffffff;
        }
        .nav-user-section {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .user-dropdown {
            position: relative;
        }
        .user-button {
            color: #e5e7eb;
            font-size: 1rem;
            font-weight: 500;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            background: transparent;
            transition: background-color 0.3s ease, color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }
        .user-button:hover {
            background-color: #6b7280;
            color: #ffffff;
        }
        .user-dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: #ffffff;
            border-radius: 0.375rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            min-width: 160px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: opacity 0.3s ease, transform 0.3s ease, visibility 0.3s ease;
            z-index: 100;
        }
        .user-dropdown:hover .user-dropdown-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        .user-dropdown-menu a {
            display: block;
            padding: 0.5rem 1rem;
            color: #1f2937;
            font-size: 0.875rem;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .user-dropdown-menu a:hover {
            background-color: #f3f4f6;
        }
        .logout-link {
            color: white;
            font-size: 1rem;
            font-weight: 500;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            text-decoration: none;
            transition: background 0.3s ease, transform 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }
        .logout-link:hover {
            background: linear-gradient(to right, #2563eb, #1d4ed8);
            transform: scale(1.02);
        }
        .hamburger {
            display: none;
            flex-direction: column;
            cursor: pointer;
            gap: 0.25rem;
        }
        .hamburger span {
            width: 24px;
            height: 3px;
            background: #e5e7eb;
            border-radius: 2px;
            transition: all 0.3s ease;
        }
        .hamburger.active span:nth-child(1) {
            transform: rotate(45deg) translate(5px, 5px);
        }
        .hamburger.active span:nth-child(2) {
            opacity: 0;
        }
        .hamburger.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -7px);
        }
        @media (max-width: 767px) {
            .navbar-container {
                flex-wrap: wrap;
            }
            .nav-menu {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: #4f46e5;
                flex-direction: column;
                padding: 1rem;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }
            .nav-menu.active {
                display: flex;
            }
            .nav-menu a {
                padding: 0.75rem;
                width: 100%;
                text-align: left;
                font-size: 1rem;
            }
            .nav-user-section {
                display: none;
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
                padding: 1rem;
                width: 100%;
            }
            .nav-user-section.active {
                display: flex;
            }
            .user-dropdown {
                width: 100%;
            }
            .user-dropdown-menu {
                position: static;
                background: #6b7280;
                box-shadow: none;
                transform: none;
                opacity: 1;
                visibility: visible;
                margin-top: 0.5rem;
                width: 100%;
            }
            .user-dropdown-menu a {
                color: #e5e7eb;
            }
            .user-dropdown-menu a:hover {
                background-color: #4b5563;
            }
            .logout-link {
                width: 100%;
                text-align: left;
                color: white;
            }
            .logout-link:hover {
                color: white;
            }
            .hamburger {
                display: flex;
            }
        }
    </style>
</head>
<body class="bg-gray-100">
    <nav class="navbar">
        <div class="navbar-container">
            <div class="hamburger" id="hamburger" role="button" aria-label="Toggle navigation" aria-expanded="false">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="flex items-center gap-4">
                <div class="nav-menu" id="nav-menu">
                    <a href="index.php"><i class="fas fa-home"></i> Trang chủ</a>
                    <a href="nutrients.php"><i class="fas fa-seedling"></i> Dinh dưỡng</a>
                    <a href="suggest_dishes.php"><i class="fas fa-utensils"></i> Gợi ý theo nguyên liệu</a>
                    <a href="favorites.php"><i class="fas fa-heart"></i> Món ăn yêu thích</a>
                    <a href="menu.php"><i class="fas fa-calendar-alt"></i> Thực đơn</a>
                    <a href="nutrition_chart.php"><i class="fas fa-chart-bar"></i> Biểu đồ dinh dưỡng</a>
                </div>
                <div class="nav-user-section" id="nav-user-section">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <div class="user-dropdown">
                            <button class="user-button">
                                <i class="fas fa-user mr-2"></i>
                                <span><?php echo htmlspecialchars(isset($_SESSION['ten_dangnhap']) && !empty($_SESSION['ten_dangnhap']) ? $_SESSION['ten_dangnhap'] : 'Người dùng'); ?></span>
                            </button>
                            <div class="user-dropdown-menu">
                                <a href="profile.php">Hồ sơ</a>
                            </div>
                        </div>
                        <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt mr-2"></i>Đăng xuất</a>
                    <?php else: ?>
                        <a href="login.php" class="user-button">
                            <i class="fas fa-sign-in-alt mr-2"></i> Đăng nhập
                        </a>
                        <a href="register.php" class="user-button">
                            <i class="fas fa-user-plus mr-2"></i> Đăng ký
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="swiper mySwiper">
        <div class="swiper-wrapper">
            <?php if (empty($banner_images)): ?>
                <div class="swiper-slide">
                    <img src="https://via.placeholder.com/800x400?text=Không+có+hình+ảnh" alt="Placeholder">
                </div>
            <?php else: ?>
                <?php foreach ($banner_images as $image): ?>
                    <div class="swiper-slide">
                        <img src="<?php echo htmlspecialchars($image); ?>" alt="Banner">
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-pagination"></div>
    </div>

    <div class="container mx-auto p-6 flex flex-col md:flex-row gap-6 main-content">
        <div class="flex-1">
            <div class="search-bar mb-8">
                <form method="POST" id="search-form">
                    <div class="input-wrapper">
                        <input type="text" name="search_query" id="search-input" placeholder="Tìm kiếm món ăn, nguyên liệu, danh mục..." value="<?php echo htmlspecialchars($search_query); ?>">
                        <i class="fas fa-search search-icon"></i>
                        <button type="button" class="clear-btn" id="clear-btn">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </form>
            </div>

            <?php if (!empty($filter_status)): ?>
                <div class="filter-status">
                    <p class="font-semibold">Đang lọc:</p>
                    <ul>
                        <?php foreach ($filter_status as $status): ?>
                            <li><?php echo $status; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <h2 class="text-2xl font-bold mb-6 text-center">Danh sách món ăn phổ biến</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <?php if (empty($dishes)): ?>
                    <p class="col-span-full text-center text-gray-500">Không có món ăn nào phù hợp với tiêu chí.</p>
                <?php else: ?>
                    <?php foreach ($dishes as $dish): ?>
                        <div class="dish-card">
                            <a href="detail.php?id=<?php echo $dish['ma_monan']; ?>" class="dish-card-link">
                                <div class="dish-card-content">
                                    <img src="<?php echo htmlspecialchars($dish['hinh_anh'] ?? 'https://via.placeholder.com/300x192'); ?>" alt="<?php echo htmlspecialchars($dish['ten_monan']); ?>" class="w-full h-48 object-cover">
                                    <h3><?php echo htmlspecialchars($dish['ten_monan']); ?></h3>
                                    <p class="calo"><i class="fas fa-fire-alt text-xs"></i> <?php echo htmlspecialchars($dish['calo']); ?> kcal</p>
                                    <p class="rating">
                                        <?php 
                                        $avg_rating = round($dish['avg_rating'], 1);
                                        $full_stars = floor($avg_rating);
                                        $half_star = ($avg_rating - $full_stars) >= 0.5 ? 1 : 0;
                                        $empty_stars = 5 - $full_stars - $half_star;
                                        echo str_repeat('<i class="fas fa-star"></i>', $full_stars);
                                        echo $half_star ? '<i class="fas fa-star-half-alt"></i>' : '';
                                        echo str_repeat('<i class="far fa-star"></i>', $empty_stars);
                                        echo " $avg_rating/5";
                                        ?>
                                    </p>
                                    <p>Chế độ: <?php echo htmlspecialchars($dish['ten_chedo'] ?? 'Chưa có'); ?></p>
                                </div>
                            </a>
                            <a href="detail.php?id=<?php echo $dish['ma_monan']; ?>" class="detail-btn">Xem chi tiết</a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php
                    $filter_params = $_POST;
                    ?>
                    <?php if ($current_page > 1): ?>
                        <a href="?page=<?php echo $current_page - 1; ?>&<?php echo http_build_query($filter_params); ?>">Trước</a>
                    <?php else: ?>
                        <span class="disabled">Trước</span>
                    <?php endif; ?>

                    <?php
                    $start_page = max(1, $current_page - 2);
                    $end_page = min($total_pages, $start_page + 4);
                    if ($end_page - $start_page < 4) {
                        $start_page = max(1, $end_page - 4);
                    }
                    for ($i = $start_page; $i <= $end_page; $i++): ?>
                        <?php if ($i == $current_page): ?>
                            <span class="active"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="?page=<?php echo $i; ?>&<?php echo http_build_query($filter_params); ?>"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <?php if ($current_page < $total_pages): ?>
                        <a href="?page=<?php echo $current_page + 1; ?>&<?php echo http_build_query($filter_params); ?>">Sau</a>
                    <?php else: ?>
                        <span class="disabled">Sau</span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="w-full md:w-64">
            <div class="filter-card sticky top-6">
                <form method="POST" id="filter-form" class="space-y-6">
                    <input type="hidden" name="search_query" value="<?php echo htmlspecialchars($search_query); ?>">
                    <div class="filter-group">
                        <label for="calo_filter" class="filter-label">Lọc theo Calo</label>
                        <select name="calo_filter" id="calo_filter" onchange="this.form.submit()">
                            <option value="">Tất cả</option>
                            <option value="under_250" <?php echo $calo_filter == 'under_250' ? 'selected' : ''; ?>>Dưới 250 kcal</option>
                            <option value="250_350" <?php echo $calo_filter == '250_350' ? 'selected' : ''; ?>>250 - 350 kcal</option>
                            <option value="350_500" <?php echo $calo_filter == '350_500' ? 'selected' : ''; ?>>350 - 500 kcal</option>
                            <option value="above_500" <?php echo $calo_filter == 'above_500' ? 'selected' : ''; ?>>Trên 500 kcal</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="chedo_filter" class="filter-label">Lọc theo Chế độ</label>
                        <select name="chedo_filter" id="chedo_filter" onchange="this.form.submit()">
                            <option value="">Tất cả</option>
                            <?php foreach ($diets as $diet): ?>
                                <option value="<?php echo $diet['ma_chedo']; ?>" <?php echo $chedo_filter == $diet['ma_chedo'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($diet['ten_chedo']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="danhmuc_filter" class="filter-label">Lọc theo Danh mục</label>
                        <select name="danhmuc_filter" id="danhmuc_filter" onchange="this.form.submit()">
                            <option value="">Tất cả</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['ma_danhmuc']; ?>" <?php echo $danhmuc_filter == $category['ma_danhmuc'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($category['ten_danhmuc']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="button" onclick="resetFilters()" class="reset-filter-btn">Xóa bộ lọc</button>
                </form>
            </div>
        </div>
    </div>

    <footer>
        <div class="container mx-auto">
            <div class="footer-links">
                <a href="index.php">Trang chủ</a>
                <a href="nutrients.php">Dinh dưỡng</a>
                <a href="suggest_dishes.php">Gợi ý theo nguyên liệu</a>
                <a href="favorites.php">Món ăn yêu thích</a>
                <a href="menu.php">Thực đơn</a>
                <a href="nutrition_chart.php">Biểu đồ dinh dưỡng</a>
            </div>
            <div class="footer-social">
                <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
            </div>
            <div class="footer-info">
                <p>Liên hệ qua email: <a href="mailto:support@foodsuggestion.com" class="hover:text-blue-500">lethingochan227tv@gmail.com</a></p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script>
        var swiper = new Swiper('.mySwiper', {
            loop: true,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        });

        document.addEventListener('DOMContentLoaded', function () {
            const searchInput = document.getElementById('search-input');
            const clearBtn = document.getElementById('clear-btn');
            const searchForm = document.getElementById('search-form');
            const hamburger = document.getElementById('hamburger');
            const navMenu = document.getElementById('nav-menu');
            const navUserSection = document.getElementById('nav-user-section');

            searchInput.addEventListener('input', function () {
                clearBtn.classList.toggle('show', searchInput.value.length > 0);
            });

            clearBtn.addEventListener('click', function () {
                searchInput.value = '';
                clearBtn.classList.remove('show');
                searchForm.submit();
            });

            if (searchInput.value.length > 0) {
                clearBtn.classList.add('show');
            }

            document.querySelectorAll('.detail-btn').forEach(button => {
                button.addEventListener('click', function (event) {
                    event.stopPropagation();
                });
            });

            hamburger.addEventListener('click', function () {
                const isActive = hamburger.classList.toggle('active');
                hamburger.setAttribute('aria-expanded', isActive);
                navMenu.classList.toggle('active');
                navUserSection.classList.toggle('active');
            });

            document.querySelectorAll('.nav-menu a, .nav-user-section a').forEach(link => {
                link.addEventListener('click', function () {
                    if (window.innerWidth <= 767) {
                        hamburger.classList.remove('active');
                        hamburger.setAttribute('aria-expanded', 'false');
                        navMenu.classList.remove('active');
                        navUserSection.classList.remove('active');
                    }
                });
            });
        });

        function resetFilters() {
            document.getElementById('calo_filter').value = '';
            document.getElementById('chedo_filter').value = '';
            document.getElementById('danhmuc_filter').value = '';
            document.getElementById('search-input').value = '';
            document.getElementById('filter-form').submit();
        }
    </script>
</body>
</html>