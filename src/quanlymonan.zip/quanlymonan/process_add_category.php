<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ten_danhmuc = $_POST['ten_danhmuc'];

    // Kiểm tra tên danh mục đã tồn tại
    $sql = "SELECT * FROM danhmuc WHERE ten_danhmuc = :ten_danhmuc";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_danhmuc' => $ten_danhmuc]);
    if ($stmt->rowCount() > 0) {
        header("Location: add_category.php?error=Tên danh mục đã tồn tại");
        exit();
    }

    // Thêm danh mục mới
    $sql = "INSERT INTO danhmuc (ten_danhmuc) VALUES (:ten_danhmuc)";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_danhmuc' => $ten_danhmuc]);

    header("Location: manage_categories.php");
    exit();
}
?>