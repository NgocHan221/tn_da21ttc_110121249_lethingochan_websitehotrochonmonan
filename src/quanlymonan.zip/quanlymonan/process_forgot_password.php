<?php
session_start();
require_once 'connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reset_password'])) {
    if (!isset($_SESSION['reset_email']) || !isset($_SESSION['reset_sdt']) || !isset($_SESSION['reset_verified'])) {
        header("Location: forgot_password.php?error=Phiên xác nhận không hợp lệ");
        exit();
    }

    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $email = $_SESSION['reset_email'];
    $sdt = $_SESSION['reset_sdt'];

    // Kiểm tra mật khẩu khớp
    if ($password !== $confirm_password) {
        header("Location: forgot_password.php?show_password_form=1&error=Mật khẩu không khớp");
        exit();
    }

    // Kiểm tra độ dài mật khẩu
    if (strlen($password) < 6) {
        header("Location: forgot_password.php?show_password_form=1&error=Mật khẩu phải dài ít nhất 6 ký tự");
        exit();
    }

    try {
        // Cập nhật mật khẩu (không mã hóa)
        $sql = "UPDATE nguoidung SET mat_khau = :mat_khau WHERE email = :email AND sdt = :sdt";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            'mat_khau' => $password,
            'email' => $email,
            'sdt' => $sdt
        ]);

        // Xóa session
        unset($_SESSION['reset_email'], $_SESSION['reset_sdt'], $_SESSION['reset_verified']);
        header("Location: login.php?success=Mật khẩu đã được đặt lại, vui lòng đăng nhập");
        exit();
    } catch (PDOException $e) {
        error_log("Database error at " . date('Y-m-d H:i:s') . ": " . $e->getMessage());
        header("Location: forgot_password.php?show_password_form=1&error=Đã xảy ra lỗi, vui lòng thử lại sau");
        exit();
    }
} else {
    header("Location: forgot_password.php?error=Phương thức không hợp lệ");
    exit();
}
?>