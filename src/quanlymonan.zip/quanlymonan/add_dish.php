<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

$sql = "SELECT * FROM danhmuc ORDER BY ten_danhmuc";
$stmt = $conn->prepare($sql);
$stmt->execute();
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sql = "SELECT * FROM chedo ORDER BY ten_chedo";
$stmt = $conn->prepare($sql);
$stmt->execute();
$diets = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sql = "SELECT * FROM dinhduong ORDER BY ten_dinhduong";
$stmt = $conn->prepare($sql);
$stmt->execute();
$nutrients = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sql = "SELECT * FROM nguyenlieu ORDER BY ten_nguyenlieu";
$stmt = $conn->prepare($sql);
$stmt->execute();
$ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sql = "SELECT * FROM thanhphandinhduong ORDER BY ten_thanhphan";
$stmt = $conn->prepare($sql);
$stmt->execute();
$components = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Hàm chuẩn hóa ký tự tiếng Việt
function normalizeVietnameseChar($char) {
    $map = [
        'À' => 'A', 'Á' => 'A', 'Ạ' => 'A', 'Ả' => 'A', 'Ã' => 'A',
        'Ă' => 'Ă', 'Ằ' => 'Ă', 'Ắ' => 'Ă', 'Ặ' => 'Ă', 'Ẳ' => 'Ă', 'Ẵ' => 'Ă',
        'Â' => 'Â', 'Ầ' => 'Â', 'Ấ' => 'Â', 'Ậ' => 'Â', 'Ẩ' => 'Â', 'Ẫ' => 'Â',
        'Đ' => 'Đ',
        'È' => 'E', 'É' => 'E', 'Ẹ' => 'E', 'Ẻ' => 'E', 'Ẽ' => 'E',
        'Ê' => 'Ê', 'Ề' => 'Ê', 'Ế' => 'Ê', 'Ệ' => 'Ê', 'Ể' => 'Ê', 'Ễ' => 'Ê',
        'Ì' => 'I', 'Í' => 'I', 'Ị' => 'I', 'Ỉ' => 'I', 'Ĩ' => 'I',
        'Ò' => 'O', 'Ó' => 'O', 'Ọ' => 'O', 'Ỏ' => 'O', 'Õ' => 'O',
        'Ô' => 'Ô', 'Ồ' => 'Ô', 'Ố' => 'Ô', 'Ộ' => 'Ô', 'Ổ' => 'Ô', 'Ỗ' => 'Ô',
        'Ơ' => 'Ơ', 'Ờ' => 'Ơ', 'Ớ' => 'Ơ', 'Ợ' => 'Ơ', 'Ở' => 'Ơ', 'Ỡ' => 'Ơ',
        'Ù' => 'U', 'Ú' => 'U', 'Ụ' => 'U', 'Ủ' => 'U', 'Ũ' => 'U',
        'Ư' => 'Ư', 'Ừ' => 'Ư', 'Ứ' => 'Ư', 'Ự' => 'Ư', 'Ử' => 'Ư', 'Ữ' => 'Ư',
        'Ỳ' => 'Y', 'Ý' => 'Y', 'Ỵ' => 'Y', 'Ỷ' => 'Y', 'Ỹ' => 'Y'
    ];
    $char = mb_strtoupper($char, 'UTF-8');
    return $map[$char] ?? $char;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content=" inital-scale=1.0">
    <title>Thêm món ăn</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/froala-editor@latest/css/froala_editor.pkgd.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/froala-editor@latest/css/froala_style.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/froala-editor@latest/js/froala_editor.pkgd.min.js"></script>
    <style>
        .video-preview {
            margin-top: 1rem;
            display: none;
            justify-content: center;
        }
        .video-preview video {
            max-width: 100%;
            width: 512px;
            height: 256px;
            object-fit: cover;
            border-radius: 0.5rem;
        }
        .full-width-container {
            width: calc(100vw - 16rem); /* 16rem là chiều rộng của sidebar */
            max-width: none; /* Bỏ giới hạn chiều rộng tối đa */
        }
    </style>
    <script>
        function toggleIngredients() {
            const ingredientsSection = document.getElementById('ingredients-section');
            ingredientsSection.style.display = ingredientsSection.style.display === 'none' ? 'block' : 'none';
        }
        function toggleComponents() {
            const componentsSection = document.getElementById('components-section');
            componentsSection.style.display = componentsSection.style.display === 'none' ? 'block' : 'none';
        }
        function previewVideo(input) {
            const videoPreview = document.getElementById('video-preview');
            const video = videoPreview.querySelector('video');
            const file = input.files[0];
            if (file) {
                video.src = URL

        .createObjectURL(file);
                videoPreview.style.display = 'flex';
            } else {
                video.src = '';
                videoPreview.style.display = 'none';
            }
        }
    </script>
</head>
<body class="bg-gray-100 flex">
    <div class="w-64 bg-gray-800 text-white h-screen fixed top-0 left-0 p-4 text-xl">
        <h2 class="text-2xl font-bold mb-6">Quản trị viên</h2>
        <ul>
            <li class="mb-4"><a href="admin_dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-users mr-2"></i> Quản lý người dùng</a></li>
            <li class="mb-4"><a href="manage_categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-list mr-2"></i> Quản lý danh mục</a></li>
            <li class="mb-4"><a href="manage_diets.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-utensils mr-2"></i> Quản lý chế độ</a></li>
            <li class="mb-4"><a href="manage_ingredients.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-seedling mr-2"></i> Quản lý nguyên liệu</a></li>
            <li class="mb-4"><a href="manage_nutrients.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-heartbeat mr-2"></i> Quản lý dinh dưỡng</a></li>
            <li class="mb-4"><a href="manage_components.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-vial mr-2"></i> Quản lý thành phần dinh dưỡng</a></li>
            <li class="mb-4"><a href="manage_dishes.php" class="flex items-center p-2 bg-gray-700 rounded"><i class="fas fa-utensil-spoon mr-2"></i> Quản lý món ăn</a></li>
            <li class="mb-4"><a href="admin_feedback.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-comments mr-2"></i> Quản lý phản hồi</a></li>
            <li class="mb-4"><a href="manage_preservation.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-leaf mr-2"></i> Quản lý chi tiết dinh dưỡng</a></li>
            <li><a href="logout.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-sign-out-alt mr-2"></i> Đăng xuất</a></li>
        </ul>
    </div>
    <div class="ml-64 p-6 w-full">
        <div class="full-width-container mx-auto bg-white p-8 rounded-lg shadow-lg">
            <h2 class="text-2xl font-bold mb-8 text-center">Thêm món ăn</h2>
            <?php if (isset($_GET['error'])): ?>
                <p class="text-red-500 mb-4"><?php echo htmlspecialchars($_GET['error']); ?></p>
            <?php endif; ?>
            <form action="process_add_dish.php" method="POST" enctype="multipart/form-data" class="space-y-6">
                <div>
                    <label class="block text-gray-700">Tên món ăn</label>
                    <input type="text" name="ten_monan" class="w-full p-3 border rounded-lg" required>
                </div>
                <div>
                    <label class="block text-gray-700">Hình ảnh</label>
                    <input type="file" name="hinh_anh" class="w-full p-3 border rounded-lg" accept="image/*">
                </div>
                <div>
                    <label class="block text-gray-700">Video</label>
                    <input type="file" name="video" class="w-full p-3 border rounded-lg" accept="video/*" onchange="previewVideo(this)">
                    <div id="video-preview" class="video-preview">
                        <video controls>
                            <source src="" type="video/mp4">
                            Trình duyệt của bạn không hỗ trợ video.
                        </video>
                    </div>
                </div>
                <div>
                    <label class="block text-gray-700">Khẩu phần (số người)</label>
                    <input type="number" name="khau_phan" class="w-full p-3 border rounded-lg" required min="1">
                </div>
                <div>
                    <label class="block text-gray-700">Độ khó</label>
                    <select name="do_kho" class="w-full p-3 border rounded-lg" required>
                        <option value="dễ">Dễ</option>
                        <option value="trung bình">Trung bình</option>
                        <option value="khó">Khó</option>
                    </select>
                </div>
                <div>
                    <label class="block text-gray-700">Calo</label>
                    <input type="number" name="calo" class="w-full p-3 border rounded-lg" required min="0">
                </div>
                <div>
                    <label class="block text-gray-700">Danh mục</label>
                    <div class="mt-2 space-y-2">
                        <?php foreach ($categories as $category): ?>
                            <div class="flex items-center">
                                <input type="checkbox" name="categories[<?php echo $category['ma_danhmuc']; ?>]" value="1" class="mr-2">
                                <label><?php echo htmlspecialchars($category['ten_danhmuc']); ?></label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div>
                    <label class="block text-gray-700">Chế độ</label>
                    <select name="ma_chedo" class="w-full p-3 border rounded-lg">
                        <option value="">Chọn chế độ</option>
                        <?php foreach ($diets as $diet): ?>
                            <option value="<?php echo $diet['ma_chedo']; ?>"><?php echo htmlspecialchars($diet['ten_chedo']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-gray-700">Dinh dưỡng</label>
                    <select name="ma_dinhduong" class="w-full p-3 border rounded-lg">
                        <option value="">Chọn dinh dưỡng</option>
                        <?php foreach ($nutrients as $nutrient): ?>
                            <option value="<?php echo $nutrient['ma_dinhduong']; ?>"><?php echo htmlspecialchars($nutrient['ten_dinhduong']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <button type="button" onclick="toggleIngredients()" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Thêm nguyên liệu</button>
                    <div id="ingredients-section" style="display:none;" class="mt-4">
                        <?php
                        $vietnamese_alphabet = ['A', 'Ă', 'Â', 'B', 'C', 'D', 'Đ', 'E', 'Ê', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'O', 'Ô', 'Ơ', 'P', 'Q', 'R', 'S', 'T', 'U', 'Ư', 'V', 'X', 'Y'];
                        foreach ($vietnamese_alphabet as $letter):
                        ?>
                            <div class="mb-4">
                                <h3 class="text-lg font-semibold"><?php echo $letter; ?></h3>
                                <div class="grid grid-cols-3 gap-4">
                                    <?php foreach ($ingredients as $ingredient): ?>
                                        <?php
                                        $first_char = normalizeVietnameseChar(mb_substr($ingredient['ten_nguyenlieu'], 0, 1, 'UTF-8'));
                                        if ($first_char == $letter):
                                        ?>
                                            <div class="flex items-center flex-col">
                                                <div class="flex items-center w-full">
                                                    <input type="checkbox" name="ingredients[<?php echo $ingredient['ma_nguyenlieu']; ?>][selected]" value="1" class="mr-2">
                                                    <label><?php echo htmlspecialchars($ingredient['ten_nguyenlieu']); ?></label>
                                                </div>
                                                <input type="text" name="ingredients[<?php echo $ingredient['ma_nguyenlieu']; ?>][thaythe]" class="w-full p-1 mt-1 border rounded" placeholder="Nguyên liệu thay thế (nếu có)">
                                                <input type="number" step="0.1" name="ingredients[<?php echo $ingredient['ma_nguyenlieu']; ?>][so_gram]" class="w-full p-1 mt-1 border rounded" placeholder="Số gram" min="0">
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div>
                    <label class="block text-gray-700">Ghi chú</label>
                    <textarea name="ghi_chu" class="w-full p-3 border rounded-lg" rows="4" placeholder="Nhập ghi chú (nếu có)"></textarea>
                </div>
                <div>
                    <label class="block text-gray-700">Công thức</label>
                    <textarea name="cong_thuc" id="froala-editor"></textarea>
                </div>
                <div>
                    <button type="button" onclick="toggleComponents()" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Thêm thành phần dinh dưỡng</button>
                    <div id="components-section" style="display:none;" class="mt-4">
                        <?php foreach ($components as $component): ?>
                            <div class="flex items-center mb-1">
                                <input type="checkbox" name="components[<?php echo $component['ma_thanhphan']; ?>][selected]" value="1" class="mr-2">
                                <label><?php echo htmlspecialchars($component['ten_thanhphan']); ?> (Lượng: <input type="number" step="0.001" name="components[<?php echo $component['ma_thanhphan']; ?>][phantram]" class="w-20 p-1 border rounded" min="0">) g</label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <button type="submit" class="w-full bg-blue-500 text-white p-3 rounded-lg hover:bg-blue-600">Thêm món ăn</button>
            </form>
            <p class="mt-4 text-center"><a href="manage_dishes.php" class="text-blue-500">Quay lại</a></p>
        </div>
    </div>
    <script>
        new FroalaEditor('#froala-editor', {
            height: 300,
            toolbarButtons: {
                moreText: {
                    buttons: ['bold', 'italic', 'underline', 'strikeThrough', 'subscript', 'superscript', 'fontFamily', 'fontSize', 'textColor', 'backgroundColor', 'inlineClass', 'inlineStyle', 'clearFormatting']
                },
                moreParagraph: {
                    buttons: ['alignLeft', 'alignCenter', 'formatOLSimple', 'alignRight', 'alignJustify', 'formatOL', 'formatUL', 'paragraphFormat', 'paragraphStyle', 'lineHeight', 'outdent', 'indent', 'quote']
                },
                moreRich: {
                    buttons: ['insertLink', 'insertImage', 'insertVideo', 'insertTable', 'emoticons', 'fontAwesome', 'specialCharacters', 'embedly', 'insertFile', 'insertHR']
                },
                moreMisc: {
                    buttons: ['undo', 'redo', 'fullscreen', 'print', 'getPDF', 'spellChecker', 'selectAll', 'html', 'help']
                }
            },
            imageResize: true,
            imageEditButtons: ['imageReplace', 'imageAlign', 'imageRemove', '|', 'imageLink', 'linkOpen', 'linkEdit', 'linkRemove', '-', 'imageDisplay', 'imageStyle', 'imageAlt', 'imageSize'],
            quickInsertButtons: ['image', 'table', 'ul', 'ol', 'hr'],
            imageUploadURL: 'upload_image.php',
            imageUploadMethod: 'POST',
            imageAllowedTypes: ['jpeg', 'jpg', 'png', 'gif']
        });
    </script>
</body>
</html>