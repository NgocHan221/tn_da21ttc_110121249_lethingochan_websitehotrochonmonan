<?php
session_start();
require_once 'connect.php';

// Bật hiển thị lỗi để debug (xóa khi triển khai chính thức)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Debug: Log session data
if (isset($_SESSION['user_id'])) {
    error_log("Session data on suggest_dishes.php at " . date('Y-m-d H:i:s') . ": " . print_r($_SESSION, true));
}

$search_query = isset($_POST['search_query']) ? trim($_POST['search_query']) : '';
$dishes = [];
$categories_per_dish = [];
$error_message = '';
$popular_searches = [];

function extractIngredients($query) {
    try {
        // Loại bỏ các từ khóa không cần thiết và tách nguyên liệu
        $stopWords = ['mình', 'có', 'nguyên liệu', 'bạn', 'có thể', 'giúp', 'nấu', 'món', 'gì', 'không', '?', '!', '.', 'và', 'thì', 'ăn', 'với'];
        $query = strtolower(trim($query));
        // Thay dấu phẩy bằng khoảng trắng để xử lý các trường hợp nhập liệu
        $query = str_replace(',', ' ', $query);
        foreach ($stopWords as $word) {
            $query = str_replace(" $word ", ' ', $query);
        }
        // Tách chuỗi thành mảng, loại bỏ khoảng trắng thừa và các phần tử rỗng
        $ingredients = array_filter(array_map('trim', explode(' ', preg_replace('/\s+/', ' ', $query))));
        return $ingredients;
    } catch (Exception $e) {
        error_log("Error in extractIngredients: " . $e->getMessage());
        return [];
    }
}

// Lấy tìm kiếm phổ biến từ bảng search_history
try {
    $sql = "SELECT search_query FROM search_history ORDER BY search_count DESC, last_searched DESC LIMIT 4";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Prepare statement for popular searches failed: " . $conn->error);
    }
    $stmt->execute();
    $popular_searches = $stmt->fetchAll(PDO::FETCH_COLUMN);
    if (empty($popular_searches)) {
        $popular_searches = [
            'gà, cà chua, khoai tây',
            'thịt bò, hành tây',
            'cá, rau muống',
            'tôm, mướp'
        ];
    }
} catch (Exception $e) {
    error_log("Error fetching popular searches: " . $e->getMessage());
    $popular_searches = [
        'gà, cà chua, khoai tây',
        'thịt bò, hành tây',
        'cá, rau muống',
        'tôm, mướp'
    ];
}

if ($search_query) {
    try {
        // Trích xuất nguyên liệu từ câu hỏi
        $ingredients = extractIngredients($search_query);
        
        if (!empty($ingredients)) {
            // Lưu tìm kiếm vào bảng search_history
            $search_string = implode(', ', $ingredients);
            $sql = "INSERT INTO search_history (search_query, search_count) 
                    VALUES (:search_query, 1) 
                    ON DUPLICATE KEY UPDATE search_count = search_count + 1, last_searched = CURRENT_TIMESTAMP";
            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                throw new Exception("Prepare statement for saving search failed: " . $conn->error);
            }
            $stmt->execute(['search_query' => $search_string]);

            // Chuẩn bị câu truy vấn SQL với các placeholder
            $placeholders = implode(' OR nl.ten_nguyenlieu LIKE ', array_fill(0, count($ingredients), '?'));
            $sql = "SELECT DISTINCT m.*, c.ten_chedo 
                    FROM monan m 
                    LEFT JOIN chedo c ON m.ma_chedo = c.ma_chedo 
                    JOIN monan_nguyenlieu mn ON m.ma_monan = mn.ma_monan 
                    JOIN nguyenlieu nl ON mn.ma_nguyenlieu = nl.ma_nguyenlieu 
                    WHERE nl.ten_nguyenlieu LIKE $placeholders";
            
            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                throw new Exception("Prepare statement failed: " . $conn->error);
            }
            
            // Thêm ký tự % vào các nguyên liệu để tìm kiếm LIKE
            $search_params = array_map(function($item) {
                return '%' . $item . '%';
            }, $ingredients);
            if (!$stmt->execute($search_params)) {
                throw new Exception("Execute statement failed: " . $stmt->error);
            }
            
            $dishes = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Lấy danh mục cho từng món ăn từ bảng monan_danhmuc
            foreach ($dishes as $dish) {
                $sql = "SELECT d.ten_danhmuc 
                        FROM monan_danhmuc md 
                        JOIN danhmuc d ON md.ma_danhmuc = d.ma_danhmuc 
                        WHERE md.ma_monan = :ma_monan";
                $stmt = $conn->prepare($sql);
                if (!$stmt) {
                    error_log("Prepare statement for categories failed: " . $conn->error);
                    continue;
                }
                $stmt->execute(['ma_monan' => $dish['ma_monan']]);
                $categories_per_dish[$dish['ma_monan']] = $stmt->fetchAll(PDO::FETCH_COLUMN);
            }
        } else {
            $error_message = "Không thể trích xuất nguyên liệu từ câu hỏi.";
        }
    } catch (Exception $e) {
        $error_message = "Lỗi khi tìm kiếm món ăn: " . $e->getMessage();
        error_log($error_message);
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gợi ý món ăn</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .search-bar {
            padding: 1.5rem;
            transition: all 0.3s ease;
        }
        .search-bar form {
            position: relative;
            width: 100%;
        }
        .search-bar .input-wrapper {
            position: relative;
            width: 100%;
        }
        .search-bar input {
            padding: 0.75rem 2.5rem 0.75rem 2.5rem;
            border-radius: 9999px;
            border: 2px solid #e5e7eb;
            width: 100%;
            font-size: 0.875rem;
            background-color: #f9fafb;
            transition: border-color 0.3s ease, box-shadow 0.3s ease, background-color 0.3s ease;
        }
        .search-bar input:focus {
            border-color: #3b82f6;
            background-color: #ffffff;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
            outline: none;
        }
        .search-bar .search-icon {
            position: absolute;
            left: 0.75rem;
            top: 50%;
            transform: translateY(-50%);
            color: #6b7280;
            font-size: 1rem;
            pointer-events: none;
            transition: color 0.3s ease;
        }
        .search-bar input:focus + .search-icon {
            color: #3b82f6;
        }
        .search-bar .clear-btn {
            position: absolute;
            right: 0.75rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #6b7280;
            font-size: 1rem;
            cursor: pointer;
            display: none;
            transition: color 0.3s ease;
        }
        .search-bar .clear-btn:hover {
            color: #3b82f6;
        }
        .search-bar .clear-btn.show {
            display: block;
        }
        .dish-card {
            background: linear-gradient(145deg, #ffffff, #f9fafb);
            border: 1px solid #e5e7eb;
            border-radius: 0.75rem;
            padding: 0.75rem;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            overflow: hidden;
        }
        .dish-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
        }
        .dish-card img {
            width: 100%;
            height: 192px;
            object-fit: cover;
            border-radius: 0.5rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .dish-card:hover img {
            transform: scale(1.05);
        }
        .dish-card h3 {
            font-size: 1rem;
            font-weight: 700;
            color: #1f2937;
            margin: 0.5rem 0;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .dish-card p {
            font-size: 0.75rem;
            color: #4b5563;
            margin: 0.25rem 0;
            text-align: center;
        }
        .dish-card .calo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.25rem;
            font-weight: 600;
            color: #3b82f6;
        }
        .dish-card a {
            display: block;
            text-align: center;
            font-size: 0.75rem;
            font-weight: 500;
            color: white;
            background: linear-gradient(to right, #3b82f6, #2563eb);
            padding: 0.5rem 0;
            border-radius: 0.375rem;
            margin: 0.5rem 0 0;
            transition: background 0.3s ease, transform 0.2s ease;
        }
        .dish-card a:hover {
            background: linear-gradient(to right, #2563eb, #1d4ed8);
            transform: scale(1.02);
        }
        /* Navbar styles */
        .navbar {
            background: linear-gradient(145deg, #4f46e5, #10b981);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 50;
        }
        .navbar-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        .nav-menu {
            display: flex;
            gap: 0.75rem;
            align-items: center;
        }
        .nav-menu a {
            color: #e5e7eb;
            font-size: 1rem;
            font-weight: 500;
            text-decoration: none;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            transition: background-color 0.3s ease, color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }
        .nav-menu a:hover {
            background-color: #6b7280;
            color: #ffffff;
        }
        .nav-user-section {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .user-dropdown {
            position: relative;
        }
        .user-button {
            color: #e5e7eb;
            font-size: 1rem;
            font-weight: 500;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            background: transparent;
            transition: background-color 0.3s ease, color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }
        .user-button:hover {
            background-color: #6b7280;
            color: #ffffff;
        }
        .user-dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: #ffffff;
            border-radius: 0.375rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            min-width: 160px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: opacity 0.3s ease, transform 0.3s ease, visibility 0.3s ease;
            z-index: 100;
        }
        .user-dropdown:hover .user-dropdown-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        .user-dropdown-menu a {
            display: block;
            padding: 0.5rem 1rem;
            color: #1f2937;
            font-size: 0.875rem;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .user-dropdown-menu a:hover {
            background-color: #f3f4f6;
        }
        .logout-link {
            color: white;
            font-size: 1rem;
            font-weight: 500;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            text-decoration: none;
            transition: background 0.3s ease, transform 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }
        .logout-link:hover {
            background: linear-gradient(to right, #2563eb, #1d4ed8);
            transform: scale(1.02);
        }
        .hamburger {
            display: none;
            flex-direction: column;
            cursor: pointer;
            gap: 0.25rem;
        }
        .hamburger span {
            width: 24px;
            height: 3px;
            background: #e5e7eb;
            border-radius: 2px;
            transition: all 0.3s ease;
        }
        .hamburger.active span:nth-child(1) {
            transform: rotate(45deg) translate(5px, 5px);
        }
        .hamburger.active span:nth-child(2) {
            opacity: 0;
        }
        .hamburger.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -7px);
        }
        /* Responsive styles */
        @media (max-width: 767px) {
            .navbar-container {
                flex-wrap: wrap;
            }
            .nav-menu {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: #4f46e5;
                flex-direction: column;
                padding: 1rem;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }
            .nav-menu.active {
                display: flex;
            }
            .nav-menu a {
                padding: 0.75rem;
                width: 100%;
                text-align: left;
                font-size: 1rem;
            }
            .nav-user-section {
                display: none;
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
                padding: 1rem;
                width: 100%;
            }
            .nav-user-section.active {
                display: flex;
            }
            .user-dropdown {
                width: 100%;
            }
            .user-dropdown-menu {
                position: static;
                background: #6b7280;
                box-shadow: none;
                transform: none;
                opacity: 1;
                visibility: visible;
                margin-top: 0.5rem;
                width: 100%;
            }
            .user-dropdown-menu a {
                color: #e5e7eb;
            }
            .user-dropdown-menu a:hover {
                background-color: #4b5563;
            }
            .logout-link {
                width: 100%;
                text-align: left;
                color: white;
            }
            .logout-link:hover {
                color: white;
            }
            .hamburger {
                display: flex;
            }
        }
        /* Footer styles */
        footer {
            background: linear-gradient(145deg, #1f2937, #111827);
            color: #f3f4f6;
            padding: 2rem 0;
            margin-top: 2rem;
            border-top: 1px solid #374151;
            width: 100%;
        }
        footer .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1.5rem;
        }
        footer .footer-links {
            display: flex;
            gap: 1.5rem;
        }
        footer .footer-links a {
            color: #d1d5db;
            font-size: 1.25rem;
            transition: color 0.3s ease;
        }
        footer .footer-links a:hover {
            color: #3b82f6;
        }
        footer .footer-info {
            font-size: 1.25rem;
            color: #9ca3af;
            text-align: center;
        }
        footer .footer-social {
            display: flex;
            gap: 1rem;
        }
        footer .footer-social a {
            color: #d1d5db;
            font-size: 1.25rem;
            transition: color 0.3s ease;
        }
        footer .footer-social a:hover {
            color: #3b82f6;
        }
        @media (max-width: 640px) {
            footer .footer-links {
                flex-direction: column;
                align-items: center;
                gap: 0.75rem;
            }
        }
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .container.mx-auto.p-6 {
            flex: 1;
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Thanh menu ngang phía trên -->
    <nav class="navbar">
        <div class="navbar-container">
            <div class="hamburger" id="hamburger" role="button" aria-label="Toggle navigation" aria-expanded="false">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="flex items-center gap-4">
                <div class="nav-menu" id="nav-menu">
                    <a href="index.php"><i class="fas fa-home"></i> Trang chủ</a>
                    <a href="nutrients.php"><i class="fas fa-seedling"></i> Dinh dưỡng</a>
                    <a href="suggest_dishes.php"><i class="fas fa-utensils"></i> Gợi ý theo nguyên liệu</a>
                    <a href="favorites.php"><i class="fas fa-heart"></i> Món ăn yêu thích</a>
                    <a href="menu.php"><i class="fas fa-calendar-alt"></i> Thực đơn</a>
                    <a href="nutrition_chart.php"><i class="fas fa-chart-bar"></i> Biểu đồ dinh dưỡng</a>
                </div>
                <div class="nav-user-section" id="nav-user-section">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <div class="user-dropdown">
                            <button class="user-button">
                                <i class="fas fa-user mr-2"></i>
                                <span><?php echo htmlspecialchars(isset($_SESSION['ten_dangnhap']) && !empty($_SESSION['ten_dangnhap']) ? $_SESSION['ten_dangnhap'] : 'Người dùng'); ?></span>
                            </button>
                            <div class="user-dropdown-menu">
                                <a href="profile.php">Hồ sơ</a>
                            </div>
                        </div>
                        <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt mr-2"></i>Đăng xuất</a>
                    <?php else: ?>
                        <a href="login.php" class="user-button">
                            <i class="fas fa-sign-in-alt mr-2"></i> Đăng nhập
                        </a>
                        <a href="register.php" class="user-button">
                            <i class="fas fa-user-plus mr-2"></i> Đăng ký
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Nội dung chính -->
    <div class="container mx-auto p-6">
        <h2 class="text-2xl font-bold mb-6 text-center">Gợi ý món ăn</h2>
        <!-- Thanh tìm kiếm -->
        <div class="search-bar mb-8">
            <form method="POST" id="search-form">
                <div class="input-wrapper">
                    <input type="text" name="search_query" id="search-input" placeholder="Nhập nguyên liệu hoặc câu hỏi (ví dụ: Mình có gà, cà chua, bạn có thể nấu món gì không?)" value="<?php echo htmlspecialchars($search_query); ?>">
                    <i class="fas fa-search search-icon"></i>
                    <button type="button" class="clear-btn" id="clear-btn">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </form>
        </div>

        <!-- Tìm kiếm phổ biến -->
        <div class="popular-searches mt-4 text-center">
            <h3 class="text-lg font-semibold text-gray-700 mb-2">Tìm kiếm phổ biến</h3>
            <div class="flex flex-wrap justify-center gap-2">
                <?php foreach ($popular_searches as $search): ?>
                    <button class="popular-search-btn bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm hover:bg-blue-200 transition-colors" data-search="<?php echo htmlspecialchars($search); ?>">
                        <?php echo htmlspecialchars($search); ?>
                    </button>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Thông báo lỗi -->
        <?php if ($error_message): ?>
            <p class="text-center text-red-500 mb-4"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>

        <!-- Kết quả tìm kiếm -->
        <?php if ($search_query): ?>
            <?php if (!empty($dishes)): ?>
                <p class="text-center text-green-500 mb-4">Gợi ý một số món ăn phù hợp với nguyên liệu trên:</p>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <?php foreach ($dishes as $dish): ?>
                        <div class="dish-card">
                            <img src="<?php echo htmlspecialchars($dish['hinh_anh'] ?? 'https://via.placeholder.com/300x192'); ?>" alt="<?php echo htmlspecialchars($dish['ten_monan']); ?>" class="w-full h-48 object-cover">
                            <h3><?php echo htmlspecialchars($dish['ten_monan']); ?></h3>
                            <p class="calo"><i class="fas fa-fire-alt text-xs"></i> <?php echo htmlspecialchars($dish['calo'] ?? 'N/A'); ?> kcal</p>
                            <p>Chế độ: <?php echo htmlspecialchars($dish['ten_chedo'] ?? 'Chưa có'); ?></p>
                            <p>Danh mục: <?php echo htmlspecialchars(!empty($categories_per_dish[$dish['ma_monan']]) ? implode(', ', $categories_per_dish[$dish['ma_monan']]) : 'Chưa có'); ?></p>
                            <a href="detail.php?id=<?php echo $dish['ma_monan']; ?>">Xem chi tiết</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="text-center text-red-500 mb-4">Chưa tìm thấy món ăn với những nguyên liệu trên.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <footer>
        <div class="container mx-auto">
            <div class="footer-links">
                <a href="index.php">Trang chủ</a>
                <a href="nutrients.php">Dinh dưỡng</a>
                <a href="suggest_dishes.php">Gợi ý theo nguyên liệu</a>
                <a href="favorites.php">Món ăn yêu thích</a>
                <a href="menu.php">Thực đơn</a>
                <a href="nutrition_chart.php">Biểu đồ dinh dưỡng</a>
            </div>
            <div class="footer-social">
                <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
            </div>
            <div class="footer-info">
                <p>Liên hệ qua email: <a href="mailto:support@foodsuggestion.com" class="hover:text-blue-500">lethingochan227tv@gmail.com</a></p>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const searchInput = document.getElementById('search-input');
            const clearBtn = document.getElementById('clear-btn');
            const searchForm = document.getElementById('search-form');

            // Toggle clear button visibility
            searchInput.addEventListener('input', function () {
                clearBtn.classList.toggle('show', searchInput.value.length > 0);
            });

            // Clear input and submit form
            clearBtn.addEventListener('click', function () {
                searchInput.value = '';
                clearBtn.classList.remove('show');
                searchForm.submit();
            });

            // Initialize button state on page load
            if (searchInput.value.length > 0) {
                clearBtn.classList.add('show');
            }

            // Xử lý nhấp vào nút tìm kiếm phổ biến
            document.querySelectorAll('.popular-search-btn').forEach(button => {
                button.addEventListener('click', function () {
                    searchInput.value = this.getAttribute('data-search');
                    clearBtn.classList.add('show');
                    searchForm.submit();
                });
            });

            // Xử lý hamburger menu
            const hamburger = document.getElementById('hamburger');
            const navMenu = document.getElementById('nav-menu');
            const navUserSection = document.getElementById('nav-user-section');

            hamburger.addEventListener('click', function () {
                const isActive = hamburger.classList.toggle('active');
                hamburger.setAttribute('aria-expanded', isActive);
                navMenu.classList.toggle('active');
                navUserSection.classList.toggle('active');
            });

            // Đóng menu khi click vào link trên mobile
            document.querySelectorAll('.nav-menu a, .nav-user-section a').forEach(link => {
                link.addEventListener('click', function () {
                    if (window.innerWidth <= 767) {
                        hamburger.classList.remove('active');
                        hamburger.setAttribute('aria-expanded', 'false');
                        navMenu.classList.remove('active');
                        navUserSection.classList.remove('active');
                    }
                });
            });
        });
    </script>
</body>
</html>