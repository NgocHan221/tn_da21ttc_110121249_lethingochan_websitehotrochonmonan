<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

$sql = "SELECT * FROM dinhduong ORDER BY ten_dinhduong";
$stmt = $conn->prepare($sql);
$stmt->execute();
$nutrients = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý dinh dưỡng</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex">
    <!-- Menu dọc bên trái -->
    <div class="w-96 bg-gray-800 text-white h-screen fixed top-0 left-0 p-4 text-xl">
        <h2 class="text-3xl font-bold mb-6">Quản trị viên</h2>
        <ul>
            <li class="mb-4"><a href="admin_dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-users mr-2"></i> Quản lý người dùng</a></li>
            <li class="mb-4"><a href="manage_categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-list mr-2"></i> Quản lý danh mục</a></li>
            <li class="mb-4"><a href="manage_diets.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-utensils mr-2"></i> Quản lý chế độ</a></li>
            <li class="mb-4"><a href="manage_ingredients.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-seedling mr-2"></i> Quản lý nguyên liệu</a></li>
            <li class="mb-4"><a href="manage_nutrients.php" class="flex items-center p-2 bg-gray-700 rounded"><i class="fas fa-heartbeat mr-2"></i> Quản lý dinh dưỡng</a></li>
            <li class="mb-4"><a href="manage_components.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-vial mr-2"></i> Quản lý thành phần dinh dưỡng</a></li>
            <li class="mb-4"><a href="manage_dishes.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-utensil-spoon mr-2"></i> Quản lý món ăn</a></li>
            <li class="mb-4"><a href="admin_feedback.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-comments mr-2"></i> Quản lý phản hồi</a></li>
            <li class="mb-4"><a href="manage_preservation.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-leaf mr-2"></i> Quản lý chi tiết dinh dưỡng</a></li>
            <li><a href="logout.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-sign-out-alt mr-2"></i> Đăng xuất</a></li>
        </ul>
    </div>
    <!-- Nội dung chính -->
    <div class="ml-96 p-6 w-full">
        <div class="max-w-6xl mx-auto bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl font-bold mb-6 text-center">Danh sách dinh dưỡng</h2>
            <?php if (isset($_GET['success'])): ?>
                <p class="text-green-500 mb-4"><?php echo htmlspecialchars($_GET['success']); ?></p>
            <?php endif; ?>
            <?php if (isset($_GET['error'])): ?>
                <p class="text-red-500 mb-4"><?php echo htmlspecialchars($_GET['error']); ?></p>
            <?php endif; ?>
            <div class="mb-4 flex justify-between">
                <a href="add_nutrient.php" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"><i class="fas fa-plus"></i> Thêm dinh dưỡng</a>
            </div>
            <table class="w-full border-collapse border border-gray-300 rounded">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="border p-3 text-center">Mã dinh dưỡng</th>
                        <th class="border p-3 text-center">Tên dinh dưỡng</th>
                        <th class="border p-3 text-center">Hình ảnh</th>
                        <th class="border p-3 text-center">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($nutrients)): ?>
                        <tr>
                            <td colspan="4" class="border p-3 text-center text-gray-500">Không có dữ liệu</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($nutrients as $nutrient): ?>
                            <tr class="hover:bg-gray-50 even:bg-gray-50">
                                <td class="border p-3 text-center"><?php echo htmlspecialchars($nutrient['ma_dinhduong']); ?></td>
                                <td class="border p-3"><?php echo htmlspecialchars($nutrient['ten_dinhduong']); ?></td>
                                <td class="border p-3 text-center">
                                    <?php if ($nutrient['hinh_anh']): ?>
                                        <img src="<?php echo htmlspecialchars($nutrient['hinh_anh']); ?>" alt="Hình ảnh" class="w-16 h-16 object-cover rounded">
                                    <?php else: ?>
                                        <span class="text-gray-500">Không có hình</span>
                                    <?php endif; ?>
                                </td>
                                <td class="border p-3 flex justify-center gap-2">
                                    <a href="edit_nutrient.php?id=<?php echo $nutrient['ma_dinhduong']; ?>" class="bg-yellow-400 hover:bg-yellow-500 text-white px-3 py-1 rounded shadow transition duration-200">
                                        <i class="fas fa-edit"></i> Sửa
                                    </a>
                                    <a href="delete_nutrient.php?id=<?php echo $nutrient['ma_dinhduong']; ?>" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded shadow transition duration-200" onclick="return confirm('Bạn có chắc chắn muốn xóa?')">
                                        <i class="fas fa-trash-alt"></i> Xóa
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
