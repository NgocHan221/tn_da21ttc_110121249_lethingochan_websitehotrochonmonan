<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: manage_preservation.php?error=ID không hợp lệ");
    exit();
}
$preservation_id = (int)$_GET['id'];

try {
    // Lấy dữ liệu bài viết bảo quản
    $sql = "SELECT p.id, p.dish_id, p.content, p.ghi_chu, m.ten_monan 
            FROM preservation p 
            JOIN monan m ON p.dish_id = m.ma_monan 
            WHERE p.id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $preservation_id]);
    $preservation = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$preservation) {
        header("Location: manage_preservation.php?error=Bài viết không tồn tại");
        exit();
    }

    // Lấy danh sách món ăn
    $sql = "SELECT ma_monan, ten_monan FROM monan ORDER BY ten_monan";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $dishes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Lấy thực đơn gợi ý
    $sql = "SELECT meal, calories, dishes 
            FROM menu_suggestions 
            WHERE preservation_id = :preservation_id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['preservation_id' => $preservation_id]);
    $menu_suggestions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Tổ chức thực đơn gợi ý theo bữa
    $menu_data = ['Bữa sáng' => ['calories' => '', 'dishes' => []], 
                  'Bữa trưa' => ['calories' => '', 'dishes' => []], 
                  'Bữa tối' => ['calories' => '', 'dishes' => []]];
    foreach ($menu_suggestions as $suggestion) {
        $menu_data[$suggestion['meal']]['calories'] = $suggestion['calories'];
        $menu_data[$suggestion['meal']]['dishes'] = json_decode($suggestion['dishes'], true) ?? [];
    }
} catch (PDOException $e) {
    error_log("Lỗi truy vấn: " . $e->getMessage());
    header("Location: manage_preservation.php?error=Lỗi truy vấn dữ liệu");
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa bài viết bảo quản - <?php echo htmlspecialchars($preservation['ten_monan']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/froala-editor@latest/css/froala_editor.pkgd.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/froala-editor@latest/css/froala_style.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/froala-editor@latest/js/froala_editor.pkgd.min.js"></script>
    <script>
        function addDish(meal) {
            const container = document.getElementById(`dishes-${meal}`);
            const dishDiv = document.createElement('div');
            dishDiv.className = 'mb-2';
            dishDiv.innerHTML = `
                <input type="text" name="menu[${meal}][dishes][]" class="w-full p-2 border rounded-lg" placeholder="Nhập tên món ăn">
            `;
            container.appendChild(dishDiv);
        }
    </script>
</head>
<body class="bg-gray-100 flex">
    <!-- Sidebar -->
    <div class="w-96 bg-gray-800 text-white h-screen fixed top-0 left-0 p-4 text-xl">
        <h2 class="text-3xl font-bold mb-6">Quản trị viên</h2>
        <ul>
            <li class="mb-4"><a href="admin_dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-users mr-2"></i> Quản lý người dùng</a></li>
            <li class="mb-4"><a href="manage_categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-list mr-2"></i> Quản lý danh mục</a></li>
            <li class="mb-4"><a href="manage_diets.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-utensils mr-2"></i> Quản lý chế độ</a></li>
            <li class="mb-4"><a href="manage_ingredients.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-seedling mr-2"></i> Quản lý nguyên liệu</a></li>
            <li class="mb-4"><a href="manage_nutrients.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-heartbeat mr-2"></i> Quản lý dinh dưỡng</a></li>
            <li class="mb-4"><a href="manage_components.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-vial mr-2"></i> Quản lý thành phần dinh dưỡng</a></li>
            <li class="mb-4"><a href="manage_dishes.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-utensil-spoon mr-2"></i> Quản lý món ăn</a></li>
            <li class="mb-4"><a href="admin_feedback.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-comments mr-2"></i> Quản lý phản hồi</a></li>
            <li class="mb-4"><a href="manage_preservation.php" class="flex items-center p-2 bg-gray-700 rounded"><i class="fas fa-leaf mr-2"></i> Quản lý chi tiết dinh dưỡng</a></li>
            <li><a href="logout.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-sign-out-alt mr-2"></i> Đăng xuất</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="ml-96 p-6 w-[calc(100%-24rem)]">
        <div class="bg-white p-8 rounded-lg shadow-lg">
            <h2 class="text-3xl font-bold mb-8 text-center">Sửa bài viết dinh dưỡng</h2>
            <?php if (isset($_GET['error'])): ?>
                <p class="text-red-500 mb-4"><?php echo htmlspecialchars($_GET['error']); ?></p>
            <?php endif; ?>
            <form action="process_edit_preservation.php" method="POST" class="space-y-6">
                <input type="hidden" name="preservation_id" value="<?php echo htmlspecialchars($preservation['id']); ?>">
                <div>
                    <label class="block text-gray-700">Món ăn</label>
                    <select name="dish_id" class="w-full p-3 border rounded-lg" required>
                        <option value="">Chọn món ăn</option>
                        <?php foreach ($dishes as $dish): ?>
                            <option value="<?php echo $dish['ma_monan']; ?>" <?php echo $preservation['dish_id'] == $dish['ma_monan'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($dish['ten_monan']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-gray-700">Nội dung dinh dưỡng</label>
                    <textarea name="content" id="froala-editor"><?php echo htmlspecialchars($preservation['content']); ?></textarea>
                </div>
                <div>
                    <label class="block text-gray-700">Ghi chú</label>
                    <textarea name="ghi_chu" class="w-full p-3 border rounded-lg" rows="4" placeholder="Nhập ghi chú (tùy chọn)"><?php echo htmlspecialchars($preservation['ghi_chu'] ?? ''); ?></textarea>
                </div>
                <div>
                    <h3 class="text-lg font-semibold">Thực đơn gợi ý (tùy chọn)</h3>
                    <?php
                    $meals = ['Bữa sáng', 'Bữa trưa', 'Bữa tối'];
                    foreach ($meals as $meal): ?>
                        <div class="mt-4">
                            <label class="block text-gray-700"><?php echo $meal; ?></label>
                            <div class="mt-2">
                                <input type="number" name="menu[<?php echo $meal; ?>][calories]" class="w-full p-2 border rounded-lg mb-2" placeholder="Năng lượng (kcal)" min="0" value="<?php echo htmlspecialchars($menu_data[$meal]['calories'] ?? ''); ?>">
                            </div>
                            <div id="dishes-<?php echo $meal; ?>" class="mt-2">
                                <?php
                                $dishes = $menu_data[$meal]['dishes'] ?? [''];
                                foreach ($dishes as $dish): ?>
                                    <div class="mb-2">
                                        <input type="text" name="menu[<?php echo $meal; ?>][dishes][]" class="w-full p-2 border rounded-lg" placeholder="Nhập tên món ăn" value="<?php echo htmlspecialchars($dish); ?>">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <button type="button" onclick="addDish('<?php echo $meal; ?>')" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 mt-2">Thêm món ăn</button>
                        </div>
                    <?php endforeach; ?>
                </div>
                <button type="submit" class="w-full bg-blue-500 text-white p-3 rounded-lg hover:bg-blue-600">Cập nhật</button>
            </form>
            <p class="mt-4 text-center"><a href="manage_preservation.php" class="text-blue-500">Quay lại</a></p>
        </div>
    </div>

    <script>
        new FroalaEditor('#froala-editor', {
            height: 300
        });
    </script>
</body>
</html>
