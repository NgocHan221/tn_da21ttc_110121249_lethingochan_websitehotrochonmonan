<?php
session_start();
require_once 'connect.php';

// Kiểm tra người dùng đã đăng nhập
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Lấy danh sách món ăn
$sql = "SELECT ma_monan, ten_monan, calo FROM monan ORDER BY ten_monan";
$stmt = $conn->prepare($sql);
$stmt->execute();
$dishes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Lấy dữ liệu thực đơn để hiển thị trên lịch
$sql = "SELECT um.date, um.meal, um.dishes 
        FROM user_menus um 
        WHERE um.ma_nguoidung = :ma_nguoidung 
        ORDER BY um.date, 
            CASE um.meal 
                WHEN 'Sáng' THEN 1 
                WHEN 'Trưa' THEN 2 
                WHEN 'Chiều' THEN 3 
                WHEN 'Tối' THEN 4 
            END";
$stmt = $conn->prepare($sql);
$stmt->execute([':ma_nguoidung' => $user_id]);
$menu_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Tạo dữ liệu sự kiện cho lịch
$events = [];
$menu_by_date = [];
foreach ($menu_data as $menu) {
    $date = $menu['date'];
    $meal = $menu['meal'];
    $dish_ids = json_decode($menu['dishes'], true);
    $dish_names = [];
    foreach ($dish_ids as $dish_id) {
        foreach ($dishes as $dish) {
            if ($dish['ma_monan'] == $dish_id) {
                $dish_names[] = $dish['ten_monan'];
            }
        }
    }
    if (!isset($menu_by_date[$date])) {
        $menu_by_date[$date] = [];
    }
    $menu_by_date[$date][] = [
        'meal' => $meal,
        'dishes' => $dish_names
    ];
}

foreach ($menu_by_date as $date => $menus) {
    $tooltip_content = '';
    foreach ($menus as $menu) {
        $tooltip_content .= '<strong>' . htmlspecialchars($menu['meal']) . ':</strong> ' . htmlspecialchars(implode(', ', $menu['dishes'])) . '<br>';
    }
    $events[] = [
        'title' => 'Thực đơn',
        'start' => $date,
        'url' => 'menu.php?date=' . $date,
        'tooltip' => $tooltip_content
    ];
}

// Xử lý thêm/sửa/xóa thực đơn
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_menu'])) {
        $date = $_POST['date'] ?? '';
        $meal = $_POST['meal'] ?? '';
        $selected_dishes = $_POST['dishes'] ?? [];
        $calories = 0;

        // Tính tổng calo
        foreach ($selected_dishes as $dish_id) {
            foreach ($dishes as $dish) {
                if ($dish['ma_monan'] == $dish_id) {
                    $calories += $dish['calo'];
                }
            }
        }

        // Chuyển danh sách món ăn thành JSON
        $dishes_json = json_encode($selected_dishes);

        // Thêm thực đơn vào cơ sở dữ liệu
        $sql = "INSERT INTO user_menus (ma_nguoidung, date, meal, dishes, calories) 
                VALUES (:ma_nguoidung, :date, :meal, :dishes, :calories)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':ma_nguoidung' => $user_id,
            ':date' => $date,
            ':meal' => $meal,
            ':dishes' => $dishes_json,
            ':calories' => $calories
        ]);

        header("Location: menu.php?success=Thêm thực đơn thành công");
        exit();
    } elseif (isset($_POST['edit_menu'])) {
        $menu_id = $_POST['menu_id'] ?? '';
        $date = $_POST['edit_date'] ?? '';
        $meal = $_POST['edit_meal'] ?? '';
        $selected_dishes = $_POST['edit_dishes'] ?? [];
        $calories = 0;

        // Tính tổng calo
        foreach ($selected_dishes as $dish_id) {
            foreach ($dishes as $dish) {
                if ($dish['ma_monan'] == $dish_id) {
                    $calories += $dish['calo'];
                }
            }
        }

        // Chuyển danh sách món ăn thành JSON
        $dishes_json = json_encode($selected_dishes);

        // Cập nhật thực đơn trong cơ sở dữ liệu
        $sql = "UPDATE user_menus SET date = :date, meal = :meal, dishes = :dishes, calories = :calories 
                WHERE id = :id AND ma_nguoidung = :ma_nguoidung";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':date' => $date,
            ':meal' => $meal,
            ':dishes' => $dishes_json,
            ':calories' => $calories,
            ':id' => $menu_id,
            ':ma_nguoidung' => $user_id
        ]);

        header("Location: menu.php?success=Cập nhật thực đơn thành công");
        exit();
    } elseif (isset($_POST['delete_menu'])) {
        $menu_id = $_POST['menu_id'] ?? '';
        $sql = "DELETE FROM user_menus WHERE id = :id AND ma_nguoidung = :ma_nguoidung";
        $stmt = $conn->prepare($sql);
        $stmt->execute([':id' => $menu_id, ':ma_nguoidung' => $user_id]);

        header("Location: menu.php?success=Xóa thực đơn thành công");
        exit();
    }
}

// Lấy thực đơn của người dùng cho ngày được chọn
$selected_date = $_GET['date'] ?? date('Y-m-d');
$sql = "SELECT * FROM user_menus WHERE ma_nguoidung = :ma_nguoidung AND date = :date 
        ORDER BY 
            CASE meal 
                WHEN 'Sáng' THEN 1 
                WHEN 'Trưa' THEN 2 
                WHEN 'Chiều' THEN 3 
                WHEN 'Tối' THEN 4 
            END";
$stmt = $conn->prepare($sql);
$stmt->execute([':ma_nguoidung' => $user_id, ':date' => $selected_date]);
$menus = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thực đơn của bạn</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
    <style>
        :root {
            --primary-color: #3b82f6;
            --secondary-color: #10b981;
            --accent-color: #ef4444;
            --background-light: #f9fafb;
            --border-color: #e5e7eb;
        }

        body {
            background: var(--background-light);
            font-family: 'Inter', sans-serif;
            line-height: 1.6;
        }

        .calendar-container {
            max-width: 700px; /* Giảm từ 900px xuống 700px */
            margin: 0 auto 2rem;
            background: white;
            padding: 1rem; /* Giảm từ 1.5rem xuống 1rem */
            border-radius: 0.75rem;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border-color);
        }

        .menu-table {
            background: white;
            border-radius: 0.75rem;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
            padding: 1.5rem;
            border: 1px solid var(--border-color);
        }

        .menu-table th, .menu-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        .menu-table th {
            background: #f3f4f6;
            font-weight: 600;
            color: #1f2937;
        }

        .menu-form {
            background: white;
            border-radius: 0.75rem;
            padding: 1.5rem;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border-color);
            transition: transform 0.2s ease;
        }

        .menu-form:hover {
            transform: translateY(-2px);
        }

        .menu-form select, .menu-form input {
            border: 1px solid var(--border-color);
            border-radius: 0.375rem;
            padding: 0.5rem;
            width: 100%;
            transition: border-color 0.3s ease;
        }

        .menu-form select:focus, .menu-form input:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }

        .menu-form button {
            background: linear-gradient(to right, var(--primary-color), #2563eb);
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 0.375rem;
            border: none;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        .menu-form button:hover {
            background: linear-gradient(to right, #2563eb, #1d4ed8);
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .delete-btn {
            background: linear-gradient(to right, var(--accent-color), #dc2626);
            margin-left: 0.5rem;
        }

        .delete-btn:hover {
            background: linear-gradient(to right, #dc2626, #b91c1c);
        }

        .edit-btn {
            background: linear-gradient(to right, var(--secondary-color), #059669);
            margin-right: 0.5rem;
        }

        .edit-btn:hover {
            background: linear-gradient(to right, #059669, #047857);
        }

        .select2-container {
            width: 100% !important;
        }

        .select2-container .select2-selection--multiple {
            min-height: 40px !important;
            padding: 4px !important;
            border: 1px solid var(--border-color);
            border-radius: 0.375rem !important;
            background: white !important;
            transition: border-color 0.3s ease;
        }

        .select2-container .select2-selection--multiple:focus-within {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }

        .select2-container .select2-selection__choice {
            background-color: #e5e7eb !important;
            border: 1px solid var(--border-color) !important;
            border-radius: 0.25rem !important;
            padding: 2px 6px !important;
            margin: 2px !important;
            font-size: 0.875rem;
        }

        .select2-container .select2-selection__choice__remove {
            color: var(--accent-color) !important;
            margin-right: 4px !important;
            transition: color 0.2s ease;
        }

        .select2-container .select2-selection__choice__remove:hover {
            color: #b91c1c !important;
        }

        .select2-container .select2-search--inline .select2-search__field {
            margin: 0 !important;
            padding: 4px !important;
            height: 28px !important;
            border: none !important;
            background: transparent !important;
        }

        .select2-container .select2-dropdown {
            border: 1px solid var(--border-color) !important;
            border-radius: 0.375rem !important;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            background: white !important;
            margin-top: 4px !important;
        }

        .select2-container .select2-search--dropdown {
            padding: 6px !important;
            border-bottom: 1px solid var(--border-color);
        }

        .select2-container .select2-search--dropdown .select2-search__field {
            padding: 6px !important;
            border: 1px solid var(--border-color) !important;
            border-radius: 0.25rem !important;
            width: 100%;
            font-size: 14px;
            background: #f9fafb !important;
            outline: none !important;
            transition: border-color 0.3s ease;
        }

        .select2-container .select2-search--dropdown .select2-search__field:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }

        .select2-container .select2-results__options {
            max-height: 200px !important;
            overflow-y: auto !important;
            scrollbar-width: thin !important;
            scrollbar-color: var(--border-color) #f3f4f6 !important;
        }

        .select2-container .select2-results__options::-webkit-scrollbar {
            width: 8px !important;
        }

        .select2-container .select2-results__options::-webkit-scrollbar-thumb {
            background: var(--border-color) !important;
            border-radius: 4px !important;
        }

        .select2-container .select2-results__options::-webkit-scrollbar-track {
            background: #f3f4f6 !important;
        }

        .select2-container .select2-results__option {
            padding: 8px 12px !important;
            font-size: 14px !important;
            transition: background-color 0.2s ease;
        }

        .select2-container .select2-results__option--highlighted {
            background-color: var(--primary-color) !important;
            color: white !important;
        }

        .select2-container .select2-results__option--selected {
            background-color: #e5e7eb !important;
            color: #1f2937 !important;
        }

        .nutrition-chart-btn {
            background: linear-gradient(to right, #8b5cf6, #7c3aed);
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 0.375rem;
            text-decoration: none;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        .nutrition-chart-btn:hover {
            background: linear-gradient(to right, #7c3aed, #6d28d9);
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        /* Navbar styles */
        .navbar {
            background: linear-gradient(145deg, #4f46e5, var(--secondary-color));
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 50;
        }

        .navbar-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }

        .nav-menu {
            display: flex;
            gap: 0.75rem;
            align-items: center;
        }

        .nav-menu a {
            color: #e5e7eb;
            font-size: 1rem;
            font-weight: 500;
            text-decoration: none;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            transition: background-color 0.3s ease, color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }

        .nav-menu a:hover {
            background-color: #6b7280;
            color: #ffffff;
        }

        .nav-user-section {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .user-dropdown {
            position: relative;
        }

        .user-button {
            color: #e5e7eb;
            font-size: 1rem;
            font-weight: 500;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            background: transparent;
            transition: background-color 0.3s ease, color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }

        .user-button:hover {
            background-color: #6b7280;
            color: #ffffff;
        }

        .user-dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: #ffffff;
            border-radius: 0.375rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            min-width: 160px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: opacity 0.3s ease, transform 0.3s ease, visibility 0.3s ease;
            z-index: 100;
        }

        .user-dropdown:hover .user-dropdown-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .user-dropdown-menu a {
            display: block;
            padding: 0.5rem 1rem;
            color: #1f2937;
            font-size: 0.875rem;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .user-dropdown-menu a:hover {
            background-color: #f3f4f6;
        }

        .logout-link {
            color: white;
            font-size: 1rem;
            font-weight: 500;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            text-decoration: none;
            transition: background 0.3s ease, transform 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }

        .logout-link:hover {
            background: linear-gradient(to right, #2563eb, #1d4ed8);
            transform: scale(1.02);
        }

        .hamburger {
            display: none;
            flex-direction: column;
            cursor: pointer;
            gap: 0.25rem;
        }

        .hamburger span {
            width: 24px;
            height: 3px;
            background: #e5e7eb;
            border-radius: 2px;
            transition: all 0.3s ease;
        }

        .hamburger.active span:nth-child(1) {
            transform: rotate(45deg) translate(5px, 5px);
        }

        .hamburger.active span:nth-child(2) {
            opacity: 0;
        }

        .hamburger.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -7px);
        }

        @media (max-width: 767px) {
            .navbar-container {
                flex-wrap: wrap;
            }
            .nav-menu {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: #4f46e5;
                flex-direction: column;
                padding: 1rem;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            }
            .nav-menu.active {
                display: flex;
            }
            .nav-menu a {
                padding: 0.75rem;
                width: 100%;
                text-align: left;
                font-size: 1rem;
            }
            .nav-user-section {
                display: none;
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
                padding: 1rem;
                width: 100%;
            }
            .nav-user-section.active {
                display: flex;
            }
            .user-dropdown {
                width: 100%;
            }
            .user-dropdown-menu {
                position: static;
                background: #6b7280;
                box-shadow: none;
                transform: none;
                opacity: 1;
                visibility: visible;
                margin-top: 0.5rem;
                width: 100%;
            }
            .user-dropdown-menu a {
                color: #e5e7eb;
            }
            .user-dropdown-menu a:hover {
                background-color: #4b5563;
            }
            .logout-link {
                width: 100%;
                text-align: left;
                color: white;
            }
            .logout-link:hover {
                color: white;
            }
            .hamburger {
                display: flex;
            }
        }

        .error-message {
            color: var(--accent-color);
            font-size: 0.875rem;
            margin-top: 0.25rem;
            display: none;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 50;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }

        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            border-radius: 0.75rem;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .close {
            color: #666;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.2s ease;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
        }

        .fc-tooltip {
            position: absolute;
            background: #fff;
            border: 1px solid var(--border-color);
            border-radius: 0.375rem;
            padding: 8px 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            z-index: 100;
            font-size: 14px;
            color: #1f2937;
            max-width: 300px;
            word-wrap: break-word;
            animation: slideIn 0.2s ease;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Thanh menu ngang -->
    <nav class="navbar">
        <div class="navbar-container">
            <div class="hamburger" id="hamburger" role="button" aria-label="Toggle navigation" aria-expanded="false">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="flex items-center gap-4">
                <div class="nav-menu" id="nav-menu">
                    <a href="index.php"><i class="fas fa-home"></i> Trang chủ</a>
                    <a href="nutrients.php"><i class="fas fa-seedling"></i> Dinh dưỡng</a>
                    <a href="suggest_dishes.php"><i class="fas fa-utensils"></i> Gợi ý theo nguyên liệu</a>
                    <a href="favorites.php"><i class="fas fa-heart"></i> Món ăn yêu thích</a>
                    <a href="menu.php"><i class="fas fa-calendar-alt"></i> Thực đơn</a>
                    <a href="nutrition_chart.php"><i class="fas fa-chart-bar"></i> Biểu đồ dinh dưỡng</a>
                </div>
                <div class="nav-user-section" id="nav-user-section">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <div class="user-dropdown">
                            <button class="user-button">
                                <i class="fas fa-user mr-2"></i>
                                <span><?php echo htmlspecialchars(isset($_SESSION['ten_dangnhap']) && !empty($_SESSION['ten_dangnhap']) ? $_SESSION['ten_dangnhap'] : 'Người dùng'); ?></span>
                            </button>
                            <div class="user-dropdown-menu">
                                <a href="profile.php">Hồ sơ</a>
                            </div>
                        </div>
                        <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt mr-2"></i>Đăng xuất</a>
                    <?php else: ?>
                        <a href="login.php" class="user-button">
                            <i class="fas fa-sign-in-alt mr-2"></i> Đăng nhập
                        </a>
                        <a href="register.php" class="user-button">
                            <i class="fas fa-user-plus mr-2"></i> Đăng ký
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Nội dung chính -->
    <div class="container mx-auto p-6">
        <div class="flex items-center justify-between mb-6">
            <h2 class="text-3xl font-bold text-gray-800 text-center">Thực đơn của bạn</h2>
            <a href="nutrition_chart.php" class="nutrition-chart-btn">
                <i class="fas fa-chart-line mr-2"></i>Biểu đồ dinh dưỡng
            </a>
        </div>

        <?php if (isset($_GET['success'])): ?>
            <p class="text-green-500 mb-4 text-center bg-green-50 p-2 rounded-lg"><?php echo htmlspecialchars($_GET['success']); ?></p>
        <?php endif; ?>

        <!-- Lịch -->
        <div class="calendar-container">
            <div id="calendar"></div>
        </div>

        <!-- Form thêm thực đơn -->
        <div class="menu-form" id="menu-form-container">
            <h3 class="text-xl font-semibold mb-4 text-gray-700">Thêm thực đơn</h3>
            <form method="POST" id="menu-form">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                        <label for="date" class="block font-semibold mb-1 text-gray-600">Ngày</label>
                        <input type="date" name="date" id="date" value="<?php echo htmlspecialchars($selected_date); ?>" required class="w-full p-2 border rounded">
                    </div>
                    <div>
                        <label for="meal" class="block font-semibold mb-1 text-gray-600">Buổi ăn</label>
                        <select name="meal" id="meal" required class="w-full p-2 border rounded">
                            <option value="">Chọn buổi ăn</option>
                            <option value="Sáng">Sáng</option>
                            <option value="Trưa">Trưa</option>
                            <option value="Chiều">Chiều</option>
                            <option value="Tối">Tối</option>
                        </select>
                        <div id="meal-error" class="error-message">Vui lòng chọn buổi ăn.</div>
                    </div>
                    <div>
                        <label for="dishes" class="block font-semibold mb-1 text-gray-600">Món ăn</label>
                        <select name="dishes[]" id="dishes" multiple class="w-full">
                            <?php foreach ($dishes as $dish): ?>
                                <option value="<?php echo $dish['ma_monan']; ?>">
                                    <?php echo htmlspecialchars($dish['ten_monan']) . ' (' . $dish['calo'] . ' kcal)'; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div id="dishes-error" class="error-message">Vui lòng chọn ít nhất một món ăn.</div>
                    </div>
                </div>
                <button type="submit" name="add_menu" class="mt-4 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Thêm thực đơn</button>
            </form>
        </div>

        <!-- Modal sửa thực đơn -->
        <div id="editModal" class="modal">
            <div class="modal-content">
                <span class="close">×</span>
                <h3 class="text-xl font-semibold mb-4 text-gray-700">Sửa thực đơn</h3>
                <form method="POST" id="edit-menu-form">
                    <input type="hidden" name="menu_id" id="edit_menu_id">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div>
                            <label for="edit_date" class="block font-semibold mb-1 text-gray-600">Ngày</label>
                            <input type="date" name="edit_date" id="edit_date" required class="w-full p-2 border rounded">
                        </div>
                        <div>
                            <label for="edit_meal" class="block font-semibold mb-1 text-gray-600">Buổi ăn</label>
                            <select name="edit_meal" id="edit_meal" required class="w-full p-2 border rounded">
                                <option value="">Chọn buổi ăn</option>
                                <option value="Sáng">Sáng</option>
                                <option value="Trưa">Trưa</option>
                                <option value="Chiều">Chiều</option>
                                <option value="Tối">Tối</option>
                            </select>
                            <div id="edit-meal-error" class="error-message">Vui lòng chọn buổi ăn.</div>
                        </div>
                        <div>
                            <label for="edit_dishes" class="block font-semibold mb-1 text-gray-600">Món ăn</label>
                            <select name="edit_dishes[]" id="edit_dishes" multiple class="w-full">
                                <?php foreach ($dishes as $dish): ?>
                                    <option value="<?php echo $dish['ma_monan']; ?>">
                                        <?php echo htmlspecialchars($dish['ten_monan']) . ' (' . $dish['calo'] . ' kcal)'; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div id="edit-dishes-error" class="error-message">Vui lòng chọn ít nhất một món ăn.</div>
                        </div>
                    </div>
                    <button type="submit" name="edit_menu" class="mt-4 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Lưu thay đổi</button>
                </form>
            </div>
        </div>

        <!-- Bảng thực đơn của ngày được chọn -->
        <div class="menu-table">
            <h3 class="text-xl font-semibold mb-4 text-gray-700">Thực đơn ngày <?php echo htmlspecialchars($selected_date); ?></h3>
            <?php if (empty($menus)): ?>
                <p class="text-center text-gray-500 bg-gray-50 p-2 rounded-lg">Không có thực đơn nào cho ngày này.</p>
            <?php else: ?>
                <table class="w-full">
                    <thead>
                        <tr>
                            <th>Buổi ăn</th>
                            <th>Tên món ăn</th>
                            <th>Calo</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($menus as $menu): ?>
                            <?php
                            $menu_dishes = json_decode($menu['dishes'], true);
                            $dish_names = [];
                            foreach ($menu_dishes as $dish_id) {
                                foreach ($dishes as $dish) {
                                    if ($dish['ma_monan'] == $dish_id) {
                                        $dish_names[] = htmlspecialchars($dish['ten_monan']);
                                    }
                                }
                            }
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($menu['meal']); ?></td>
                                <td><?php echo implode(', ', $dish_names); ?></td>
                                <td><?php echo htmlspecialchars($menu['calories']); ?> kcal</td>
                                <td>
                                    <button class="edit-btn text-white px-3 py-1 rounded" onclick='openEditModal(<?php echo json_encode($menu); ?>, <?php echo json_encode($menu_dishes); ?>)'>Sửa</button>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="menu_id" value="<?php echo htmlspecialchars($menu['id']); ?>">
                                        <button type="submit" name="delete_menu" class="delete-btn text-white px-3 py-1 rounded" onclick="return confirm('Bạn có chắc chắn muốn xóa thực đơn này không?')">Xóa</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white p-4 mt-6">
        <div class="container mx-auto">
            <div class="flex justify-center gap-4">
                <a href="index.php">Trang chủ</a>
                <a href="nutrients.php">Dinh dưỡng</a>
                <a href="suggest_dishes.php">Gợi ý theo nguyên liệu</a>
                <a href="favorites.php">Món ăn yêu thích</a>
                <a href="menu.php">Thực đơn</a>
                <a href="nutrition_chart.php">Biểu đồ dinh dưỡng</a>
            </div>
            <div class="flex justify-center mt-4 gap-4">
                <a href="https://facebook.com" target="_blank" class="hover:text-blue-500"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com" target="_blank" class="hover:text-blue-500"><i class="fab fa-twitter"></i></a>
                <a href="https://instagram.com" target="_blank" class="hover:text-blue-500"><i class="fab fa-instagram"></i></a>
            </div>
            <div class="text-center text-sm mt-4">
                <p>Liên hệ qua email: <a href="mailto:support@foodsuggestion.com" class="hover:text-blue-500">lethingochan227tv@gmail.com</a></p>
            </div>
        </div>
    </footer>

    <!-- Thêm thư viện JavaScript -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Khởi tạo lịch
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                locale: 'vi',
                events: [
                    <?php foreach ($events as $event): ?>
                        {
                            title: '<?php echo $event['title']; ?>',
                            start: '<?php echo $event['start']; ?>',
                            url: '<?php echo $event['url']; ?>',
                            tooltip: '<?php echo addslashes($event['tooltip']); ?>'
                        },
                    <?php endforeach; ?>
                ],
                eventClick: function(info) {
                    window.location.href = info.event.url;
                },
                eventMouseEnter: function(info) {
                    var tooltip = document.createElement('div');
                    tooltip.className = 'fc-tooltip';
                    tooltip.innerHTML = info.event.extendedProps.tooltip;
                    document.body.appendChild(tooltip);

                    var rect = info.el.getBoundingClientRect();
                    tooltip.style.top = (rect.top + window.scrollY - tooltip.offsetHeight - 10) + 'px';
                    tooltip.style.left = (rect.left + window.scrollX + (rect.width / 2)) + 'px';
                    tooltip.style.transform = 'translateX(-50%)';
                },
                eventMouseLeave: function(info) {
                    var tooltips = document.getElementsByClassName('fc-tooltip');
                    while (tooltips.length > 0) {
                        tooltips[0].parentNode.removeChild(tooltips[0]);
                    }
                }
            });
            calendar.render();

            // Khởi tạo Select2 cho chọn món ăn với tính năng tìm kiếm
            function initializeSelect2(selector) {
                $(selector).select2({
                    placeholder: 'Tìm kiếm và chọn món ăn...',
                    allowClear: true,
                    width: '100%',
                    minimumInputLength: 0,
                    minimumResultsForSearch: 0,
                    language: {
                        noResults: function() {
                            return "Không tìm thấy món ăn";
                        },
                        searching: function() {
                            return "Đang tìm kiếm...";
                        }
                    },
                    matcher: function(params, data) {
                        if (!params.term || params.term.trim() === '') {
                            return data;
                        }
                        const term = params.term.toLowerCase();
                        const normalizedText = data.text
                            .toLowerCase()
                            .normalize('NFD')
                            .replace(/[\u0300-\u036f]/g, '');
                        if (normalizedText.includes(term) || data.text.toLowerCase().includes(term)) {
                            return data;
                        }
                        return null;
                    }
                });
            }

            // Khởi tạo Select2 cho form chính và form sửa
            initializeSelect2('#dishes');
            initializeSelect2('#edit_dishes');

            // Xử lý ngày được chọn từ URL
            var selectedDate = '<?php echo htmlspecialchars($selected_date); ?>';
            if (selectedDate) {
                calendar.gotoDate(selectedDate);
            }

            // Thêm kiểm tra khi thêm thực đơn
            document.getElementById('menu-form').addEventListener('submit', function(e) {
                const meal = document.getElementById('meal').value;
                const dishes = document.getElementById('dishes').value || [];
                if (!meal || dishes.length === 0) {
                    e.preventDefault();
                    if (!meal) document.getElementById('meal-error').style.display = 'block';
                    if (dishes.length === 0) document.getElementById('dishes-error').style.display = 'block';
                }
            });

            // Thêm kiểm tra khi sửa thực đơn
            document.getElementById('edit-menu-form').addEventListener('submit', function(e) {
                const meal = document.getElementById('edit_meal').value;
                const dishes = document.getElementById('edit_dishes').value || [];
                if (!meal || dishes.length === 0) {
                    e.preventDefault();
                    if (!meal) document.getElementById('edit-meal-error').style.display = 'block';
                    if (dishes.length === 0) document.getElementById('edit-dishes-error').style.display = 'block';
                }
            });

            // Xử lý modal
            var modal = document.getElementById('editModal');
            var closeBtn = document.getElementsByClassName('close')[0];

            // Mở modal và điền dữ liệu
            window.openEditModal = function(menu, dishes) {
                document.getElementById('edit_menu_id').value = menu.id;
                document.getElementById('edit_date').value = menu.date;
                document.getElementById('edit_meal').value = menu.meal;
                $('#edit_dishes').val(dishes).trigger('change');
                modal.style.display = 'block';
            }

            // Đóng modal
            closeBtn.onclick = function() {
                modal.style.display = 'none';
            }

            // Đóng modal khi click bên ngoài
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            }

            // Xử lý hamburger menu
            const hamburger = document.getElementById('hamburger');
            const navMenu = document.getElementById('nav-menu');
            const navUserSection = document.getElementById('nav-user-section');

            hamburger.addEventListener('click', function () {
                const isActive = hamburger.classList.toggle('active');
                hamburger.setAttribute('aria-expanded', isActive);
                navMenu.classList.toggle('active');
                navUserSection.classList.toggle('active');
            });

            // Đóng menu khi click vào link trên mobile
            document.querySelectorAll('.nav-menu a, .nav-user-section a').forEach(link => {
                link.addEventListener('click', function () {
                    if (window.innerWidth <= 767) {
                        hamburger.classList.remove('active');
                        hamburger.setAttribute('aria-expanded', 'false');
                        navMenu.classList.remove('active');
                        navUserSection.classList.remove('active');
                    }
                });
            });
        });
    </script>
</body>
</html>
