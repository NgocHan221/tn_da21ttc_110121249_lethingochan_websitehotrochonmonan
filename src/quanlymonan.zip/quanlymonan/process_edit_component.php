<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ma_thanhphan = $_POST['ma_thanhphan'];
    $ten_thanhphan = $_POST['ten_thanhphan'];

    // Kiểm tra tên thành phần đã tồn tại (trừ thành phần hiện tại)
    $sql = "SELECT * FROM thanhphandinhduong WHERE ten_thanhphan = :ten_thanhphan AND ma_thanhphan != :ma_thanhphan";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_thanhphan' => $ten_thanhphan, 'ma_thanhphan' => $ma_thanhphan]);
    if ($stmt->rowCount() > 0) {
        header("Location: edit_component.php?id=$ma_thanhphan&error=Tên thành phần đã tồn tại");
        exit();
    }

    // Cập nhật thành phần
    $sql = "UPDATE thanhphandinhduong SET ten_thanhphan = :ten_thanhphan WHERE ma_thanhphan = :ma_thanhphan";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_thanhphan' => $ten_thanhphan, 'ma_thanhphan' => $ma_thanhphan]);

    header("Location: manage_components.php");
    exit();
}
?>