<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: add_nutrient.php?error=Phương thức không hợp lệ");
    exit();
}

try {
    $ten_dinhduong = $_POST['ten_dinhduong'] ?? '';
    $hinh_anh = '';

    if (isset($_FILES['hinh_anh']) && $_FILES['hinh_anh']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/nutrients/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $filename = uniqid('nutrient_') . '.' . pathinfo($_FILES['hinh_anh']['name'], PATHINFO_EXTENSION);
        $destination = $upload_dir . $filename;
        if (move_uploaded_file($_FILES['hinh_anh']['tmp_name'], $destination)) {
            $hinh_anh = $destination;
        } else {
            throw new Exception("Không thể tải hình ảnh lên");
        }
    }

    $sql = "INSERT INTO dinhduong (ten_dinhduong, hinh_anh) VALUES (:ten_dinhduong, :hinh_anh)";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_dinhduong' => $ten_dinhduong, 'hinh_anh' => $hinh_anh]);

    header("Location: manage_nutrients.php?success=Đã thêm dinh dưỡng thành công");
    exit();
} catch (Exception $e) {
    header("Location: add_nutrient.php?error=" . urlencode($e->getMessage()));
    exit();
}
?>