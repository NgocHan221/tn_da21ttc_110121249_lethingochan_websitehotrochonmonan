<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ma_nguyenlieu = $_POST['ma_nguyenlieu'];
    $ten_nguyenlieu = $_POST['ten_nguyenlieu'];

    // Kiểm tra tên nguyên liệu đã tồn tại (trừ nguyên liệu hiện tại)
    $sql = "SELECT * FROM nguyenlieu WHERE ten_nguyenlieu = :ten_nguyenlieu AND ma_nguyenlieu != :ma_nguyenlieu";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_nguyenlieu' => $ten_nguyenlieu, 'ma_nguyenlieu' => $ma_nguyenlieu]);
    if ($stmt->rowCount() > 0) {
        header("Location: edit_ingredient.php?id=$ma_nguyenlieu&error=Tên nguyên liệu đã tồn tại");
        exit();
    }

    // Cập nhật nguyên liệu
    $sql = "UPDATE nguyenlieu SET ten_nguyenlieu = :ten_nguyenlieu WHERE ma_nguyenlieu = :ma_nguyenlieu";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_nguyenlieu' => $ten_nguyenlieu, 'ma_nguyenlieu' => $ma_nguyenlieu]);

    header("Location: manage_ingredients.php");
    exit();
}
?>