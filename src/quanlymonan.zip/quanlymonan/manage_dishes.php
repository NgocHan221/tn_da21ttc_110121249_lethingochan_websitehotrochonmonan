<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

function displayValue($value, $default = 'Chưa chọn') {
    return !empty($value) ? htmlspecialchars($value) : $default;
}

$items_per_page = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] > 0 ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $items_per_page;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? (int)$_GET['category'] : 0;

try {
    $sql_count = "SELECT COUNT(*) FROM monan WHERE 1=1";
    $params = [];
    if ($search) {
        $sql_count .= " AND ten_monan LIKE :search";
        $params['search'] = '%' . $search . '%';
    }
    if ($category) {
        $sql_count .= " AND ma_monan IN (SELECT ma_monan FROM monan_danhmuc WHERE ma_danhmuc = :category)";
        $params['category'] = $category;
    }
    $stmt_count = $conn->prepare($sql_count);
    foreach ($params as $key => $value) {
        $stmt_count->bindValue($key, $value);
    }
    $stmt_count->execute();
    $total_items = $stmt_count->fetchColumn();
    $total_pages = ceil($total_items / $items_per_page);

    $sql = "SELECT m.*, c.ten_chedo, n.ten_dinhduong 
            FROM monan m 
            LEFT JOIN chedo c ON m.ma_chedo = c.ma_chedo 
            LEFT JOIN dinhduong n ON m.ma_dinhduong = n.ma_dinhduong
            WHERE 1=1";
    if ($search) {
        $sql .= " AND m.ten_monan LIKE :search";
    }
    if ($category) {
        $sql .= " AND m.ma_monan IN (SELECT ma_monan FROM monan_danhmuc WHERE ma_danhmuc = :category)";
    }
    $sql .= " LIMIT :limit OFFSET :offset";
    $stmt = $conn->prepare($sql);
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $items_per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $dishes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $sql_categories = "SELECT md.ma_monan, GROUP_CONCAT(d.ten_danhmuc) AS ten_danhmuc
                       FROM monan_danhmuc md 
                       JOIN danhmuc d ON md.ma_danhmuc = d.ma_danhmuc 
                       GROUP BY md.ma_monan";
    $stmt_categories = $conn->query($sql_categories);
    $categories = [];
    while ($row = $stmt_categories->fetch(PDO::FETCH_ASSOC)) {
        $categories[$row['ma_monan']] = explode(',', $row['ten_danhmuc']);
    }
} catch (PDOException $e) {
    echo "<p class='text-red-500'>Lỗi truy vấn: " . htmlspecialchars($e->getMessage()) . "</p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý món ăn</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .hidden-col { display: none; }
        @media (max-width: 768px) {
            table { display: block; overflow-x: auto; white-space: nowrap; }
            .hidden-col-mobile { display: none; }
        }
        th, td {
            white-space: nowrap;
            vertical-align: top;
        }
        .recipe-col {
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .recipe-content {
            white-space: normal;
            word-wrap: break-word;
        }
    </style>
</head>
<body class="bg-gray-100 flex">
    <!-- Sidebar -->
    <div class="w-64 bg-gray-800 text-white h-screen fixed top-0 left-0 p-4 text-xl">
        <h2 class="text-2xl font-bold mb-6">Quản trị viên</h2>
        <ul>
            <li class="mb-4"><a href="admin_dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-users mr-2"></i> Quản lý người dùng</a></li>
            <li class="mb-4"><a href="manage_categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-list mr-2"></i> Quản lý danh mục</a></li>
            <li class="mb-4"><a href="manage_diets.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-utensils mr-2"></i> Quản lý chế độ</a></li>
            <li class="mb-4"><a href="manage_ingredients.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-seedling mr-2"></i> Quản lý nguyên liệu</a></li>
            <li class="mb-4"><a href="manage_nutrients.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-heartbeat mr-2"></i> Quản lý dinh dưỡng</a></li>
            <li class="mb-4"><a href="manage_components.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-vial mr-2"></i> Quản lý thành phần dinh dưỡng</a></li>
            <li class="mb-4"><a href="manage_dishes.php" class="flex items-center p-2 bg-gray-700 rounded"><i class="fas fa-utensil-spoon mr-2"></i> Quản lý món ăn</a></li>
            <li class="mb-4"><a href="admin_feedback.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-comments mr-2"></i> Quản lý phản hồi</a></li>
            <li class="mb-4"><a href="manage_preservation.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-leaf mr-2"></i> Quản lý chi tiết dinh dưỡng</a></li>
            <li><a href="logout.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-sign-out-alt mr-2"></i> Đăng xuất</a></li>
        </ul>
    </div>

    <!-- Main content -->
    <div class="ml-64 p-0 w-full">
        <div class="bg-white min-h-screen p-8">
            <h2 class="text-3xl font-bold mb-8 text-center">Danh sách món ăn</h2>
            
            <?php if (isset($_GET['success'])): ?>
                <p class="text-green-500 mb-4"><?php echo htmlspecialchars($_GET['success']); ?></p>
            <?php endif; ?>

            <div class="mb-6">
                <form method="GET" class="flex flex-wrap gap-4">
                    <input type="text" name="search" placeholder="Tìm kiếm món ăn..." value="<?php echo htmlspecialchars($search); ?>" class="border p-2 rounded w-full md:w-1/2">
                    <select name="category" class="border p-2 rounded w-full md:w-auto">
                        <option value="">Tất cả danh mục</option>
                        <?php
                        $stmt = $conn->query("SELECT * FROM danhmuc");
                        while ($cat = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            $selected = $category == $cat['ma_danhmuc'] ? 'selected' : '';
                            echo "<option value='{$cat['ma_danhmuc']}' $selected>" . htmlspecialchars($cat['ten_danhmuc']) . "</option>";
                        }
                        ?>
                    </select>
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Tìm</button>
                </form>
            </div>

            <div class="mb-6 flex justify-between">
                <a href="add_dish.php" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">Thêm món ăn</a>
                <button id="toggleRecipe" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Xem thêm Công thức</button>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full border border-gray-300 text-sm text-gray-800 shadow rounded-md">
                    <thead class="bg-gray-100 text-gray-700 font-semibold uppercase">
                        <tr>
                            <th class="border px-4 py-3">Tên món ăn</th>
                            <th class="border px-4 py-3 hidden-col-mobile">Hình ảnh</th>
                            <th class="border px-4 py-3 hidden-col-mobile">Video</th>
                            <th class="border px-4 py-3">Khẩu phần</th>
                            <th class="border px-4 py-3">Độ khó</th>
                            <th class="border px-4 py-3">Calo</th>
                            <th class="border px-4 py-3">Danh mục</th>
                            <th class="border px-4 py-3 hidden-col-mobile">Chế độ</th>
                            <th class="border px-4 py-3 hidden-col-mobile">Dinh dưỡng</th>
                            <th class="border px-4 py-3 hidden-col recipe-col">Công thức</th>
                            <th class="border px-4 py-3">Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dishes as $dish): ?>
                            <tr class="hover:bg-gray-50 even:bg-gray-50">
                                <td class="border px-4 py-3"><?php echo displayValue($dish['ten_monan']); ?></td>
                                <td class="border px-4 py-3 hidden-col-mobile">
                                    <?php 
                                    $img = $dish['hinh_anh'];
                                    echo $img && file_exists($img) ? "<img src='$img' alt='Hình' class='w-20 h-20 object-cover'>" : "Không có hình";
                                    ?>
                                </td>
                                <td class="border px-4 py-3 hidden-col-mobile">
                                    <?php 
                                    $video = $dish['video'];
                                    echo $video && file_exists($video) ? "<video controls width='160'><source src='$video' type='video/mp4'>Trình duyệt không hỗ trợ video.</video>" : "Không có video";
                                    ?>
                                </td>
                                <td class="border px-4 py-3"><?php echo displayValue($dish['khau_phan'], '0') . ' người'; ?></td>
                                <td class="border px-4 py-3"><?php echo displayValue($dish['do_kho']); ?></td>
                                <td class="border px-4 py-3"><?php echo displayValue($dish['calo'], '0') . ' kcal'; ?></td>
                                <td class="border px-4 py-3"><?php echo !empty($categories[$dish['ma_monan']]) ? displayValue(implode(', ', $categories[$dish['ma_monan']])) : 'Chưa chọn'; ?></td>
                                <td class="border px-4 py-3 hidden-col-mobile"><?php echo displayValue($dish['ten_chedo']); ?></td>
                                <td class="border px-4 py-3 hidden-col-mobile"><?php echo displayValue($dish['ten_dinhduong']); ?></td>
                                <td class="border px-4 py-3 hidden-col recipe-col">
                                    <div class="recipe-content">
                                        <?php echo !empty($dish['cong_thuc']) ? htmlspecialchars_decode($dish['cong_thuc']) : 'Chưa có công thức'; ?>
                                    </div>
                                </td>
                                <td class="border px-4 py-3 flex gap-2">
                                    <a href="edit_dish.php?id=<?php echo $dish['ma_monan']; ?>" 
                                       class="bg-yellow-400 hover:bg-yellow-500 text-white px-3 py-1 rounded shadow transition duration-200">
                                        <i class="fas fa-edit"></i> Sửa
                                    </a>
                                    <a href="process_delete_dish.php?id=<?php echo $dish['ma_monan']; ?>" 
                                       class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded shadow transition duration-200" 
                                       onclick="return confirm('Bạn có chắc muốn xóa món ăn này?')">
                                        <i class="fas fa-trash-alt"></i> Xóa
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Phân trang -->
            <div class="mt-6 flex justify-center">
                <nav class="inline-flex rounded-md shadow-sm">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category; ?>" class="px-3 py-2 bg-gray-200 text-gray-700 rounded-l-md hover:bg-gray-300">Trước</a>
                    <?php endif; ?>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category; ?>" class="px-3 py-2 <?php echo $i == $page ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'; ?> hover:bg-gray-300"><?php echo $i; ?></a>
                    <?php endfor; ?>
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $category; ?>" class="px-3 py-2 bg-gray-200 text-gray-700 rounded-r-md hover:bg-gray-300">Sau</a>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('toggleRecipe').addEventListener('click', function () {
            const recipeCols = document.querySelectorAll('.recipe-col');
            recipeCols.forEach(col => col.classList.toggle('hidden-col'));
            this.textContent = this.textContent.includes('Xem') ? 'Ẩn Công thức' : 'Xem thêm Công thức';
        });
    </script>
</body>
</html>
