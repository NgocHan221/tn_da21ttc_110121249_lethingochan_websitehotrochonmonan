<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: manage_nutrients.php");
    exit();
}

$ma_dinhduong = $_GET['id'];

// Lấy thông tin dinh dưỡng để xóa hình ảnh
$sql = "SELECT hinh_anh FROM dinhduong WHERE ma_dinhduong = :ma_dinhduong";
$stmt = $conn->prepare($sql);
$stmt->execute(['ma_dinhduong' => $ma_dinhduong]);
$nutrient = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$nutrient) {
    header("Location: manage_nutrients.php?error=Dinh dưỡng không tồn tại");
    exit();
}

// Xóa hình ảnh nếu có
if ($nutrient['hinh_anh'] && file_exists($nutrient['hinh_anh'])) {
    unlink($nutrient['hinh_anh']);
}

// Xóa các liên kết trong bảng monan
$sql = "UPDATE monan SET ma_dinhduong = NULL WHERE ma_dinhduong = :ma_dinhduong";
$stmt = $conn->prepare($sql);
$stmt->execute(['ma_dinhduong' => $ma_dinhduong]);

// Xóa dinh dưỡng
$sql = "DELETE FROM dinhduong WHERE ma_dinhduong = :ma_dinhduong";
$stmt = $conn->prepare($sql);
$stmt->execute(['ma_dinhduong' => $ma_dinhduong]);

header("Location: manage_nutrients.php?success=Dinh dưỡng đã được xóa thành công");
exit;