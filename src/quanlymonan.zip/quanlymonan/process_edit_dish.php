<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: edit_dish.php?error=Phương thức không hợp lệ");
    exit();
}

try {
    $ma_monan = $_POST['ma_monan'] ?? 0;
    $ten_monan = $_POST['ten_monan'] ?? '';
    $khau_phan = $_POST['khau_phan'] ?? '';
    $do_kho = $_POST['do_kho'] ?? '';
    $calo = $_POST['calo'] ?? '';
    $categories = $_POST['categories'] ?? [];
    $ma_chedo = $_POST['ma_chedo'] ?? null;
    $ma_dinhduong = $_POST['ma_dinhduong'] ?? null;
    $cong_thuc = $_POST['cong_thuc'] ?? '';
    $ghi_chu = $_POST['ghi_chu'] ?? null;
    $ingredients = $_POST['ingredients'] ?? [];
    $components = $_POST['components'] ?? [];

    // Kiểm tra dữ liệu đầu vào
    if (!is_numeric($ma_monan) || $ma_monan < 1) {
        throw new Exception("ID món ăn không hợp lệ");
    }
    if (empty($ten_monan) || !preg_match("/^[\p{L}\s\d]+$/u", $ten_monan)) {
        throw new Exception("Tên món ăn không hợp lệ");
    }
    if (!is_numeric($khau_phan) || $khau_phan < 1) {
        throw new Exception("Khẩu phần phải là số dương");
    }
    if (!is_numeric($calo) || $calo < 0) {
        throw new Exception("Calo phải là số không âm");
    }
    foreach ($ingredients as $ma_nguyenlieu => $data) {
        if (isset($data['selected']) && $data['selected']) {
            if (!empty($data['so_gram']) && (!is_numeric($data['so_gram']) || $data['so_gram'] < 0)) {
                throw new Exception("Số gram của nguyên liệu phải là số không âm");
            }
        }
    }

    // Lấy thông tin món ăn hiện tại
    $sql = "SELECT hinh_anh, video FROM monan WHERE ma_monan = :ma_monan";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_monan' => $ma_monan]);
    $current_dish = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$current_dish) {
        throw new Exception("Món ăn không tồn tại");
    }

    // Xử lý upload hình ảnh
    $hinh_anh = $current_dish['hinh_anh'];
    if (isset($_FILES['hinh_anh']) && $_FILES['hinh_anh']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/images/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        $allowed_image_types = ['image/jpeg', 'image/png', 'image/gif'];
        $max_file_size = 10 * 1024 * 1024;
        $file_type = mime_content_type($_FILES['hinh_anh']['tmp_name']);
        if (!in_array($file_type, $allowed_image_types) || $_FILES['hinh_anh']['size'] > $max_file_size) {
            throw new Exception("Hình ảnh không hợp lệ hoặc quá lớn");
        }
        $hinh_anh_name = uniqid('image_') . '.' . pathinfo($_FILES['hinh_anh']['name'], PATHINFO_EXTENSION);
        $hinh_anh_path = $upload_dir . $hinh_anh_name;
        if (move_uploaded_file($_FILES['hinh_anh']['tmp_name'], $hinh_anh_path)) {
            if ($hinh_anh && file_exists($hinh_anh)) {
                unlink($hinh_anh);
            }
            $hinh_anh = $hinh_anh_path;
        } else {
            throw new Exception("Không thể upload hình ảnh");
        }
    }

    // Xử lý upload video
    $video = $current_dish['video'];
    if (isset($_FILES['video']) && $_FILES['video']['error'] == UPLOAD_ERR_OK) {
        $video_dir = 'uploads/videos/';
        if (!file_exists($video_dir)) {
            mkdir($video_dir, 0755, true);
        }
        $allowed_video_types = ['video/mp4', 'video/mpeg'];
        $max_file_size = 50 * 1024 * 1024;
        $file_type = mime_content_type($_FILES['video']['tmp_name']);
        if (!in_array($file_type, $allowed_video_types) || $_FILES['video']['size'] > $max_file_size) {
            throw new Exception("Video không hợp lệ hoặc quá lớn");
        }
        $video_name = uniqid('video_') . '.' . pathinfo($_FILES['video']['name'], PATHINFO_EXTENSION);
        $video_path = $video_dir . $video_name;
        if (move_uploaded_file($_FILES['video']['tmp_name'], $video_path)) {
            if ($video && file_exists($video)) {
                unlink($video);
            }
            $video = $video_path;
        } else {
            throw new Exception("Không thể upload video");
        }
    }

    $conn->beginTransaction();

    // Cập nhật món ăn
    $sql = "UPDATE monan SET ten_monan = :ten_monan, hinh_anh = :hinh_anh, video = :video, khau_phan = :khau_phan, 
            do_kho = :do_kho, calo = :calo, ma_chedo = :ma_chedo, ma_dinhduong = :ma_dinhduong, cong_thuc = :cong_thuc, 
            ghi_chu = :ghi_chu WHERE ma_monan = :ma_monan";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        'ma_monan' => $ma_monan,
        'ten_monan' => $ten_monan,
        'hinh_anh' => $hinh_anh,
        'video' => $video,
        'khau_phan' => $khau_phan,
        'do_kho' => $do_kho,
        'calo' => $calo,
        'ma_chedo' => $ma_chedo ?: null,
        'ma_dinhduong' => $ma_dinhduong ?: null,
        'cong_thuc' => $cong_thuc,
        'ghi_chu' => $ghi_chu ?: null
    ]);

    // Xóa danh mục cũ và thêm lại
    $sql = "DELETE FROM monan_danhmuc WHERE ma_monan = :ma_monan";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_monan' => $ma_monan]);

    if (!empty($categories)) {
        $sql = "INSERT INTO monan_danhmuc (ma_monan, ma_danhmuc) VALUES (:ma_monan, :ma_danhmuc)";
        $stmt = $conn->prepare($sql);
        foreach (array_keys($categories) as $ma_danhmuc) {
            $stmt->execute(['ma_monan' => $ma_monan, 'ma_danhmuc' => $ma_danhmuc]);
        }
    }

    // Xóa nguyên liệu cũ và nguyên liệu thay thế cũ
    $sql = "DELETE FROM monan_nguyenlieu WHERE ma_monan = :ma_monan";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_monan' => $ma_monan]);

    $sql = "DELETE FROM nguyenlieu_thaythe WHERE ma_monan = :ma_monan";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_monan' => $ma_monan]);

    // Thêm nguyên liệu chính và số gram
    if (!empty($ingredients)) {
        $sql_nguyenlieu = "INSERT INTO monan_nguyenlieu (ma_monan, ma_nguyenlieu, so_gram) VALUES (:ma_monan, :ma_nguyenlieu, :so_gram)";
        $stmt_nguyenlieu = $conn->prepare($sql_nguyenlieu);

        $sql_thaythe = "INSERT INTO nguyenlieu_thaythe (ma_monan, ma_nguyenlieu_chinh, ma_nguyenlieu_thaythe) 
                        VALUES (:ma_monan, :ma_nguyenlieu_chinh, :ma_nguyenlieu_thaythe)";
        $stmt_thaythe = $conn->prepare($sql_thaythe);

        foreach ($ingredients as $ma_nguyenlieu => $data) {
            if (isset($data['selected']) && $data['selected']) {
                // Thêm nguyên liệu chính với số gram
                $so_gram = !empty($data['so_gram']) ? floatval($data['so_gram']) : null;
                $stmt_nguyenlieu->execute([
                    'ma_monan' => $ma_monan,
                    'ma_nguyenlieu' => $ma_nguyenlieu,
                    'so_gram' => $so_gram
                ]);

                // Xử lý nguyên liệu thay thế
                if (!empty($data['thaythe'])) {
                    $ten_thaythe = htmlspecialchars(trim($data['thaythe']), ENT_QUOTES, 'UTF-8');

                    // Kiểm tra xem nguyên liệu thay thế đã tồn tại chưa
                    $sql_check = "SELECT ma_nguyenlieu FROM nguyenlieu WHERE ten_nguyenlieu = :ten_nguyenlieu";
                    $stmt_check = $conn->prepare($sql_check);
                    $stmt_check->execute(['ten_nguyenlieu' => $ten_thaythe]);
                    $existing_ingredient = $stmt_check->fetch(PDO::FETCH_ASSOC);

                    if ($existing_ingredient) {
                        $ma_nguyenlieu_thaythe = $existing_ingredient['ma_nguyenlieu'];
                    } else {
                        // Thêm nguyên liệu thay thế mới vào bảng nguyenlieu
                        $sql_insert = "INSERT INTO nguyenlieu (ten_nguyenlieu) VALUES (:ten_nguyenlieu)";
                        $stmt_insert = $conn->prepare($sql_insert);
                        $stmt_insert->execute(['ten_nguyenlieu' => $ten_thaythe]);
                        $ma_nguyenlieu_thaythe = $conn->lastInsertId();
                    }

                    // Thêm vào bảng nguyenlieu_thaythe
                    $stmt_thaythe->execute([
                        'ma_monan' => $ma_monan,
                        'ma_nguyenlieu_chinh' => $ma_nguyenlieu,
                        'ma_nguyenlieu_thaythe' => $ma_nguyenlieu_thaythe
                    ]);
                }
            }
        }
    }

    // Xóa thành phần dinh dưỡng cũ và thêm lại
    $sql = "DELETE FROM monan_thanhphandinhduong WHERE ma_monan = :ma_monan";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_monan' => $ma_monan]);

    if (!empty($components)) {
        $sql = "INSERT INTO monan_thanhphandinhduong (ma_monan, ma_thanhphan, phantram) 
                VALUES (:ma_monan, :ma_thanhphan, :phantram)";
        $stmt = $conn->prepare($sql);
        foreach ($components as $ma_thanhphan => $data) {
            if (isset($data['selected']) && $data['selected']) {
                $phantram = $data['phantram'] ?? 0;
                $stmt->execute([
                    'ma_monan' => $ma_monan,
                    'ma_thanhphan' => $ma_thanhphan,
                    'phantram' => $phantram
                ]);
            }
        }
    }

    $conn->commit();
    header("Location: manage_dishes.php?success=Món ăn đã được cập nhật thành công");
    exit();
} catch (Exception $e) {
    $conn->rollBack();
    $log_file = __DIR__ . '/logs/debug.log';
    $log_dir = dirname($log_file);
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - Error: " . $e->getMessage() . "\n", FILE_APPEND);
    header("Location: edit_dish.php?id=$ma_monan&error=" . urlencode($e->getMessage()));
    exit();
}
?>