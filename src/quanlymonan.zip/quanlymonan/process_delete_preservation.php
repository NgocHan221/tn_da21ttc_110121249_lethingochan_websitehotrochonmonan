<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: manage_preservation.php");
    exit();
}

$preservation_id = $_GET['id'];
$conn->beginTransaction();
try {
    $sql = "DELETE FROM menu_suggestions WHERE preservation_id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $preservation_id]);

    $sql = "DELETE FROM preservation WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $preservation_id]);

    $conn->commit();
    header("Location: manage_preservation.php?success=Xóa bài viết bảo quản thành công");
    exit();
} catch (Exception $e) {
    $conn->rollBack();
    header("Location: manage_preservation.php?error=Lỗi khi xóa bài viết");
    exit();
}
?>