<?php
session_start();
require_once 'connect.php';

// Generate CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

error_log("detail.php: user_id=" . ($_SESSION['user_id'] ?? 'not set')); // Debug

if (!isset($_GET['id'])) {
    header("Location: index.php?error=missing_id");
    exit();
}

$dish_id = (int)$_GET['id'];
try {
    $sql = "SELECT m.*, c.ten_chedo, n.ten_dinhduong 
            FROM monan m 
            LEFT JOIN chedo c ON m.ma_chedo = c.ma_chedo 
            LEFT JOIN dinhduong n ON m.ma_dinhduong = n.ma_dinhduong 
            WHERE m.ma_monan = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $dish_id]);
    $dish = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$dish) {
        header("Location: index.php?error=dish_not_found");
        exit();
    }

    // Fetch categories
    $sql = "SELECT d.ten_danhmuc 
            FROM monan_danhmuc md 
            JOIN danhmuc d ON md.ma_danhmuc = d.ma_danhmuc 
            WHERE md.ma_monan = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $dish_id]);
    $categories = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Fetch ingredients
    $sql = "SELECT n.ten_nguyenlieu, mn.so_gram, GROUP_CONCAT(nt.ten_nguyenlieu) AS thaythe 
            FROM monan_nguyenlieu mn 
            JOIN nguyenlieu n ON mn.ma_nguyenlieu = n.ma_nguyenlieu 
            LEFT JOIN nguyenlieu_thaythe ntth ON mn.ma_monan = ntth.ma_monan AND mn.ma_nguyenlieu = ntth.ma_nguyenlieu_chinh 
            LEFT JOIN nguyenlieu nt ON ntth.ma_nguyenlieu_thaythe = nt.ma_nguyenlieu 
            WHERE mn.ma_monan = :id 
            GROUP BY n.ten_nguyenlieu, mn.so_gram";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $dish_id]);
    $ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch nutritional components
    $sql = "SELECT t.ten_thanhphan, mt.phantram 
            FROM monan_thanhphandinhduong mt 
            JOIN thanhphandinhduong t ON mt.ma_thanhphan = t.ma_thanhphan 
            WHERE mt.ma_monan = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $dish_id]);
    $components = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch comments
    $sql = "SELECT f.id, f.content, f.rating, f.created_at, f.is_admin, f.parent_id, u.ten_dangnhap, u.ho_ten 
            FROM feedback f 
            JOIN nguoidung u ON f.ma_nguoidung = u.ma_nguoidung 
            WHERE f.ma_monan = :id AND f.is_deleted = 0 
            ORDER BY f.created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $dish_id]);
    $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Check favorite status
    $is_favorited = false;
    if (isset($_SESSION['user_id'])) {
        $sql = "SELECT COUNT(*) FROM favorites WHERE ma_nguoidung = :user_id AND ma_monan = :dish_id";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['user_id' => $_SESSION['user_id'], 'dish_id' => $dish_id]);
        $is_favorited = $stmt->fetchColumn() > 0;
    }

    // Handle comment submission
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id']) && isset($_POST['content'])) {
        $content = trim(strip_tags($_POST['content']));
        $parent_id = $_POST['parent_id'] ?? null;
        $rating = filter_var($_POST['rating'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 5]]);
        
        if (empty($content) || (isset($_POST['rating']) && $rating === false)) {
            header("Location: detail.php?id=$dish_id&error=invalid_comment");
            exit();
        }

        $sql = "INSERT INTO feedback (ma_nguoidung, ma_monan, parent_id, content, rating, created_at, is_admin) 
                VALUES (:ma_nguoidung, :ma_monan, :parent_id, :content, :rating, NOW(), 0)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            'ma_nguoidung' => $_SESSION['user_id'],
            'ma_monan' => $dish_id,
            'parent_id' => $parent_id,
            'content' => $content,
            'rating' => $rating
        ]);

        // Notify admin
        $sql = "SELECT ma_nguoidung FROM nguoidung WHERE vai_tro = 'admin' LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        if ($admin_id = $stmt->fetchColumn()) {
            $sql = "INSERT INTO notifications (ma_nguoidung, message, created_at, is_read) 
                    VALUES (:ma_nguoidung, :message, NOW(), 0)";
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                'ma_nguoidung' => $admin_id,
                'message' => "Người dùng {$_SESSION['ten_dangnhap']} đã thêm bình luận mới cho món ăn {$dish['ten_monan']}."
            ]);
        }

        header("Location: detail.php?id=$dish_id");
        exit();
    }
} catch (PDOException $e) {
    error_log("detail.php: Database error: " . $e->getMessage());
    header("Location: index.php?error=database");
    exit();
}

// Create share URL
$current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$share_title = urlencode($dish['ten_monan']);
$share_description = urlencode("Xem công thức món " . $dish['ten_monan'] . " tại đây!");
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi tiết món ăn - <?php echo htmlspecialchars($dish['ten_monan']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            line-height: 1.6;
            background: #f3f4f6;
        }
        .larger-text {
            font-size: 1.25rem;
        }
        h3.larger-text, .recipe-title {
            font-size: 1.75rem;
            font-weight: 700;
            color: #1f2937;
            border-bottom: 2px solid #3b82f6;
            padding-bottom: 0.5rem;
            margin-bottom: 1.5rem;
        }
        .video-container {
            margin-top: 1rem;
            width: 100%;
            display: flex;
            justify-content: center;
        }
        .dish-video {
            width: 100%;
            max-width: 800px;
            height: auto;
            object-fit: cover;
            border-radius: 0.5rem;
            border: 2px solid #e2e8f0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .comment-section {
            margin-top: 2rem;
        }
        .comment-card {
            background: #f8fafc;
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            border: 1px solid #e2e8f0;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .comment-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .comment-card.reply {
            margin-left: 2.5rem;
            background: #f1f5f9;
            border-left: 3px solid #3b82f6;
        }
        .comment-card .comment-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        .comment-card .comment-header .user-info {
            font-weight: 600;
            color: #1f2937;
        }
        .comment-card .comment-header .admin-badge {
            background: #3b82f6;
            color: white;
            padding: 0.2rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.75rem;
        }
        .comment-card .comment-content {
            color: #4b5563;
        }
        .comment-card .comment-actions {
            margin-top: 0.5rem;
            display: flex;
            gap: 0.5rem;
        }
        .comment-form {
            margin-top: 1rem;
            background: #ffffff;
            padding: 1rem;
            border-radius: 0.5rem;
            border: 1px solid #e2e8f0;
        }
        .comment-form textarea {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #e2e8f0;
            border-radius: 0.375rem;
            resize: vertical;
        }
        .comment-form .rating {
            margin-bottom: 0.5rem;
        }
        .comment-form .rating label {
            margin-right: 0.5rem;
            font-weight: 600;
        }
        .star-rating {
            display: inline-flex;
            gap: 0.25rem;
            cursor: pointer;
        }
        .star {
            font-size: 1.5rem;
            color: #d1d5db;
            transition: color 0.2s ease;
        }
        .star.selected,
        .star:hover,
        .star:hover ~ .star {
            color: #f59e0b;
        }
        .star-rating:hover .star {
            color: #d1d5db;
        }
        .star-rating .star:hover,
        .star-rating .star.selected {
            color: #f59e0b;
        }
        .favorite-btn, .share-btn, .preservation-btn, .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            font-weight: 500;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.3s ease;
        }
        .favorite-btn.favorited {
            background: #ef4444;
            color: white;
        }
        .favorite-btn.favorited:hover {
            background: #dc2626;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }
        .favorite-btn:not(.favorited) {
            background: #3b82f6;
            color: white;
        }
        .favorite-btn:not(.favorited):hover {
            background: #2563eb;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }
        .share-btn {
            background: #10b981;
            color: white;
        }
        .share-btn:hover {
            background: #059669;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }
        .preservation-btn {
            background: #8b5cf6;
            color: white;
        }
        .preservation-btn:hover {
            background: #7c3aed;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }
        .back-btn {
            background: #6b7280;
            color: white;
        }
        .back-btn:hover {
            background: #4b5563;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }
        .share-menu {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 0.375rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            z-index: 10;
            min-width: 150px;
            transition: opacity 0.3s ease, transform 0.3s ease;
            transform: translateY(-10px);
        }
        .share-menu.show {
            display: block;
            transform: translateY(0);
        }
        .share-menu a {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            color: #1f2937;
            font-size: 0.875rem;
            transition: background 0.2s ease;
        }
        .share-menu a:hover {
            background: #f3f4f6;
        }
        .share-menu a i {
            font-size: 1rem;
        }
        .button-group {
            display: flex;
            gap: 1rem;
            justify-content: center;
            position: relative;
        }
        .navbar {
            background: linear-gradient(145deg, #4f46e5, #10b981);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 50;
        }
        .navbar-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        .nav-logo {
            font-size: 1.75rem;
            font-weight: 800;
            color: #ffffff;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .nav-logo:hover {
            color: #fef08a;
        }
        .nav-menu {
            display: flex;
            gap: 0.75rem;
            align-items: center;
        }
        .nav-menu a {
            color: #e5e7eb;
            font-size: 1rem;
            font-weight: 500;
            text-decoration: none;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            transition: background-color 0.3s ease, color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }
        .nav-menu a:hover {
            background-color: #6b7280;
            color: #ffffff;
        }
        .nav-user-section {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .user-dropdown {
            position: relative;
        }
        .user-button {
            color: #e5e7eb;
            font-size: 1rem;
            font-weight: 500;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            background: transparent;
            transition: background-color 0.3s ease, color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }
        .user-button:hover {
            background-color: #6b7280;
            color: #ffffff;
        }
        .user-dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: #ffffff;
            border-radius: 0.375rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            min-width: 160px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: opacity 0.3s ease, transform 0.3s ease, visibility 0.3s ease;
            z-index: 100;
        }
        .user-dropdown:hover .user-dropdown-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        .user-dropdown-menu a {
            display: block;
            padding: 0.5rem 1rem;
            color: #1f2937;
            font-size: 0.875rem;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .user-dropdown-menu a:hover {
            background-color: #f3f4f6;
        }
        .logout-link {
            color: white;
            font-size: 1rem;
            font-weight: 500;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            text-decoration: none;
            transition: background 0.3s ease, transform 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }
        .logout-link:hover {
            background: linear-gradient(to right, #2563eb, #1d4ed8);
            transform: scale(1.02);
        }
        .hamburger {
            display: none;
            flex-direction: column;
            cursor: pointer;
            gap: 0.25rem;
        }
        .hamburger span {
            width: 24px;
            height: 3px;
            background: #e5e7eb;
            border-radius: 2px;
            transition: all 0.3s ease;
        }
        .hamburger.active span:nth-child(1) {
            transform: rotate(45deg) translate(5px, 5px);
        }
        .hamburger.active span:nth-child(2) {
            opacity: 0;
        }
        .hamburger.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -7px);
        }
        .chart-container {
            max-width: 800px;
            margin: 2rem auto;
        }
        @media (max-width: 767px) {
            .dish-video {
                max-width: 100%;
            }
            .navbar-container {
                flex-wrap: wrap;
            }
            .nav-logo {
                flex: 0 0 auto;
            }
            .nav-menu {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: #4f46e5;
                flex-direction: column;
                padding: 1rem;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }
            .nav-menu.active {
                display: flex;
            }
            .nav-menu a {
                padding: 0.75rem;
                width: 100%;
                text-align: left;
                font-size: 1rem;
            }
            .nav-user-section {
                display: none;
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
                padding: 1rem;
                width: 100%;
            }
            .nav-user-section.active {
                display: flex;
            }
            .user-dropdown {
                width: 100%;
            }
            .user-dropdown-menu {
                position: static;
                background: #6b7280;
                box-shadow: none;
                transform: none;
                opacity: 1;
                visibility: visible;
                margin-top: 0.5rem;
                width: 100%;
            }
            .user-dropdown-menu a {
                color: #e5e7eb;
            }
            .user-dropdown-menu a:hover {
                background-color: #4b5563;
            }
            .logout-link {
                width: 100%;
                text-align: left;
                color: white;
            }
            .logout-link:hover {
                color: white;
            }
            .hamburger {
                display: flex;
            }
        }
        .custom-title {
            font-size: 40px;
            font-weight: bold;
            margin-bottom: 1rem;
            text-align: center;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <div class="flex items-center gap-4">
                <div class="hamburger" id="hamburger" aria-expanded="false">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="nav-menu" id="nav-menu">
                    <a href="index.php"><i class="fas fa-home"></i> Trang chủ</a>
                    <a href="nutrients.php"><i class="fas fa-seedling"></i> Dinh dưỡng</a>
                    <a href="suggest_dishes.php"><i class="fas fa-utensils"></i> Gợi ý theo nguyên liệu</a>
                    <a href="favorites.php"><i class="fas fa-heart"></i> Món ăn yêu thích</a>
                    <a href="menu.php"><i class="fas fa-calendar-alt"></i> Thực đơn</a>
                    <a href="nutrition_chart.php"><i class="fas fa-chart-bar"></i> Biểu đồ dinh dưỡng</a>
                </div>
                <div class="nav-user-section" id="nav-user-section">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <div class="user-dropdown">
                            <button class="user-button">
                                <i class="fas fa-user mr-2"></i>
                                <span><?php echo htmlspecialchars(isset($_SESSION['ten_dangnhap']) && !empty($_SESSION['ten_dangnhap']) ? $_SESSION['ten_dangnhap'] : 'Người dùng'); ?></span>
                            </button>
                            <div class="user-dropdown-menu">
                                <a href="profile.php">Hồ sơ</a>
                            </div>
                        </div>
                        <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt mr-2"></i>Đăng xuất</a>
                    <?php else: ?>
                        <a href="login.php" class="user-button">
                            <i class="fas fa-sign-in-alt mr-2"></i> Đăng nhập
                        </a>
                        <a href="register.php" class="user-button">
                            <i class="fas fa-user-plus mr-2"></i> Đăng ký
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="p-6">
        <a href="index.php" class="back-btn mb-4">
            <i class="fas fa-arrow-left"></i>
            <span>Quay lại</span>
        </a>
        <h1 class="custom-title"><?php echo htmlspecialchars($dish['ten_monan']); ?></h1>
        <div class="bg-white p-6 rounded-lg shadow-lg mt-4">
            <?php if ($dish['video']): ?>
                <div class="video-container">
                    <video controls class="dish-video">
                        <source src="<?php echo htmlspecialchars($dish['video']); ?>" type="video/mp4">
                        Trình duyệt của bạn không hỗ trợ video.
                    </video>
                </div>
                <div class="mt-4 button-group">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <button id="favorite-btn" class="favorite-btn <?php echo $is_favorited ? 'favorited' : ''; ?>" 
                                data-dish-id="<?php echo $dish_id; ?>" 
                                data-csrf-token="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <i class="fas fa-heart"></i>
                            <span><?php echo $is_favorited ? 'Bỏ yêu thích' : 'Yêu thích'; ?></span>
                        </button>
                    <?php endif; ?>
                    <div class="relative">
                        <button id="share-btn" class="share-btn">
                            <i class="fas fa-share-alt"></i>
                            <span>Chia sẻ</span>
                        </button>
                        <div id="share-menu" class="share-menu">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode($current_url); ?>" target="_blank">
                                <i class="fab fa-facebook-f"></i> Facebook
                            </a>
                            <a href="#" onclick="copyLink('<?php echo $current_url; ?>'); return false;">
                                <i class="fas fa-link"></i> Sao chép liên kết
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <br>
            <p class="larger-text"><strong>Khẩu phần:</strong> <?php echo htmlspecialchars($dish['khau_phan']); ?> người</p>
            <p class="larger-text"><strong>Độ khó:</strong> <?php echo htmlspecialchars($dish['do_kho']); ?></p>
            <p class="larger-text"><strong>Calo:</strong> <?php echo htmlspecialchars($dish['calo']); ?> kcal</p>
            <p class="larger-text"><strong>Danh mục:</strong> <?php echo !empty($categories) ? htmlspecialchars(implode(', ', $categories)) : 'Chưa có'; ?></p>
            <p class="larger-text"><strong>Chế độ:</strong> <?php echo htmlspecialchars($dish['ten_chedo'] ?? 'Chưa có'); ?></p>
            <p class="larger-text"><strong>Dinh dưỡng:</strong> <?php echo htmlspecialchars($dish['ten_dinhduong'] ?? 'Chưa có'); ?></p>
            <p class="larger-text"><strong>Nguyên liệu:</strong></p>
            <ul class="list-disc pl-5 larger-text">
                <?php foreach ($ingredients as $ingredient): ?>
                    <li>
                        <?php echo htmlspecialchars($ingredient['ten_nguyenlieu']); ?>: 
                        <?php echo !empty($ingredient['so_gram']) ? htmlspecialchars($ingredient['so_gram']) . 'g' : 'Chưa xác định'; ?>
                        <?php if (!empty($ingredient['thaythe'])): ?>
                            <span class="text-gray-500">(Thay thế: <?php echo htmlspecialchars($ingredient['thaythe']); ?>)</span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
            <?php if (!empty($dish['ghi_chu'])): ?>
                <p class="larger-text mt-4"><strong>Ghi chú:</strong> <?php echo htmlspecialchars($dish['ghi_chu']); ?></p>
            <?php endif; ?>
            <p class="recipe-title mt-4">Công thức:</p>
            <div class="larger-text whitespace-pre-wrap"><?php echo $dish['cong_thuc']; ?></div>
            <h3 class="mt-6 text-xl font-semibold larger-text">Thành phần dinh dưỡng:</h3>
            <div class="chart-container">
                <canvas id="nutritionChart"></canvas>
            </div>
            <div class="mt-4 text-center">
                <a href="preservation.php?id=<?php echo $dish_id; ?>" class="preservation-btn">
                    <i class="fas fa-leaf"></i>
                    <span>Dinh dưỡng của thực phẩm</span>
                </a>
            </div>
            <div class="comment-section">
                <h3 class="mt-6 text-xl font-semibold larger-text">Bình luận</h3>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="comment-form">
                        <form method="POST">
                            <div class="rating">
                                <label class="mr-2 font-semibold">Đánh giá:</label>
                                <div class="star-rating" role="radiogroup">
                                    <span class="star" data-value="1">★</span>
                                    <span class="star" data-value="2">★</span>
                                    <span class="star" data-value="3">★</span>
                                    <span class="star" data-value="4">★</span>
                                    <span class="star" data-value="5">★</span>
                                    <input type="hidden" name="rating" id="rating-input">
                                </div>
                            </div>
                            <textarea name="content" rows="4" placeholder="Viết bình luận của bạn..." required></textarea>
                            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 mt-2">Gửi bình luận</button>
                        </form>
                    </div>
                <?php else: ?>
                    <p class="larger-text mt-4">Vui lòng <a href="login.php" class="text-blue-500 hover:underline">đăng nhập</a> để gửi bình luận.</p>
                <?php endif; ?>
                <?php
                $comment_tree = [];
                foreach ($comments as $comment) {
                    $comment_tree[$comment['parent_id'] ?? 0][] = $comment;
                }

                function display_comments($comments, $comment_tree, $parent_id = 0, $level = 0) {
                    if (!isset($comment_tree[$parent_id])) return;
                    foreach ($comment_tree[$parent_id] as $comment) {
                        ?>
                        <div class="comment-card <?php echo $comment['parent_id'] ? 'reply' : ''; ?>">
                            <div class="comment-header">
                                <div class="user-info">
                                    <?php echo htmlspecialchars($comment['ho_ten'] ?: $comment['ten_dangnhap']); ?>
                                    <?php if ($comment['is_admin']): ?>
                                        <span class="admin-badge">Admin</span>
                                    <?php endif; ?>
                                </div>
                                <div class="text-gray-500 text-sm">
                                    <?php echo date('d/m/Y H:i', strtotime($comment['created_at'])); ?>
                                </div>
                            </div>
                            <div class="comment-content larger-text">
                                <?php echo htmlspecialchars($comment['content']); ?>
                                <?php if ($comment['rating']): ?>
                                    <div class="mt-1 text-yellow-500">
                                        <?php echo str_repeat('★', $comment['rating']) . str_repeat('☆', 5 - $comment['rating']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="comment-actions">
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <button class="text-blue-500 hover:underline text-sm reply-btn" 
                                            data-comment-id="<?php echo $comment['id']; ?>">
                                        Trả lời
                                    </button>
                                <?php endif; ?>
                            </div>
                            <?php if (isset($_SESSION['user_id'])): ?>
                                <div class="comment-form reply-form hidden" id="reply-form-<?php echo $comment['id']; ?>">
                                    <form method="POST">
                                        <input type="hidden" name="parent_id" value="<?php echo $comment['id']; ?>">
                                        <textarea name="content" rows="3" placeholder="Viết trả lời của bạn..." required></textarea>
                                        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 mt-2">Gửi trả lời</button>
                                        <button type="button" class="text-gray-500 hover:underline ml-2 cancel-reply-btn">Hủy</button>
                                    </form>
                                </div>
                            <?php endif; ?>
                            <?php display_comments($comments, $comment_tree, $comment['id'], $level + 1); ?>
                        </div>
                        <?php
                    }
                }

                display_comments($comments, $comment_tree);
                ?>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Initialize Chart.js
            const ctx = document.getElementById('nutritionChart').getContext('2d');
            const components = <?php echo json_encode($components); ?>;
            const labels = components.map(c => c.ten_thanhphan);
            const data = components.map(c => parseFloat(c.phantram));
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Lượng (g)',
                        data: data,
                        backgroundColor: [
                            'rgba(59, 130, 246, 0.7)',
                            'rgba(16, 185, 129, 0.7)',
                            'rgba(239, 68, 68, 0.7)',
                            'rgba(139, 92, 246, 0.7)',
                            'rgba(245, 158,11, 0.7)'
                        ],
                        borderColor: [
                            '#1e40af',
                            '#047857',
                            '#b91c1c',
                            '#6d28d9',
                            '#b45309'
                        ],
                        borderWidth: 1,
                        hoverBackgroundColor: [
                            'rgba(59, 130, 246, 0.9)',
                            'rgba(16, 185, 129, 0.9)',
                            'rgba(239, 68, 68, 0.9)',
                            'rgba(139, 92, 246, 0.9)',
                            'rgba(245, 158, 11, 0.9)'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top',
                            labels: {
                                font: {
                                    size: 14,
                                    weight: 'bold'
                                },
                                color: '#1f2937'
                            }
                        },
                        tooltip: {
                            backgroundColor: '#1f2937',
                            titleFont: { size: 14, weight: 'bold' },
                            bodyFont: { size: 12 },
                            callbacks: {
                                label: function(context) {
                                    return `${context.dataset.label}: ${context.raw} g`;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Lượng (g)',
                                font: { size: 14, weight: 'bold' },
                                color: '#1f2937'
                            },
                            ticks: { font: { size: 12 }, color: '#4b5563' },
                            grid: { color: '#e5e7eb' }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Thành phần',
                                font: { size: 14, weight: 'bold' },
                                color: '#1f2937'
                            },
                            ticks: {
                                font: { size: 12 },
                                color: '#4b5563',
                                autoSkip: false,
                                maxRotation: 45,
                                minRotation: 45
                            },
                            grid: { display: false }
                        }
                    },
                    animation: {
                        duration: 1000,
                        easing: 'easeOutQuart'
                    }
                }
            });

            // Star rating
            const stars = document.querySelectorAll('.star');
            const ratingInput = document.getElementById('rating-input');
            stars.forEach(star => {
                star.addEventListener('click', () => {
                    const value = star.getAttribute('data-value');
                    ratingInput.value = value;
                    stars.forEach(s => {
                        s.classList.toggle('selected', s.getAttribute('data-value') <= value);
                    });
                });
                star.addEventListener('mouseover', () => {
                    const value = star.getAttribute('data-value');
                    stars.forEach(s => {
                        s.classList.toggle('selected', s.getAttribute('data-value') <= value);
                    });
                });
                star.addEventListener('mouseout', () => {
                    const selectedValue = ratingInput.value || 0;
                    stars.forEach(s => {
                        s.classList.toggle('selected', s.getAttribute('data-value') <= selectedValue);
                    });
                });
            });

            // Share button
            const shareBtn = document.getElementById('share-btn');
            const shareMenu = document.getElementById('share-menu');
            shareBtn?.addEventListener('click', () => {
                shareMenu.classList.toggle('show');
            });
            document.addEventListener('click', (e) => {
                if (!shareBtn.contains(e.target) && !shareMenu.contains(e.target)) {
                    shareMenu.classList.remove('show');
                }
            });

            function copyLink(url) {
                navigator.clipboard.writeText(url).then(() => {
                    alert('Đã sao chép liên kết!');
                });
            }

            // Favorite button
            const favoriteBtn = document.getElementById('favorite-btn');
            favoriteBtn?.addEventListener('click', () => {
                const dishId = favoriteBtn.dataset.dishId;
                const csrfToken = favoriteBtn.dataset.csrfToken;
                if (!dishId || isNaN(dishId)) {
                    alert('ID món ăn không hợp lệ');
                    return;
                }
                if (!csrfToken) {
                    alert('Lỗi bảo mật: CSRF token không tồn tại');
                    return;
                }
                const isFavorited = favoriteBtn.classList.contains('favorited');
                const action = isFavorited ? 'remove' : 'add';
                console.log('Sending request:', { dishId, action, csrfToken });
                fetch('process_favorite.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `dish_id=${dishId}&action=${action}&csrf_token=${encodeURIComponent(csrfToken)}`
                })
                .then(response => {
                    console.log('Response status:', response.status, 'ok:', response.ok);
                    if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
                    return response.json();
                })
                .then(data => {
                    console.log('Response data:', data);
                    if (data.success) {
                        favoriteBtn.classList.toggle('favorited');
                        favoriteBtn.querySelector('span').textContent = isFavorited ? 'Yêu thích' : 'Bỏ yêu thích';
                        alert(data.message || (isFavorited ? 'Đã bỏ yêu thích' : 'Đã thêm vào yêu thích'));
                    } else {
                        alert(data.message || 'Đã có lỗi xảy ra');
                    }
                })
                .catch(error => {
                    console.error('Fetch error:', error);
                    alert('Lỗi kết nối: ' + error.message);
                });
            });

            // Reply comments
            document.querySelectorAll('.reply-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const commentId = btn.dataset.commentId;
                    const replyForm = document.getElementById(`reply-form-${commentId}`);
                    replyForm.classList.toggle('hidden');
                });
            });

            document.querySelectorAll('.cancel-reply-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const replyForm = btn.closest('.reply-form');
                    replyForm.classList.add('hidden');
                });
            });

            // Hamburger menu
            const hamburger = document.getElementById('hamburger');
            const navMenu = document.getElementById('nav-menu');
            const navUserSection = document.getElementById('nav-user-section');
            hamburger.addEventListener('click', () => {
                const isActive = hamburger.classList.toggle('active');
                hamburger.setAttribute('aria-expanded', isActive);
                navMenu.classList.toggle('active');
                navUserSection.classList.toggle('active');
            });

            document.querySelectorAll('.nav-menu a, .nav-user-section a').forEach(link => {
                link.addEventListener('click', () => {
                    if (window.innerWidth <= 767) {
                        hamburger.classList.remove('active');
                        hamburger.setAttribute('aria-expanded', 'false');
                        navMenu.classList.remove('active');
                        navUserSection.classList.remove('active');
                    }
                });
            });
        });
    </script>
</body>
</html>

