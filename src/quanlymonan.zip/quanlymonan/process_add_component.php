<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ten_thanhphan = $_POST['ten_thanhphan'];

    // Kiểm tra tên thành phần đã tồn tại
    $sql = "SELECT * FROM thanhphandinhduong WHERE ten_thanhphan = :ten_thanhphan";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_thanhphan' => $ten_thanhphan]);
    if ($stmt->rowCount() > 0) {
        header("Location: add_component.php?error=Tên thành phần đã tồn tại");
        exit();
    }

    // Thêm thành phần mới
    $sql = "INSERT INTO thanhphandinhduong (ten_thanhphan) VALUES (:ten_thanhphan)";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_thanhphan' => $ten_thanhphan]);

    header("Location: manage_components.php");
    exit();
}
?>