<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

$ma_dinhduong = $_POST['ma_dinhduong'] ?? 0;
$ten_dinhduong = $_POST['ten_dinhduong'] ?? '';

// Lấy thông tin dinh dưỡng hiện tại
$sql = "SELECT hinh_anh FROM dinhduong WHERE ma_dinhduong = :ma_dinhduong";
$stmt = $conn->prepare($sql);
$stmt->execute(['ma_dinhduong' => $ma_dinhduong]);
$current_nutrient = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$current_nutrient) {
    header("Location: manage_nutrients.php?error=Dinh dưỡng không tồn tại");
    exit();
}

// Xử lý upload hình ảnh mới (nếu có)
$hinh_anh = $current_nutrient['hinh_anh'];
if (isset($_FILES['hinh_anh']) && $_FILES['hinh_anh']['error'] == 0) {
    $upload_dir = 'uploads/images/';
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    $filename = uniqid('nutrient_') . '.' . pathinfo($_FILES['hinh_anh']['name'], PATHINFO_EXTENSION);
    $destination = $upload_dir . $filename;
    if (move_uploaded_file($_FILES['hinh_anh']['tmp_name'], $destination)) {
        // Xóa hình ảnh cũ nếu có
        if ($hinh_anh && file_exists($hinh_anh)) {
            unlink($hinh_anh);
        }
        $hinh_anh = $destination;
    } else {
        header("Location: edit_nutrient.php?id=$ma_dinhduong&error=Không thể tải hình ảnh lên");
        exit;
    }
}

// Cập nhật dinh dưỡng
$sql = "UPDATE dinhduong SET ten_dinhduong = :ten_dinhduong, hinh_anh = :hinh_anh WHERE ma_dinhduong = :ma_dinhduong";
$stmt = $conn->prepare($sql);
$stmt->execute([
    'ma_dinhduong' => $ma_dinhduong,
    'ten_dinhduong' => $ten_dinhduong,
    'hinh_anh' => $hinh_anh
]);

header("Location: manage_nutrients.php?success=Dinh dưỡng đã được cập nhật thành công");
exit;