<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ten_nguyenlieu = $_POST['ten_nguyenlieu'];

    // Kiểm tra tên nguyên liệu đã tồn tại
    $sql = "SELECT * FROM nguyenlieu WHERE ten_nguyenlieu = :ten_nguyenlieu";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_nguyenlieu' => $ten_nguyenlieu]);
    if ($stmt->rowCount() > 0) {
        header("Location: add_ingredient.php?error=Tên nguyên liệu đã tồn tại");
        exit();
    }

    // Thêm nguyên liệu mới
    $sql = "INSERT INTO nguyenlieu (ten_nguyenlieu) VALUES (:ten_nguyenlieu)";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_nguyenlieu' => $ten_nguyenlieu]);

    header("Location: manage_ingredients.php");
    exit();
}
?>