<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ma_danhmuc = $_POST['ma_danhmuc'];
    $ten_danhmuc = $_POST['ten_danhmuc'];

    // Kiểm tra tên danh mục đã tồn tại (trừ danh mục hiện tại)
    $sql = "SELECT * FROM danhmuc WHERE ten_danhmuc = :ten_danhmuc AND ma_danhmuc != :ma_danhmuc";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_danhmuc' => $ten_danhmuc, 'ma_danhmuc' => $ma_danhmuc]);
    if ($stmt->rowCount() > 0) {
        header("Location: edit_category.php?id=$ma_danhmuc&error=Tên danh mục đã tồn tại");
        exit();
    }

    // Cập nhật danh mục
    $sql = "UPDATE danhmuc SET ten_danhmuc = :ten_danhmuc WHERE ma_danhmuc = :ma_danhmuc";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_danhmuc' => $ten_danhmuc, 'ma_danhmuc' => $ma_danhmuc]);

    header("Location: manage_categories.php");
    exit();
}
?>