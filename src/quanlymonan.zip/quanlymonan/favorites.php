<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Lấy danh sách món ăn yêu thích
$sql = "SELECT m.*, d.ten_danhmuc, c.ten_chedo 
        FROM favorites f 
        JOIN monan m ON f.ma_monan = m.ma_monan 
        LEFT JOIN danhmuc d ON m.ma_danhmuc = d.ma_danhmuc 
        LEFT JOIN chedo c ON m.ma_chedo = c.ma_chedo 
        WHERE f.ma_nguoidung = :user_id 
        ORDER BY f.created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->execute(['user_id' => $_SESSION['user_id']]);
$dishes = $stmt->fetchAll(PDO::FETCH_ASSOC);

error_log("favorites.php: Number of favorite dishes: " . count($dishes)); // Debug
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Công thức yêu thích</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        .dish-card {
            background: linear-gradient(145deg, #ffffff, #f9fafb);
            border: 1px solid #e5e7eb;
            border-radius: 0.75rem;
            padding: 0.75rem;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            overflow: hidden;
        }
        .dish-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
        }
        .dish-card img {
            width: 100%;
            height: 192px;
            object-fit: cover;
            border-radius: 0.5rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .dish-card:hover img {
            transform: scale(1.05);
        }
        .dish-card h3 {
            font-size: 1rem;
            font-weight: 700;
            color: #1f2937;
            margin: 0.5rem 0;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .dish-card p {
            font-size: 0.75rem;
            color: #4b5563;
            margin: 0.25rem 0;
            text-align: center;
        }
        .dish-card .calo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.25rem;
            font-weight: 600;
            color: #3b82f6;
        }
        .dish-card a {
            display: block;
            text-align: center;
            font-size: 0.75rem;
            font-weight: 500;
            color: white;
            background: linear-gradient(to right, #3b82f6, #2563eb);
            padding: 0.5rem 0;
            border-radius: 0.375rem;
            margin: 0.5rem 0 0;
            transition: background 0.3s ease, transform 0.2s ease;
        }
        .dish-card a:hover {
            background: linear-gradient(to right, #2563eb, #1d4ed8);
            transform: scale(1.02);
        }
        /* Navbar styles from index.php */
        .navbar {
            background: linear-gradient(145deg, #4f46e5, #10b981);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 50;
        }
        .navbar-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        .nav-menu {
            display: flex;
            gap: 0.75rem;
            align-items: center;
        }
        .nav-menu a {
            color: #e5e7eb;
            font-size: 1rem;
            font-weight: 500;
            text-decoration: none;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            transition: background-color 0.3s ease, color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }
        .nav-menu a:hover {
            background-color: #6b7280;
            color: #ffffff;
        }
        .nav-user-section {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .user-dropdown {
            position: relative;
        }
        .user-button {
            color: #e5e7eb;
            font-size: 1rem;
            font-weight: 500;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            background: transparent;
            transition: background-color 0.3s ease, color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }
        .user-button:hover {
            background-color: #6b7280;
            color: #ffffff;
        }
        .user-dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: #ffffff;
            border-radius: 0.375rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            min-width: 160px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: opacity 0.3s ease, transform 0.3s ease, visibility 0.3s ease;
            z-index: 100;
        }
        .user-dropdown:hover .user-dropdown-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        .user-dropdown-menu a {
            display: block;
            padding: 0.5rem 1rem;
            color: #1f2937;
            font-size: 0.875rem;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .user-dropdown-menu a:hover {
            background-color: #f3f4f6;
        }
        .logout-link {
            color: white;
            font-size: 1rem;
            font-weight: 500;
            padding: 0.5rem 0.75rem;
            border-radius: 0.375rem;
            text-decoration: none;
            transition: background 0.3s ease, transform 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            white-space: nowrap;
        }
        .logout-link:hover {
            background: linear-gradient(to right, #2563eb, #1d4ed8);
            transform: scale(1.02);
        }
        .hamburger {
            display: none;
            flex-direction: column;
            cursor: pointer;
            gap: 0.25rem;
        }
        .hamburger span {
            width: 24px;
            height: 3px;
            background: #e5e7eb;
            border-radius: 2px;
            transition: all 0.3s ease;
        }
        .hamburger.active span:nth-child(1) {
            transform: rotate(45deg) translate(5px, 5px);
        }
        .hamburger.active span:nth-child(2) {
            opacity: 0;
        }
        .hamburger.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -7px);
        }
        /* Responsive styles */
        @media (max-width: 767px) {
            .navbar-container {
                flex-wrap: wrap;
            }
            .nav-menu {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: #4f46e5;
                flex-direction: column;
                padding: 1rem;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }
            .nav-menu.active {
                display: flex;
            }
            .nav-menu a {
                padding: 0.75rem;
                width: 100%;
                text-align: left;
                font-size: 1rem;
            }
            .nav-user-section {
                display: none;
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
                padding: 1rem;
                width: 100%;
            }
            .nav-user-section.active {
                display: flex;
            }
            .user-dropdown {
                width: 100%;
            }
            .user-dropdown-menu {
                position: static;
                background: #6b7280;
                box-shadow: none;
                transform: none;
                opacity: 1;
                visibility: visible;
                margin-top: 0.5rem;
                width: 100%;
            }
            .user-dropdown-menu a {
                color: #e5e7eb;
            }
            .user-dropdown-menu a:hover {
                background-color: #4b5563;
            }
            .logout-link {
                width: 100%;
                text-align: left;
                color: white;
            }
            .logout-link:hover {
                color: white;
            }
            .hamburger {
                display: flex;
            }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Thanh menu ngang phía trên -->
    <nav class="navbar">
        <div class="navbar-container">
            <div class="hamburger" id="hamburger" role="button" aria-label="Toggle navigation" aria-expanded="false">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="flex items-center gap-4">
                <div class="nav-menu" id="nav-menu">
                    <a href="index.php"><i class="fas fa-home"></i> Trang chủ</a>
                    <a href="nutrients.php"><i class="fas fa-seedling"></i> Dinh dưỡng</a>
                    <a href="suggest_dishes.php"><i class="fas fa-utensils"></i> Gợi ý theo nguyên liệu</a>
                    <a href="favorites.php"><i class="fas fa-heart"></i> Món ăn yêu thích</a>
                    <a href="menu.php"><i class="fas fa-calendar-alt"></i> Thực đơn</a>
                    <a href="nutrition_chart.php"><i class="fas fa-chart-bar"></i> Biểu đồ dinh dưỡng</a>
                </div>
                <div class="nav-user-section" id="nav-user-section">
                    <?php 
                    $display_name = isset($_SESSION['ten_dangnhap']) && !empty($_SESSION['ten_dangnhap']) ? $_SESSION['ten_dangnhap'] : 'Người dùng';
                    ?>
                    <div class="user-dropdown">
                        <button class="user-button">
                            <i class="fas fa-user mr-2"></i>
                            <span><?php echo htmlspecialchars($display_name); ?></span>
                        </button>
                        <div class="user-dropdown-menu">
                            <a href="profile.php">Hồ sơ</a>
                        </div>
                    </div>
                    <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt mr-2"></i>Đăng xuất</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Nội dung chính -->
    <div class="container mx-auto p-6">
        <h2 class="text-2xl font-bold mb-6 text-center">Công thức món ăn yêu thích</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <?php if (empty($dishes)): ?>
                <p class="col-span-full text-center text-gray-500">Bạn chưa có món ăn yêu thích nào. Hãy thêm từ trang chi tiết món ăn!</p>
            <?php else: ?>
                <?php foreach ($dishes as $dish): ?>
                    <div class="dish-card">
                        <img src="<?php echo htmlspecialchars($dish['hinh_anh'] ?? 'https://via.placeholder.com/300x192'); ?>" 
                             alt="<?php echo htmlspecialchars($dish['ten_monan']); ?>" class="w-full h-48 object-cover">
                        <h3><?php echo htmlspecialchars($dish['ten_monan']); ?></h3>
                        <p class="calo"><i class="fas fa-fire-alt text-xs"></i> <?php echo htmlspecialchars($dish['calo']); ?> kcal</p>
                        <p>Danh mục: <?php echo htmlspecialchars($dish['ten_danhmuc'] ?? 'Chưa có'); ?></p>
                        <p>Chế độ: <?php echo htmlspecialchars($dish['ten_chedo'] ?? ''); ?></p>
                        <a href="detail.php?id=<?php echo $dish['ma_monan']; ?>">Xem chi tiết</a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Xử lý hamburger menu
        document.addEventListener('DOMContentLoaded', function () {
            const hamburger = document.getElementById('hamburger');
            const navMenu = document.getElementById('nav-menu');
            const navUserSection = document.getElementById('nav-user-section');

            hamburger.addEventListener('click', function () {
                const isActive = hamburger.classList.toggle('active');
                hamburger.setAttribute('aria-expanded', isActive);
                navMenu.classList.toggle('active');
                navUserSection.classList.toggle('active');
            });

            // Đóng menu khi click vào link trên mobile
            document.querySelectorAll('.nav-menu a, .nav-user-section a').forEach(link => {
                link.addEventListener('click', function () {
                    if (window.innerWidth <= 767) {
                        hamburger.classList.remove('active');
                        hamburger.setAttribute('aria-expanded', 'false');
                        navMenu.classList.remove('active');
                        navUserSection.classList.remove('active');
                    }
                });
            });
        });
    </script>
</body>
</html>