<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: manage_dishes.php?error=ID món ăn không hợp lệ");
    exit();
}

try {
    $ma_monan = (int)$_GET['id'];
    $conn->beginTransaction();

    // Lấy thông tin hình ảnh và video để xóa file
    $sql = "SELECT hinh_anh, video FROM monan WHERE ma_monan = :ma_monan";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_monan' => $ma_monan]);
    $dish = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$dish) {
        throw new Exception("Món ăn không tồn tại");
    }

    // Xóa file hình ảnh và video nếu tồn tại
    if ($dish['hinh_anh'] && file_exists($dish['hinh_anh'])) {
        unlink($dish['hinh_anh']);
    }
    if ($dish['video'] && file_exists($dish['video'])) {
        unlink($dish['video']);
    }

    // Xóa dữ liệu liên quan
    $tables = [
        'monan_danhmuc',
        'monan_nguyenlieu',
        'nguyenlieu_thaythe',
        'monan_thanhphandinhduong',
        'favorites',
        'feedback'
    ];
    foreach ($tables as $table) {
        $sql = "DELETE FROM $table WHERE ma_monan = :ma_monan";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['ma_monan' => $ma_monan]);
    }

    // Xóa món ăn
    $sql = "DELETE FROM monan WHERE ma_monan = :ma_monan";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_monan' => $ma_monan]);

    $conn->commit();
    header("Location: manage_dishes.php?success=Món ăn đã được xóa thành công");
    exit();
} catch (Exception $e) {
    $conn->rollBack();
    $log_file = __DIR__ . '/logs/debug.log';
    $log_dir = dirname($log_file);
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - Error: " . $e->getMessage() . "\n", FILE_APPEND);
    header("Location: manage_dishes.php?error=" . urlencode($e->getMessage()));
    exit();
}
?>
