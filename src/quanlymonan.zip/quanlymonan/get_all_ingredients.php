<?php
require_once 'connect.php';

header('Content-Type: application/json');

if (isset($_GET['ma_monan']) && is_numeric($_GET['ma_monan'])) {
    $ma_monan = (int)$_GET['ma_monan'];
    $sql = "SELECT n.ma_nguyenlieu, n.ten_nguyenlieu 
            FROM nguyenlieu n 
            WHERE n.ma_nguyenlieu NOT IN (
                SELECT ma_nguyenlieu FROM monan_nguyenlieu WHERE ma_monan = :ma_monan
            ) 
            ORDER BY n.ten_nguyenlieu";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_monan' => $ma_monan]);
    $ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($ingredients);
} else {
    $sql = "SELECT ma_nguyenlieu, ten_nguyenlieu FROM nguyenlieu ORDER BY ten_nguyenlieu";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($ingredients);
}
?>