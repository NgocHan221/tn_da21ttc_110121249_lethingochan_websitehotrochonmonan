<?php
session_start();
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['vai_tro'] == 'admin') {
        header("Location: admin_dashboard.php");
    } else {
        header("Location: index.php");
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gradient-to-tr from-indigo-100 via-blue-100 to-white min-h-screen flex items-center justify-center px-4">
    <div class="bg-white rounded-2xl shadow-2xl p-8 md:p-10 max-w-md w-full transition-all duration-300">
        <h2 class="text-4xl font-bold text-center text-indigo-700 mb-6">Chào mừng trở lại</h2>
        <p class="text-center text-gray-500 mb-6 text-sm">Vui lòng đăng nhập để tiếp tục</p>

        <?php if (isset($_GET['error'])): ?>
            <div class="bg-red-50 text-red-600 border border-red-200 rounded-md p-3 mb-4 text-sm">
                <i class="fas fa-exclamation-circle mr-2"></i><?php echo htmlspecialchars($_GET['error']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['success'])): ?>
            <div class="bg-green-50 text-green-600 border border-green-200 rounded-md p-3 mb-4 text-sm">
                <i class="fas fa-check-circle mr-2"></i><?php echo htmlspecialchars($_GET['success']); ?>
            </div>
        <?php endif; ?>

        <form action="process_login.php" method="POST" class="space-y-5">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Tên đăng nhập hoặc Email</label>
                <input type="text" name="login" placeholder="Nhập tên đăng nhập hoặc email"
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none transition duration-200" required>
            </div>
            <div class="relative">
                <label class="block text-sm font-medium text-gray-700 mb-1">Mật khẩu</label>
                <input type="password" name="password" id="password" placeholder="Nhập mật khẩu"
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none transition duration-200" required>
                <span class="absolute right-4 top-10 cursor-pointer text-gray-500 hover:text-indigo-600" onclick="togglePassword()">
                    <i id="eyeIcon" class="fas fa-eye"></i>
                </span>
            </div>
            <button type="submit"
                    class="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold text-sm hover:bg-indigo-700 transition duration-200 focus:ring-2 focus:ring-indigo-400 focus:outline-none">
                Đăng nhập
            </button>
        </form>

        <div class="mt-6 text-center text-gray-600 text-sm">
            Chưa có tài khoản?
            <a href="register.php" class="text-indigo-600 font-medium hover:underline">Đăng ký</a>
            <span class="mx-1">|</span>
            <a href="forgot_password.php" class="text-indigo-600 font-medium hover:underline">Quên mật khẩu?</a>
        </div>
    </div>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const eyeIcon = document.getElementById('eyeIcon');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                eyeIcon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                eyeIcon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }
    </script>
</body>
</html>
