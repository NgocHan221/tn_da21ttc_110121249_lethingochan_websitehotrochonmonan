<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: add_preservation.php?error=Phương thức không hợp lệ");
    exit();
}

try {
    $dish_id = $_POST['dish_id'] ?? 0;
    $content = $_POST['content'] ?? '';
    $ghi_chu = $_POST['ghi_chu'] ?? '';
    $menu = $_POST['menu'] ?? [];

    // Kiểm tra dữ liệu đầu vào
    if (!is_numeric($dish_id) || $dish_id <= 0) {
        throw new Exception("ID món ăn không hợp lệ");
    }
    if (empty(trim($content))) {
        throw new Exception("Nội dung bảo quản không được để trống");
    }

    // Kiểm tra món ăn tồn tại
    $sql = "SELECT ma_monan FROM monan WHERE ma_monan = :dish_id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['dish_id' => $dish_id]);
    if (!$stmt->fetch()) {
        throw new Exception("Món ăn không tồn tại");
    }

    $conn->beginTransaction();

    // Thêm bài viết bảo quản
    $sql = "INSERT INTO preservation (dish_id, content, ghi_chu) VALUES (:dish_id, :content, :ghi_chu)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        'dish_id' => $dish_id,
        'content' => $content,
        'ghi_chu' => $ghi_chu ?: null // Lưu NULL nếu ghi_chu rỗng
    ]);
    $preservation_id = $conn->lastInsertId();

    // Thêm thực đơn gợi ý
    foreach ($menu as $meal => $data) {
        $calories = $data['calories'] ?? 0;
        $dishes = array_filter($data['dishes'] ?? [], function($dish) {
            return !empty(trim($dish));
        });
        if (!empty($dishes)) {
            if (!is_numeric($calories) || $calories < 0) {
                throw new Exception("Năng lượng cho $meal phải là số không âm");
            }
            $dishes_json = json_encode($dishes, JSON_UNESCAPED_UNICODE);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception("Lỗi mã hóa JSON cho món ăn");
            }
            $sql = "INSERT INTO menu_suggestions (preservation_id, meal, calories, dishes) 
                    VALUES (:preservation_id, :meal, :calories, :dishes)";
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                'preservation_id' => $preservation_id,
                'meal' => $meal,
                'calories' => $calories,
                'dishes' => $dishes_json
            ]);
        }
    }

    $conn->commit();
    header("Location: manage_preservation.php?success=Thêm bài viết bảo quản thành công");
    exit();
} catch (Exception $e) {
    $conn->rollBack();
    error_log("Lỗi khi thêm bài viết bảo quản: " . $e->getMessage());
    header("Location: add_preservation.php?error=" . urlencode($e->getMessage()));
    exit();
}
?>