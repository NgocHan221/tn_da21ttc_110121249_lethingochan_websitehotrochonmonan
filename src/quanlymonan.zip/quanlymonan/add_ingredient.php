<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm nguyên liệu</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex">
    <!-- Menu dọc bên trái -->
    <div class="w-96 bg-gray-800 text-white h-screen fixed top-0 left-0 p-4 text-xl">
        <h2 class="text-3xl font-bold mb-6">Quản trị viên</h2>
        <ul>
            <li class="mb-4">
                <a href="admin_dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-users mr-2"></i> Quản lý người dùng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-list mr-2"></i> Quản lý danh mục
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_diets.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-utensils mr-2"></i> Quản lý chế độ
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_ingredients.php" class="flex items-center p-2 bg-gray-700 rounded">
                    <i class="fas fa-seedling mr-2"></i> Quản lý nguyên liệu
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_nutrients.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-heartbeat mr-2"></i> Quản lý dinh dưỡng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_components.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-vial mr-2"></i> Quản lý thành phần dinh dưỡng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_dishes.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-utensil-spoon mr-2"></i> Quản lý món ăn
                </a>
            </li>
            <li class="mb-4">
                <a href="admin_feedback.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-comments mr-2"></i> Quản lý phản hồi
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_preservation.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-leaf mr-2"></i> Quản lý chi tiết dinh dưỡng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_alternative_ingredients.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-exchange-alt mr-2"></i> Quản lý nguyên liệu thay thế
                </a>
            </li>
            <li>
                <a href="logout.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-sign-out-alt mr-2"></i> Đăng xuất
                </a>
            </li>
        </ul>
    </div>
    <!-- Nội dung chính -->
    <div class="ml-64 p-6 w-full">
        <div class="max-w-md mx-auto bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl font-bold mb-6 text-center">Thêm nguyên liệu</h2>
            <?php if (isset($_GET['error'])): ?>
                <p class="text-red-500 mb-4"><?php echo htmlspecialchars($_GET['error']); ?></p>
            <?php endif; ?>
            <form action="process_add_ingredient.php" method="POST">
                <div class="mb-4">
                    <label class="block text-gray-700">Tên nguyên liệu</label>
                    <input type="text" name="ten_nguyenlieu" class="w-full p-2 border rounded" required>
                </div>
                <button type="submit" class="w-full bg-green-500 text-white p-2 rounded hover:bg-green-600">Thêm</button>
            </form>
            <p class="mt-4 text-center"><a href="manage_ingredients.php" class="text-blue-500">Quay lại</a></p>
        </div>
    </div>
</body>
</html>