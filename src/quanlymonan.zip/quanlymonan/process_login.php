<?php
session_start();
require_once 'connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = trim($_POST['login']);
    $password = $_POST['password'];

    try {
        // Kiểm tra tên đăng nhập hoặc email
        $sql = "SELECT ma_nguoidung, ten_dangnhap, vai_tro, mat_khau FROM nguoidung WHERE email = :login OR ten_dangnhap = :login";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['login' => $login]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // So sánh mật khẩu dạng văn bản thuần
        if ($user && $password === $user['mat_khau']) {
            $_SESSION['user_id'] = $user['ma_nguoidung'];
            $_SESSION['ten_dangnhap'] = $user['ten_dangnhap'];
            $_SESSION['vai_tro'] = $user['vai_tro'];
            if ($user['vai_tro'] == 'admin') {
                header("Location: admin_dashboard.php");
            } else {
                header("Location: index.php");
            }
            exit();
        } else {
            header("Location: login.php?error=Sai tên đăng nhập, email hoặc mật khẩu");
            exit();
        }
    } catch (PDOException $e) {
        error_log("Database error at " . date('Y-m-d H:i:s') . ": " . $e->getMessage());
        header("Location: login.php?error=Đã xảy ra lỗi, vui lòng thử lại sau");
        exit();
    }
} else {
    header("Location: login.php?error=Phương thức không hợp lệ");
    exit();
}
?>