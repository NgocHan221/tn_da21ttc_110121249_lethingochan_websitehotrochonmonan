<?php
require_once 'connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ten_dangnhap = trim(filter_var($_POST['ten_dangnhap'], FILTER_SANITIZE_STRING));
    $ho_ten = trim(filter_var($_POST['ho_ten'], FILTER_SANITIZE_STRING));
    $email = trim(filter_var($_POST['email'], FILTER_SANITIZE_EMAIL));
    $sdt = trim(filter_var($_POST['sdt'], FILTER_SANITIZE_STRING));
    $tuoi = (int)$_POST['tuoi'];
    $chieu_cao = (float)$_POST['chieu_cao'];
    $can_nang = (float)$_POST['can_nang'];
    $gioi_tinh = $_POST['gioi_tinh'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Kiểm tra xác nhận mật khẩu
    if ($password !== $confirm_password) {
        header("Location: register.php?error=Mật khẩu xác nhận không khớp");
        exit();
    }

    // Kiểm tra định dạng email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: register.php?error=Email không hợp lệ");
        exit();
    }

    // Kiểm tra số điện thoại (10 số, bắt đầu bằng 0, nếu có)
    if (!empty($sdt) && !preg_match('/^0[0-9]{9}$/', $sdt)) {
        header("Location: register.php?error=Số điện thoại không hợp lệ");
        exit();
    }

    // Kiểm tra độ dài mật khẩu
    if (strlen($password) < 6) {
        header("Location: register.php?error=Mật khẩu phải dài ít nhất 6 ký tự");
        exit();
    }

    // Kiểm tra tuổi
    if ($tuoi < 1 || $tuoi > 150) {
        header("Location: register.php?error=Tuổi phải từ 1 đến 150");
        exit();
    }

    // Kiểm tra chiều cao
    if ($chieu_cao < 50 || $chieu_cao > 300) {
        header("Location: register.php?error=Chiều cao phải từ 50 đến 300 cm");
        exit();
    }

    // Kiểm tra cân nặng
    if ($can_nang < 20 || $can_nang > 300) {
        header("Location: register.php?error=Cân nặng phải từ 20 đến 300 kg");
        exit();
    }

    // Kiểm tra giới tính
    if (!in_array($gioi_tinh, ['Nam', 'Nữ', 'Khác'])) {
        header("Location: register.php?error=Giới tính không hợp lệ");
        exit();
    }

    try {
        // Kiểm tra email hoặc tên đăng nhập đã tồn tại
        $sql_check = "SELECT ma_nguoidung FROM nguoidung WHERE email = :email OR ten_dangnhap = :ten_dangnhap";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->execute(['email' => $email, 'ten_dangnhap' => $ten_dangnhap]);
        $existing_user = $stmt_check->fetch(PDO::FETCH_ASSOC);

        if ($existing_user) {
            header("Location: register.php?error=Email hoặc tên đăng nhập đã tồn tại");
            exit();
        }

        // Thêm người dùng mới (lưu mật khẩu trực tiếp)
        $sql = "INSERT INTO nguoidung (ten_dangnhap, ho_ten, email, sdt, tuoi, chieu_cao, can_nang, gioi_tinh, mat_khau, vai_tro) 
                VALUES (:ten_dangnhap, :ho_ten, :email, :sdt, :tuoi, :chieu_cao, :can_nang, :gioi_tinh, :mat_khau, 'nguoidung')";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            'ten_dangnhap' => $ten_dangnhap,
            'ho_ten' => $ho_ten,
            'email' => $email,
            'sdt' => $sdt,
            'tuoi' => $tuoi,
            'chieu_cao' => $chieu_cao,
            'can_nang' => $can_nang,
            'gioi_tinh' => $gioi_tinh,
            'mat_khau' => $password // Lưu mật khẩu trực tiếp
        ]);

        header("Location: login.php?success=Đăng ký thành công, vui lòng đăng nhập");
        exit();
    } catch (PDOException $e) {
        error_log("Database error at " . date('Y-m-d H:i:s') . ": " . $e->getMessage());
        header("Location: register.php?error=Đã xảy ra lỗi, vui lòng thử lại sau");
        exit();
    }
} else {
    header("Location: register.php?error=Phương thức không hợp lệ");
    exit();
}
?>