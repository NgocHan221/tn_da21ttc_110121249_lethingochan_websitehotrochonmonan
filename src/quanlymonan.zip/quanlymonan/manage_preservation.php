<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

$items_per_page = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] > 0 ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $items_per_page;

try {
    // Count total preservation records
    $sql_count = "SELECT COUNT(*) FROM preservation";
    $stmt_count = $conn->prepare($sql_count);
    $stmt_count->execute();
    $total_items = $stmt_count->fetchColumn();
    $total_pages = ceil($total_items / $items_per_page);

    // Fetch preservation records for the current page
    $sql = "SELECT p.id, p.dish_id, p.content, m.ten_monan 
            FROM preservation p 
            JOIN monan m ON p.dish_id = m.ma_monan
            LIMIT :limit OFFSET :offset";
    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':limit', $items_per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $preservations = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p class='text-red-500'>Lỗi truy vấn: " . htmlspecialchars($e->getMessage()) . "</p>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý chi tiết dinh dưỡng</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex">
    <!-- Sidebar -->
    <div class="w-96 bg-gray-800 text-white h-screen fixed top-0 left-0 p-4 text-xl">
        <h2 class="text-3xl font-bold mb-6">Quản trị viên</h2>
        <ul>
            <li class="mb-4">
                <a href="admin_dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-users mr-2"></i> Quản lý người dùng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-list mr-2"></i> Quản lý danh mục
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_diets.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-utensils mr-2"></i> Quản lý chế độ
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_ingredients.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-seedling mr-2"></i> Quản lý nguyên liệu
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_nutrients.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-heartbeat mr-2"></i> Quản lý dinh dưỡng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_components.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-vial mr-2"></i> Quản lý thành phần dinh dưỡng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_dishes.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-utensil-spoon mr-2"></i> Quản lý món ăn
                </a>
            </li>
            <li class="mb-4">
                <a href="admin_feedback.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-comments mr-2"></i> Quản lý phản hồi
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_preservation.php" class="flex items-center p-2 bg-gray-700 rounded">
                    <i class="fas fa-leaf mr-2"></i> Quản lý chi tiết dinh dưỡng
                </a>
            </li>
            <li>
                <a href="logout.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-sign-out-alt mr-2"></i> Đăng xuất
                </a>
            </li>
        </ul>
    </div>

    <!-- Main content -->
    <div class="ml-96 p-6 w-[calc(100%-24rem)]">
        <div class="max-w-full mx-auto bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-3xl font-bold mb-6 text-center">Quản lý chi tiết dinh dưỡng</h2>
            <?php if (isset($_GET['success'])): ?>
                <p class="text-green-500 mb-4"><?php echo htmlspecialchars($_GET['success']); ?></p>
            <?php endif; ?>
            <?php if (isset($_GET['error'])): ?>
                <p class="text-red-500 mb-4"><?php echo htmlspecialchars($_GET['error']); ?></p>
            <?php endif; ?>
            <div class="mb-4">
                <a href="add_preservation.php" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">Thêm bài viết bảo quản</a>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full border-collapse text-base">
                    <thead>
                        <tr class="bg-gray-200">
                            <th class="border p-2 text-center">ID</th>
                            <th class="border p-2 text-center">Món ăn</th>
                            <th class="border p-2 text-center">Chi tiết dinh dưỡng</th>
                            <th class="border p-2 text-center">Hành động</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($preservations as $preservation): ?>
                            <tr>
                                <td class="border p-2 text-center"><?php echo htmlspecialchars($preservation['id']); ?></td>
                                <td class="border p-2 text-center"><?php echo htmlspecialchars($preservation['ten_monan']); ?></td>
                                <td class="border p-2 whitespace-pre-wrap"><?php echo $preservation['content'] ? nl2br($preservation['content']) : 'Chưa có nội dung'; ?></td>
                                <td class="border p-2 text-center space-x-2">
                                    <a href="edit_preservation.php?id=<?php echo $preservation['id']; ?>"
                                       class="inline-flex items-center bg-yellow-400 hover:bg-yellow-500 text-white px-3 py-1 rounded shadow">
                                        <i class="fas fa-edit mr-1"></i> Sửa
                                    </a>
                                    <a href="process_delete_preservation.php?id=<?php echo $preservation['id']; ?>"
                                       class="inline-flex items-center bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded shadow"
                                       onclick="return confirm('Bạn có chắc muốn xóa bài viết này?')">
                                        <i class="fas fa-trash-alt mr-1"></i> Xóa
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <!-- Pagination -->
            <div class="mt-6 flex justify-center">
                <nav class="inline-flex rounded-md shadow-sm">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>" class="px-3 py-2 bg-gray-200 text-gray-700 rounded-l-md hover:bg-gray-300">Trước</a>
                    <?php endif; ?>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>" class="px-3 py-2 <?php echo $i == $page ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'; ?> hover:bg-gray-300"><?php echo $i; ?></a>
                    <?php endfor; ?>
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page + 1; ?>" class="px-3 py-2 bg-gray-200 text-gray-700 rounded-r-md hover:bg-gray-300">Sau</a>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </div>
</body>
</html>
