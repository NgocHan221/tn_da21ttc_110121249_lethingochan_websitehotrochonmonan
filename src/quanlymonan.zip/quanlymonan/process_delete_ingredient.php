<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $ingredient_id = $_GET['id'];

    // Kiểm tra xem nguyên liệu có liên kết với món ăn trong monan_nguyenlieu
    $sql = "SELECT * FROM monan_nguyenlieu WHERE ma_nguyenlieu = :ma_nguyenlieu";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_nguyenlieu' => $ingredient_id]);
    if ($stmt->rowCount() > 0) {
        header("Location: manage_ingredients.php?error=Không thể xóa nguyên liệu vì còn món ăn liên kết");
        exit();
    }

    // Xóa nguyên liệu
    $sql = "DELETE FROM nguyenlieu WHERE ma_nguyenlieu = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $ingredient_id]);

    header("Location: manage_ingredients.php");
    exit();
}
?>