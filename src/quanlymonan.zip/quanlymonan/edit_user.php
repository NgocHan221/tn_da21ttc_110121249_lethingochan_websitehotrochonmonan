<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: admin_dashboard.php");
    exit();
}

try {
    $user_id = $_GET['id'];
    $sql = "SELECT * FROM nguoidung WHERE ma_nguoidung = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        header("Location: admin_dashboard.php");
        exit();
    }
} catch (PDOException $e) {
    error_log("Database error at " . date('Y-m-d H:i:s') . ": " . $e->getMessage());
    header("Location: admin_dashboard.php?error=Đã xảy ra lỗi khi lấy thông tin người dùng");
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa người dùng</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex">
    <div class="w-96 bg-gray-800 text-white h-screen fixed top-0 left-0 p-4 text-xl">
        <h2 class="text-3xl font-bold mb-6">Quản trị viên</h2>
        <ul>
            <li class="mb-4">
                <a href="admin_dashboard.php" class="flex items-center p-2 bg-gray-700 rounded"><i class="fas fa-users mr-2"></i> Quản lý người dùng</a>
            </li>
            <li class="mb-4">
                <a href="manage_categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-list mr-2"></i> Quản lý danh mục</a>
            </li>
            <li class="mb-4">
                <a href="manage_diets.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-utensils mr-2"></i> Quản lý chế độ</a>
            </li>
            <li class="mb-4">
                <a href="manage_ingredients.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-seedling mr-2"></i> Quản lý nguyên liệu</a>
            </li>
            <li class="mb-4">
                <a href="manage_nutrients.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-heartbeat mr-2"></i> Quản lý dinh dưỡng</a>
            </li>
            <li class="mb-4">
                <a href="manage_components.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-vial mr-2"></i> Quản lý thành phần</a>
            </li>
            <li class="mb-4">
                <a href="manage_dishes.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-utensil-spoon mr-2"></i> Quản lý món ăn</a>
            </li>
            <li class="mb-4">
                <a href="admin_feedback.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-comments mr-2"></i> Quản lý phản hồi</a>
            </li>
            <li class="mb-4">
                <a href="manage_preservation.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-leaf mr-2"></i> Quản lý chi tiết dinh dưỡng</a>
            </li>
            <li>
                <a href="logout.php" class="flex items-center p-2 hover:bg-gray-700 rounded"><i class="fas fa-sign-out-alt mr-2"></i> Đăng xuất</a>
            </li>
        </ul>
    </div>
    <div class="ml-64 p-8 w-full min-h-screen">
        <div class="bg-white p-8 rounded-xl shadow-xl w-full max-w-5xl mx-auto border border-gray-300">
            <h2 class="text-3xl font-bold mb-8 text-center text-gray-800">Sửa người dùng</h2>
            <?php if (isset($_SESSION['error'])): ?>
                <p class="text-red-500 mb-4"><?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></p>
            <?php endif; ?>
            <form action="process_edit_user.php" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <input type="hidden" name="ma_nguoidung" value="<?php echo htmlspecialchars($user['ma_nguoidung']); ?>">
                <?php
                $fields = [
                    'ten_dangnhap' => 'Tên đăng nhập',
                    'ho_ten' => 'Họ tên',
                    'email' => 'Email',
                    'sdt' => 'Số điện thoại',
                    'tuoi' => 'Tuổi',
                    'chieu_cao' => 'Chiều cao (cm)',
                    'can_nang' => 'Cân nặng (kg)',
                    'tinh_trang' => 'Tình trạng',
                ];
                foreach ($fields as $name => $label) {
                    $type = ($name === 'email') ? 'email' : (($name === 'tuoi' || $name === 'chieu_cao' || $name === 'can_nang') ? 'number' : 'text');
                    $step = ($name === 'chieu_cao' || $name === 'can_nang') ? 'step="0.1"' : '';
                    $value = htmlspecialchars($user[$name] ?? '');
                    echo "<div>
                        <label class='block font-semibold text-gray-700 mb-1'>{$label}</label>
                        <input type='{$type}' name='{$name}' class='w-full p-3 border rounded-lg' {$step} value='{$value}' required>
                    </div>";
                }
                ?>
                <div>
                    <label class="block font-semibold text-gray-700 mb-1">Giới tính</label>
                    <select name="gioi_tinh" class="w-full p-3 border rounded-lg" required>
                        <option value="Nam" <?= $user['gioi_tinh'] == 'Nam' ? 'selected' : '' ?>>Nam</option>
                        <option value="Nữ" <?= $user['gioi_tinh'] == 'Nữ' ? 'selected' : '' ?>>Nữ</option>
                        <option value="Khác" <?= $user['gioi_tinh'] == 'Khác' ? 'selected' : '' ?>>Khác</option>
                    </select>
                </div>
                <div class="relative">
                    <label class="block font-semibold text-gray-700 mb-1">Mật khẩu (bỏ trống nếu không đổi)</label>
                    <input type="password" name="password" id="password" class="w-full p-3 border rounded-lg">
                    <span class="absolute right-3 top-10 cursor-pointer" onclick="togglePassword('password', 'eyeIcon')">
                        <i id="eyeIcon" class="fas fa-eye"></i>
                    </span>
                </div>
                <div class="relative">
                    <label class="block font-semibold text-gray-700 mb-1">Xác nhận mật khẩu</label>
                    <input type="password" name="confirm_password" id="confirm_password" class="w-full p-3 border rounded-lg">
                    <span class="absolute right-3 top-10 cursor-pointer" onclick="togglePassword('confirm_password', 'eyeIconConfirm')">
                        <i id="eyeIconConfirm" class="fas fa-eye"></i>
                    </span>
                </div>
                <div>
                    <label class="block font-semibold text-gray-700 mb-1">Vai trò</label>
                    <select name="vai_tro" class="w-full p-3 border rounded-lg" required>
                        <option value="nguoidung" <?= $user['vai_tro'] == 'nguoidung' ? 'selected' : '' ?>>Người dùng</option>
                        <option value="admin" <?= $user['vai_tro'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                    </select>
                </div>
                <div class="col-span-2 pt-4">
                    <button type="submit" class="w-full bg-blue-600 text-white font-semibold py-3 rounded-lg hover:bg-blue-700 transition">Cập nhật</button>
                </div>
            </form>
            <p class="mt-6 text-center">
                <a href="admin_dashboard.php" class="text-blue-500 hover:underline">Quay lại</a>
            </p>
        </div>
    </div>
    <script>
        function togglePassword(inputId, iconId) {
            const input = document.getElementById(inputId);
            const icon = document.getElementById(iconId);
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
