<?php
header('Content-Type: application/json');

// Đường dẫn thư mục lưu trữ hình ảnh
$upload_dir = 'uploads/images/';
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Kiểm tra xem có file được gửi lên không
if (!isset($_FILES['file'])) {
    echo json_encode(['error' => 'Không có file được gửi lên']);
    exit;
}

$file = $_FILES['file'];
$allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
$max_size = 5 * 1024 * 1024; // 5MB

// Kiểm tra loại file và kích thước
if (!in_array($file['type'], $allowed_types)) {
    echo json_encode(['error' => 'Loại file không hợp lệ. Chỉ chấp nhận JPEG, JPG, PNG, GIF']);
    exit;
}

if ($file['size'] > $max_size) {
    echo json_encode(['error' => 'File quá lớn. Kích thước tối đa là 5MB']);
    exit;
}

// Tạo tên file duy nhất
$filename = uniqid('cong_thuc_') . '.' . pathinfo($file['name'], PATHINFO_EXTENSION);
$destination = $upload_dir . $filename;

// Di chuyển file vào thư mục uploads
if (move_uploaded_file($file['tmp_name'], $destination)) {
    // Trả về URL của hình ảnh để Froala sử dụng
    $image_url = $destination;
    echo json_encode(['link' => $image_url]);
} else {
    echo json_encode(['error' => 'Không thể tải file lên']);
}

exit;