<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ma_chedo = $_POST['ma_chedo'];
    $ten_chedo = $_POST['ten_chedo'];

    // Kiểm tra tên chế độ đã tồn tại (trừ chế độ hiện tại)
    $sql = "SELECT * FROM chedo WHERE ten_chedo = :ten_chedo AND ma_chedo != :ma_chedo";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_chedo' => $ten_chedo, 'ma_chedo' => $ma_chedo]);
    if ($stmt->rowCount() > 0) {
        header("Location: edit_diet.php?id=$ma_chedo&error=Tên chế độ đã tồn tại");
        exit();
    }

    // Cập nhật chế độ
    $sql = "UPDATE chedo SET ten_chedo = :ten_chedo WHERE ma_chedo = :ma_chedo";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_chedo' => $ten_chedo, 'ma_chedo' => $ma_chedo]);

    header("Location: manage_diets.php");
    exit();
}
?>