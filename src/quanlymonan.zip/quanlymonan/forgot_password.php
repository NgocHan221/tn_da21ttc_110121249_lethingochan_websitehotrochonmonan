<?php
session_start();
require_once 'connect.php';

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$show_password_form = isset($_GET['show_password_form']) && $_SESSION['reset_verified'];
$email = '';
$sdt = '';
$error = isset($_GET['error']) ? $_GET['error'] : '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['verify_info'])) {
    $email = trim(filter_var($_POST['email'], FILTER_SANITIZE_EMAIL));
    $sdt = trim(filter_var($_POST['sdt'], FILTER_SANITIZE_STRING));

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Email không hợp lệ!";
    } elseif (!preg_match('/^0[0-9]{9}$/', $sdt)) {
        $error = "Số điện thoại không hợp lệ!";
    } else {
        try {
            $sql = "SELECT ma_nguoidung FROM nguoidung WHERE email = :email AND sdt = :sdt";
            $stmt = $conn->prepare($sql);
            $stmt->execute(['email' => $email, 'sdt' => $sdt]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                $_SESSION['reset_email'] = $email;
                $_SESSION['reset_sdt'] = $sdt;
                $_SESSION['reset_verified'] = true;
                header("Location: forgot_password.php?show_password_form=1");
                exit();
            } else {
                $error = "Email hoặc số điện thoại không khớp với tài khoản nào!";
            }
        } catch (PDOException $e) {
            error_log("Database error at " . date('Y-m-d H:i:s') . ": " . $e->getMessage());
            $error = "Đã xảy ra lỗi, vui lòng thử lại sau!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quên mật khẩu</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gradient-to-tr from-indigo-50 to-blue-100 min-h-screen flex items-center justify-center px-4">
    <div class="bg-white p-8 md:p-10 rounded-2xl shadow-2xl w-full max-w-md border border-blue-200">
        <h2 class="text-3xl font-bold text-center text-blue-700 mb-2">Quên mật khẩu</h2>
        <p class="text-center text-gray-500 text-sm mb-6">Xác minh thông tin để đặt lại mật khẩu</p>

        <?php if (!empty($error)): ?>
            <div class="bg-red-50 text-red-600 border border-red-300 rounded-md p-3 mb-5 text-sm flex items-center gap-2">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if (!$show_password_form): ?>
            <!-- Form xác minh -->
            <form action="forgot_password.php" method="POST" class="space-y-5">
                <input type="hidden" name="verify_info" value="1">
                <div>
                    <label class="block text-sm text-gray-700 mb-1">Email</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                </div>
                <div>
                    <label class="block text-sm text-gray-700 mb-1">Số điện thoại</label>
                    <input type="text" name="sdt" value="<?php echo htmlspecialchars($sdt); ?>" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                </div>
                <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition duration-200">Xác nhận</button>
            </form>
        <?php else: ?>
            <!-- Form đặt lại mật khẩu -->
            <form action="process_forgot_password.php" method="POST" class="space-y-5">
                <input type="hidden" name="reset_password" value="1">
                <div class="relative">
                    <label class="block text-sm text-gray-700 mb-1">Mật khẩu mới</label>
                    <input type="password" name="password" id="password" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    <span class="absolute right-3 top-[42px] cursor-pointer text-gray-400 hover:text-blue-600" onclick="togglePassword('password', 'eyeIcon')">
                        <i id="eyeIcon" class="fas fa-eye"></i>
                    </span>
                </div>
                <div class="relative">
                    <label class="block text-sm text-gray-700 mb-1">Nhập lại mật khẩu</label>
                    <input type="password" name="confirm_password" id="confirm_password" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    <span class="absolute right-3 top-[42px] cursor-pointer text-gray-400 hover:text-blue-600" onclick="togglePassword('confirm_password', 'eyeIconConfirm')">
                        <i id="eyeIconConfirm" class="fas fa-eye"></i>
                    </span>
                </div>
                <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition duration-200">Đặt lại mật khẩu</button>
            </form>
        <?php endif; ?>

        <p class="mt-6 text-center text-sm text-gray-600">Đã nhớ mật khẩu?
            <a href="login.php" class="text-blue-600 font-medium hover:underline">Đăng nhập</a>
        </p>
    </div>

    <script>
        function togglePassword(inputId, iconId) {
            const input = document.getElementById(inputId);
            const icon = document.getElementById(iconId);
            if (input.type === "password") {
                input.type = "text";
                icon.classList.replace("fa-eye", "fa-eye-slash");
            } else {
                input.type = "password";
                icon.classList.replace("fa-eye-slash", "fa-eye");
            }
        }
    </script>
</body>
</html>
