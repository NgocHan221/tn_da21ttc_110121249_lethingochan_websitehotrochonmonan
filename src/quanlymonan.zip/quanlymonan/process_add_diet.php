<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ten_chedo = $_POST['ten_chedo'];

    // Kiểm tra tên chế độ đã tồn tại
    $sql = "SELECT * FROM chedo WHERE ten_chedo = :ten_chedo";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_chedo' => $ten_chedo]);
    if ($stmt->rowCount() > 0) {
        header("Location: add_diet.php?error=Tên chế độ đã tồn tại");
        exit();
    }

    // Thêm chế độ mới
    $sql = "INSERT INTO chedo (ten_chedo) VALUES (:ten_chedo)";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ten_chedo' => $ten_chedo]);

    header("Location: manage_diets.php");
    exit();
}
?>