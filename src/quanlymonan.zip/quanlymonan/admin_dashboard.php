<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Khởi tạo biến tìm kiếm
$search_params = [
    'ten_dangnhap' => isset($_POST['ten_dangnhap']) ? trim($_POST['ten_dangnhap']) : '',
    'ho_ten' => isset($_POST['ho_ten']) ? trim($_POST['ho_ten']) : '',
    'email' => isset($_POST['email']) ? trim($_POST['email']) : '',
    'sdt' => isset($_POST['sdt']) ? trim($_POST['sdt']) : ''
];

$users = [];
$error_message = '';

try {
    // Xây dựng câu truy vấn SQL động
    $sql = "SELECT * FROM nguoidung WHERE 1=1";
    $params = [];

    if (!empty($search_params['ten_dangnhap'])) {
        $sql .= " AND ten_dangnhap LIKE ?";
        $params[] = '%' . $search_params['ten_dangnhap'] . '%';
    }
    if (!empty($search_params['ho_ten'])) {
        $sql .= " AND ho_ten LIKE ?";
        $params[] = '%' . $search_params['ho_ten'] . '%';
    }
    if (!empty($search_params['email'])) {
        $sql .= " AND email LIKE ?";
        $params[] = '%' . $search_params['email'] . '%';
    }
    if (!empty($search_params['sdt'])) {
        $sql .= " AND sdt LIKE ?";
        $params[] = '%' . $search_params['sdt'] . '%';
    }

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Prepare statement failed: " . $conn->error);
    }
    if (!empty($params)) {
        $stmt->execute($params);
    } else {
        $stmt->execute();
    }
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error at " . date('Y-m-d H:i:s') . ": " . $e->getMessage());
    $users = [];
    $_SESSION['error'] = "Đã xảy ra lỗi khi lấy danh sách người dùng!";
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý người dùng</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .action-edit {
            background-color: #3b82f6; /* Xanh dương */
            color: white;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.875rem;
            transition: all 0.3s ease;
        }
        .action-edit:hover {
            background-color: #2563eb; /* Xanh đậm hơn khi hover */
            transform: scale(1.05);
        }
        .action-delete {
            background-color: #ef4444; /* Đỏ */
            color: white;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.875rem;
            transition: all 0.3s ease;
            margin-left: 6px;
        }
        .action-delete:hover {
            background-color: #b91c1c; /* Đỏ đậm hơn khi hover */
            transform: scale(1.05);
        }
    </style>
</head>
<body class="bg-gray-100 flex">
    <!-- Sidebar -->
    <div class="w-96 bg-gray-800 text-white h-screen fixed top-0 left-0 p-4 text-xl">
        <h2 class="text-3xl font-bold mb-6">Quản trị viên</h2>
        <ul>
            <li class="mb-4">
                <a href="admin_dashboard.php" class="flex items-center p-2 bg-gray-700 rounded">
                    <i class="fas fa-users mr-2"></i> Quản lý người dùng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-list mr-2"></i> Quản lý danh mục
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_diets.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-utensils mr-2"></i> Quản lý chế độ
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_ingredients.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-seedling mr-2"></i> Quản lý nguyên liệu
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_nutrients.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-heartbeat mr-2"></i> Quản lý dinh dưỡng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_components.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-vial mr-2"></i> Quản lý thành phần dinh dưỡng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_dishes.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-utensil-spoon mr-2"></i> Quản lý món ăn
                </a>
            </li>
            <li class="mb-4">
                <a href="admin_feedback.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-comments mr-2"></i> Quản lý phản hồi
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_preservation.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-leaf mr-2"></i> Quản lý chi tiết dinh dưỡng
                </a>
            </li>
            <li>
                <a href="logout.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-sign-out-alt mr-2"></i> Đăng xuất
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="ml-96 p-0 w-[calc(100%-24rem)]">
        <div class="max-w-full mx-auto bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-3xl font-bold mb-6 text-center">Danh sách người dùng</h2>
            <?php if (isset($_SESSION['success'])): ?>
                <div class="bg-green-100 text-green-700 p-4 mb-4 rounded"><?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
            <?php elseif (isset($_SESSION['error'])): ?>
                <div class="bg-red-100 text-red-700 p-4 mb-4 rounded"><?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
            <?php endif; ?>

            <!-- Form tìm kiếm -->
            <div class="mb-6">
                <form method="POST" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Tên đăng nhập</label>
                        <input type="text" name="ten_dangnhap" value="<?php echo htmlspecialchars($search_params['ten_dangnhap']); ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2 text-base focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Họ tên</label>
                        <input type="text" name="ho_ten" value="<?php echo htmlspecialchars($search_params['ho_ten']); ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2 text-base focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Email</label>
                        <input type="text" name="email" value="<?php echo htmlspecialchars($search_params['email']); ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2 text-base focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">SĐT</label>
                        <input type="text" name="sdt" value="<?php echo htmlspecialchars($search_params['sdt']); ?>" class="mt-1 block w-full border border-gray-300 rounded-md p-2 text-base focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    <div class="flex items-end">
                        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 w-full">Tìm kiếm</button>
                    </div>
                </form>
            </div>

            <div class="mb-4">
                <a href="add_user.php" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">Thêm người dùng</a>
            </div>

            <?php if (empty($users)): ?>
                <p class="text-center text-gray-600">Không tìm thấy người dùng nào phù hợp.</p>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full border-collapse text-base">
                        <thead>
                            <tr class="bg-gray-300 font-semibold text-gray-800">
                                <th class="border p-2 text-left">Mã</th>
                                <th class="border p-2 text-left">Tên đăng nhập</th>
                                <th class="border p-2 text-left">Họ tên</th>
                                <th class="border p-2 text-left">Email</th>
                                <th class="border p-2 text-left">SĐT</th>
                                <th class="border p-2 text-left">Tuổi</th>
                                <th class="border p-2 text-left">Chiều cao</th>
                                <th class="border p-2 text-left">Cân nặng</th>
                                <th class="border p-2 text-left">Giới tính</th>
                                <th class="border p-2 text-left">Tình trạng</th>
                                <th class="border p-2 text-left">Vai trò</th>
                                <th class="border p-2 text-left">Hành động</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 odd:bg-gray-50 even:bg-white">
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td class="border p-2"><?php echo htmlspecialchars($user['ma_nguoidung']); ?></td>
                                    <td class="border p-2"><?php echo htmlspecialchars($user['ten_dangnhap']); ?></td>
                                    <td class="border p-2"><?php echo htmlspecialchars($user['ho_ten']); ?></td>
                                    <td class="border p-2"><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td class="border p-2"><?php echo htmlspecialchars($user['sdt'] ?? ''); ?></td>
                                    <td class="border p-2"><?php echo htmlspecialchars($user['tuoi'] ?? ''); ?></td>
                                    <td class="border p-2"><?php echo htmlspecialchars($user['chieu_cao'] ?? ''); ?> cm</td>
                                    <td class="border p-2"><?php echo htmlspecialchars($user['can_nang'] ?? ''); ?> kg</td>
                                    <td class="border p-2"><?php echo htmlspecialchars($user['gioi_tinh'] ?? ''); ?></td>
                                    <td class="border p-2"><?php echo htmlspecialchars($user['tinh_trang'] ?? 'Bình thường'); ?></td>
                                    <td class="border p-2"><?php echo htmlspecialchars($user['vai_tro']); ?></td>
                                    <td class="border p-2">
                                        <a href="edit_user.php?id=<?php echo $user['ma_nguoidung']; ?>" class="action-edit">Sửa</a>
                                        <a href="process_delete_user.php?id=<?php echo $user['ma_nguoidung']; ?>" class="action-delete" onclick="return confirm('Bạn có chắc muốn xóa người dùng này?')">Xóa</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
