<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $diet_id = $_GET['id'];

    // Kiểm tra xem chế độ có liên kết với món ăn trong monan_chedo
    $sql = "SELECT * FROM monan_chedo WHERE ma_chedo = :ma_chedo";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_chedo' => $diet_id]);
    if ($stmt->rowCount() > 0) {
        header("Location: manage_diets.php?error=Không thể xóa chế độ vì còn món ăn liên kết");
        exit();
    }

    // Xóa chế độ
    $sql = "DELETE FROM chedo WHERE ma_chedo = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['id' => $diet_id]);

    header("Location: manage_diets.php");
    exit();
}
?>