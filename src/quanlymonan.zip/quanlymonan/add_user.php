<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Tạo CSRF token
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm người dùng</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex">
    <div class="w-96 bg-gray-800 text-white h-screen fixed top-0 left-0 p-4 text-xl">
        <h2 class="text-3xl font-bold mb-6">Quản trị viên</h2>
        <ul>
            <li class="mb-4">
                <a href="admin_dashboard.php" class="flex items-center p-2 bg-gray-700 rounded">
                    <i class="fas fa-users mr-2"></i> Quản lý người dùng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-list mr-2"></i> Quản lý danh mục
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_diets.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-utensils mr-2"></i> Quản lý chế độ
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_ingredients.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-seedling mr-2"></i> Quản lý nguyên liệu
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_nutrients.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-heartbeat mr-2"></i> Quản lý dinh dưỡng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_components.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-vial mr-2"></i> Quản lý thành phần dinh dưỡng
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_dishes.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-utensil-spoon mr-2"></i> Quản lý món ăn
                </a>
            </li>
            <li class="mb-4">
                <a href="admin_feedback.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-comments mr-2"></i> Quản lý phản hồi
                </a>
            </li>
            <li class="mb-4">
                <a href="manage_preservation.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-leaf mr-2"></i> Quản lý chi tiết dinh dưỡng
                </a>
            </li>
            <li>
                <a href="logout.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-sign-out-alt mr-2"></i> Đăng xuất
                </a>
            </li>
        </ul>
    </div>

    <div class="ml-64 p-8 w-full min-h-screen">
        <div class="bg-white p-8 rounded-xl shadow-xl w-full max-w-5xl mx-auto border border-gray-300">
            <h2 class="text-3xl font-bold mb-8 text-center text-gray-800">Thêm người dùng</h2>

            <?php if (isset($_SESSION['error'])): ?>
                <p class="text-red-500 mb-4"><?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></p>
            <?php endif; ?>

            <form action="process_add_user.php" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-6" onsubmit="return confirm('Bạn có chắc muốn thêm người dùng này?')">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">

                <div>
                    <label class="block font-semibold text-gray-700 mb-1">Tên đăng nhập</label>
                    <input type="text" name="ten_dangnhap" class="w-full p-3 border rounded-lg" placeholder="VD: user123" required>
                </div>
                <div>
                    <label class="block font-semibold text-gray-700 mb-1">Họ tên</label>
                    <input type="text" name="ho_ten" class="w-full p-3 border rounded-lg" placeholder="VD: Nguyễn Văn A" required>
                </div>
                <div>
                    <label class="block font-semibold text-gray-700 mb-1">Email</label>
                    <input type="email" name="email" class="w-full p-3 border rounded-lg" placeholder="VD: example@domain.com" required>
                </div>
                <div>
                    <label class="block font-semibold text-gray-700 mb-1">Số điện thoại</label>
                    <input type="text" name="sdt" class="w-full p-3 border rounded-lg" placeholder="VD: 0123456789">
                </div>
                <div>
                    <label class="block font-semibold text-gray-700 mb-1">Tuổi</label>
                    <input type="number" name="tuoi" min="1" max="150" class="w-full p-3 border rounded-lg" placeholder="VD: 25" required>
                </div>
                <div>
                    <label class="block font-semibold text-gray-700 mb-1">Chiều cao (cm)</label>
                    <input type="number" name="chieu_cao" step="0.1" min="50" max="300" class="w-full p-3 border rounded-lg" placeholder="VD: 170.5" required>
                </div>
                <div>
                    <label class="block font-semibold text-gray-700 mb-1">Cân nặng (kg)</label>
                    <input type="number" name="can_nang" step="0.1" min="20" max="300" class="w-full p-3 border rounded-lg" placeholder="VD: 65.0" required>
                </div>
                <div>
                    <label class="block font-semibold text-gray-700 mb-1">Tình trạng</label>
                    <input type="text" name="tinh_trang" class="w-full p-3 border rounded-lg" value="Bình thường" maxlength="50" placeholder="VD: Đang giảm cân" required>
                </div>
                <div>
                    <label class="block font-semibold text-gray-700 mb-1">Giới tính</label>
                    <select name="gioi_tinh" class="w-full p-3 border rounded-lg" required>
                        <option value="Nam">Nam</option>
                        <option value="Nữ">Nữ</option>
                        <option value="Khác">Khác</option>
                    </select>
                </div>
                <div class="relative">
                    <label class="block font-semibold text-gray-700 mb-1">Mật khẩu</label>
                    <input type="password" name="password" id="password" class="w-full p-3 border rounded-lg" placeholder="Tối thiểu 6 ký tự" required>
                    <span class="absolute right-3 top-10 cursor-pointer" onclick="togglePassword('password', 'eyeIcon')">
                        <i id="eyeIcon" class="fas fa-eye"></i>
                    </span>
                </div>
                <div class="relative">
                    <label class="block font-semibold text-gray-700 mb-1">Xác nhận mật khẩu</label>
                    <input type="password" name="confirm_password" id="confirm_password" class="w-full p-3 border rounded-lg" placeholder="Nhập lại mật khẩu" required>
                    <span class="absolute right-3 top-10 cursor-pointer" onclick="togglePassword('confirm_password', 'eyeIconConfirm')">
                        <i id="eyeIconConfirm" class="fas fa-eye"></i>
                    </span>
                </div>
                <div>
                    <label class="block font-semibold text-gray-700 mb-1">Vai trò</label>
                    <select name="vai_tro" class="w-full p-3 border rounded-lg" required>
                        <option value="nguoidung">Người dùng</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                <div class="col-span-2 pt-4">
                    <button type="submit" class="w-full bg-green-600 text-white font-semibold py-3 rounded-lg hover:bg-green-700 transition">Thêm</button>
                </div>
            </form>
            <p class="mt-6 text-center"><a href="admin_dashboard.php" class="text-blue-500 hover:underline">Quay lại</a></p>
        </div>
    </div>

    <script>
        function togglePassword(inputId, iconId) {
            const passwordInput = document.getElementById(inputId);
            const eyeIcon = document.getElementById(iconId);
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                eyeIcon.classList.remove('fa-eye');
                eyeIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                eyeIcon.classList.remove('fa-eye-slash');
                eyeIcon.classList.add('fa-eye');
            }
        }

        document.querySelector('form').addEventListener('submit', function(e) {
            const email = document.querySelector('input[name="email"]').value;
            const sdt = document.querySelector('input[name="sdt"]').value;
            const password = document.querySelector('input[name="password"]').value;
            const confirmPassword = document.querySelector('input[name="confirm_password"]').value;

            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                e.preventDefault();
                alert('Email không hợp lệ!');
            }
            if (sdt && !/^0[0-9]{9}$/.test(sdt)) {
                e.preventDefault();
                alert('Số điện thoại không hợp lệ!');
            }
            if (password && password !== confirmPassword) {
                e.preventDefault();
                alert('Mật khẩu xác nhận không khớp!');
            }
            if (password && password.length < 6) {
                e.preventDefault();
                alert('Mật khẩu phải dài ít nhất 6 ký tự!');
            }
        });
    </script>
</body>
</html>
