<?php
session_start();
require_once 'connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['vai_tro'] != 'admin') {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

    if ($user_id == $_SESSION['user_id']) {
        $_SESSION['error'] = "Không thể xóa tài khoản đang đăng nhập";
        header("Location: admin_dashboard.php");
        exit();
    }

    try {
        $sql_check = "SELECT ma_nguoidung FROM nguoidung WHERE ma_nguoidung = :id";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->execute(['id' => $user_id]);
        if (!$stmt_check->fetch()) {
            $_SESSION['error'] = "Người dùng không tồn tại";
            header("Location: admin_dashboard.php");
            exit();
        }

        $sql = "DELETE FROM nguoidung WHERE ma_nguoidung = :id";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['id' => $user_id]);

        $_SESSION['success'] = "Xóa người dùng thành công. Các dữ liệu liên quan (món ăn yêu thích, thực đơn, phản hồi) cũng đã được xóa.";
        header("Location: admin_dashboard.php");
        exit();
    } catch (PDOException $e) {
        error_log("Database error at " . date('Y-m-d H:i:s') . ": " . $e->getMessage());
        $_SESSION['error'] = "Đã xảy ra lỗi khi xóa người dùng";
        header("Location: admin_dashboard.php");
        exit();
    }
}
?>